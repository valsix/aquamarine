<?php
defined('BASEPATH') or exit('No direct script access allowed');

include_once("functions/default.func.php");
include_once("functions/string.func.php");
include_once("functions/date.func.php");
// include_once("lib/excel/excel_reader2.php");

class pre_report_json extends CI_Controller
{

	function __construct()
	{
		parent::__construct();

		if (!$this->kauth->getInstance()->hasIdentity()) {
			redirect('login');
		}

		$this->db->query("SET DATESTYLE TO PostgreSQL,European;");
		$this->ID = $this->kauth->getInstance()->getIdentity()->ID;
		$this->NAMA = $this->kauth->getInstance()->getIdentity()->NAMA;
		$this->JABATAN = $this->kauth->getInstance()->getIdentity()->JABATAN;
		$this->HAK_AKSES = $this->kauth->getInstance()->getIdentity()->HAK_AKSES;
		$this->LAST_LOGIN = $this->kauth->getInstance()->getIdentity()->LAST_LOGIN;
		$this->USERNAME = $this->kauth->getInstance()->getIdentity()->USERNAME;
		$this->USER_LOGIN_ID = $this->kauth->getInstance()->getIdentity()->USER_LOGIN_ID;
		$this->USER_GROUP = $this->kauth->getInstance()->getIdentity()->USER_GROUP;
		$this->CABANG_ID = $this->kauth->getInstance()->getIdentity()->CABANG_ID;
		$this->CABANG = $this->kauth->getInstance()->getIdentity()->CABANG;
	}


	function  add()
	{
		$this->load->model('Document');

		$this->load->library("FileHandler");
		$file = new FileHandler();
		$filesData = $_FILES["document"];
		$reqLinkFileTemp              =  $this->input->post("reqLinkFileTemp");
		$file->cekSize($filesData,$reqLinkFileTemp);


		$reqId 				= $this->input->post('reqId');
		$reqKeterangan 		= $this->input->post('reqKeterangan');
		$reqNama 		 	= $this->input->post('reqNama');
		$reqTipe 		 	= $this->input->post('reqTipe');


		$name_folder = strtolower(str_replace(' ', '_', $reqTipe));

		$document = new Document();
		$document->setField("DOCUMENT_ID", $reqId);
		$document->setField("NAME", $reqNama);
		$document->setField("CATEGORY", $reqTipe);
		$document->setField("DESCRIPTION", $reqKeterangan);

		if (empty($reqId)) {
			$document->insert();
			$reqId = $document->id;
		} else {
			$document->update();
		}


		
		
		// exit;
		$FILE_DIR = "uploads/" . $name_folder . "/" . $reqId . "/";
		makedirs($FILE_DIR);

		$arrData = array();
		for ($i = 0; $i < count($filesData); $i++) {
			$renameFile = $reqId . '-' . $i . "-" . getExtension($filesData['name'][$i]);
			if ($file->uploadToDirArray('document', $FILE_DIR, $renameFile, $i)) {
				array_push($arrData, $renameFile);
			} else {
				array_push($arrData, $reqLinkFileTemp[$i]);
			}
		}
		$str_name_path = '';
		for ($i = 0; $i < count($arrData); $i++) {
			if (!empty($arrData[$i])) {
				if ($i == 0) {
					$str_name_path .= $arrData[$i];
				} else {
					$str_name_path .= ',' . $arrData[$i];
				}
			}
		}

		$document = new Document();
		$document->setField("DOCUMENT_ID", $reqId);
		$document->setField("PATH", $str_name_path);
		$document->updatePath();



		echo $reqId . '- Data berhasil di simpan';
	}


	function delete()
	{
		$reqId	= $this->input->get('reqId');
		$this->load->model("Pengurus");
		$pengurus = new Pengurus();


		$pengurus->setField("PENGURUS_ID", $reqId);
		if ($pengurus->delete())
			$arrJson["PESAN"] = "Data berhasil dihapus.";
		else
			$arrJson["PESAN"] = "Data gagal dihapus.";

		echo json_encode($arrJson);
	}

	function import_excel()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);
		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$katerori = $this->input->post("reqTipe");



		$this->load->model('Document');
		for ($i = 2; $i <= $baris; $i++) {
			$document = new Document();
			$document->setField("CATEGORY", $katerori);
			$document->setField("NAME", $data->val($i, 2));
			$document->setField("DESCRIPTION", $data->val($i, 3));

			$document->insert();
			$reqId = $document->id;
			$document = new Document();
			$document->setField("DOCUMENT_ID", $reqId);
			$document->setField("CATEGORY", $katerori);
			$document->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$document->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$document->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}

	function import_excel2()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);

		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$kategori = $this->input->post("reqTipe");



		$this->load->model('Document');

		for ($i = 2; $i <= $baris; $i++) {

			$document = new Document();
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $data->val($i, 2));
			$document->setField("DESCRIPTION", $data->val($i, 3));
			$document->setField("PATH", $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $data->val($i, 5));
			$document->insert();
			$reqId = $document->id;

			$document = new Document();
			$document->setField("DOCUMENT_ID", $reqId);
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$document->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$document->setField("PATH", $reqId . ' - ' . $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $reqId . ' - ' . $data->val($i, 5));
			$document->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}


	function import_excel3()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);

		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$kategori = $this->input->post("reqTipe");


		$this->load->model('Document');

		for ($i = 2; $i <= $baris; $i++) {

			$document = new Document();
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $data->val($i, 2));
			$document->setField("DESCRIPTION", $data->val($i, 3));
			$document->setField("PATH", $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $data->val($i, 5));
			$document->insert();
			$reqId = $document->id;

			$document = new Document();
			$document->setField("DOCUMENT_ID", $reqId);
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$document->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$document->setField("PATH", $reqId . ' - ' . $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $reqId . ' - ' . $data->val($i, 5));
			$document->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}


	function import_excel4()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);

		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$kategori = $this->input->post("reqTipe");


		$this->load->model('Document');

		for ($i = 2; $i <= $baris; $i++) {

			$document = new Document();
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $data->val($i, 2));
			$document->setField("DESCRIPTION", $data->val($i, 3));
			$document->setField("PATH", $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $data->val($i, 5));
			$document->insert();
			$reqId = $document->id;

			$document = new Document();
			$document->setField("DOCUMENT_ID", $reqId);
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$document->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$document->setField("PATH", $reqId . ' - ' . $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $reqId . ' - ' . $data->val($i, 5));
			$document->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}


	function import_excel5()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);

		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$kategori = $this->input->post("reqTipe");


		$this->load->model('Document');

		for ($i = 2; $i <= $baris; $i++) {

			$document = new Document();
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $data->val($i, 2));
			$document->setField("DESCRIPTION", $data->val($i, 3));
			$document->setField("PATH", $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $data->val($i, 5));
			$document->insert();
			$reqId = $document->id;

			$document = new Document();
			$document->setField("DOCUMENT_ID", $reqId);
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$document->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$document->setField("PATH", $reqId . ' - ' . $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $reqId . ' - ' . $data->val($i, 5));
			$document->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}


	function import_excel6()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);

		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$kategori = $this->input->post("reqTipe");


		$this->load->model('Document');

		for ($i = 2; $i <= $baris; $i++) {

			$document = new Document();
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $data->val($i, 2));
			$document->setField("DESCRIPTION", $data->val($i, 3));
			$document->setField("PATH", $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $data->val($i, 5));
			$document->insert();
			$reqId = $document->id;

			$document = new Document();
			$document->setField("DOCUMENT_ID", $reqId);
			$document->setField("CATEGORY", $kategori);
			$document->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$document->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$document->setField("PATH", $reqId . ' - ' . $data->val($i, 4));
			$document->setField("EXPIRED_DATE", $reqId . ' - ' . $data->val($i, 5));
			$document->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}


	function import_excel7()
	{
		header('Cache-Control:max-age=0');
		header('Cache-Control:max-age=1');
		ini_set('memory_limit', '-1');

		ini_set('upload_max_filesize', '200M');
		ini_set('post_max_size', '200M');
		ini_set('display_errors', TRUE);
		ini_set('display_startup_errors', TRUE);
		ini_set('max_execution_time', -1);

		include_once("libraries/excel/excel_reader2.php");
		$data = new Spreadsheet_Excel_Reader($_FILES['reqFiles']["tmp_name"]);
		$baris = $data->rowcount($sheet_index = 0);
		// print_r( $data);
		// print_r($baris);
		$arrData = array();
		// $katerori = 'Company Profile';
		$kategori = $this->input->post("reqTipe");


		$this->load->model('Dokumen');

		for ($i = 2; $i <= $baris; $i++) {

			$dokumen = new Dokumen();
			$dokumen->setField("CATEGORY", $kategori);
			$dokumen->setField("NAME", $data->val($i, 2));
			$dokumen->setField("DESCRIPTION", $data->val($i, 3));
			$dokumen->setField("PATH", $data->val($i, 4));
			$dokumen->setField("LAST_REVISI", $data->val($i, 5));
			$dokumen->setField("EXPIRED_DATE", $data->val($i, 6));
			$dokumen->insert();
			$reqId = $dokumen->id;

			$dokumen = new Dokumen();
			$dokumen->setField("DOCUMENT_ID", $reqId);
			$dokumen->setField("CATEGORY", $kategori);
			$dokumen->setField("NAME", $reqId . ' - ' . $data->val($i, 2));
			$dokumen->setField("DESCRIPTION", $reqId . ' - ' . $data->val($i, 3));
			$dokumen->setField("PATH", $reqId . ' - ' . $data->val($i, 4));
			$dokumen->setField("LAST_REVISI", $reqId . ' - ' . $data->val($i, 5));
			$dokumen->setField("EXPIRED_DATE", $reqId . ' - ' . $data->val($i, 6));
			$dokumen->update();

			// echo $data->val($i,2).'<br>';
		}
		echo 'Data Berhasil di import';
	}


	function combo()
	{
		$this->load->model("Pengurus");
		$pengurus = new Pengurus();

		$pengurus->selectByParams(array());
		$i = 0;
		while ($pengurus->nextRow()) {
			$arr_json[$i]['id']		= $pengurus->getField("PENGURUS_ID");
			$arr_json[$i]['text']	= $pengurus->getField("NAMA");
			$i++;
		}

		echo json_encode($arr_json);
	}

	function send_as_email()
	{
		$this->load->model("ResikoEmail");
		$resiko_email = new ResikoEmail();
		$this->load->model('Document');


		$reqId    		= $this->input->post("reqId");
		$reqName3 		= $this->input->post("reqName3");
		$reqDescription = $_POST["reqDescription"];

		$arrData[$KETERANGAN] = $reqDescription;
		$reqSubject = ' Company Profile	';

		$document = new Document();
		$document->selectByParams(array("A.DOCUMENT_ID" => $reqId));
		$arrAttachemt = array();
		while ($document->nextRow()) {
			$reqPath                 = $document->getField("PATH");
			$files_data = explode(',',  $reqPath);
			for ($i = 0; $i < count($files_data); $i++) {
				if (!empty($files_data[$i])) {
					$texts = explode('-', $files_data[$i]);
					$doc_lampiran = "uploads/company_profile/" . $reqId . "/" . $files_data[$i];
					array_push($arrAttachemt, $doc_lampiran);
				}
			}
		}


		$arrData["KETERANGAN"] = $reqDescription;

		$arrDataAddres = array();
		$indexs = 0;
		$reqName3s = explode(',', $reqName3);
		for ($i = 0; $i < count($reqName3s); $i++) {
			$nama_emails = array();
			$nama_emails = explode('[', $reqName3s[$i]);
			$nama_penerima = $nama_emails[0];
			if (strpos($nama_emails, '@') !== false) {
				$nama_email =  str_replace("]", '', $nama_emails[1]);
				$arrDataAddres[$indexs]["EMAIL"] = $nama_email;
				$arrDataAddres[$indexs]["PENERIMA"] = $nama_penerima;
				$indexs++;
			}
		}

		try {
			$this->load->library("KMail");
			$mail = new KMail();
			$body =  $this->load->view('email/pesan', $arrData, true);

			// for ($i = 0; $i < count($reqName3s); $i++) {
			// 	$nama_emails = explode('[', $reqName3s[$i]);
			// 	$nama_email = str_replace(' ', '', $nama_emails[0]);

			// 	$nama_penerima = pre_regregName($reqName3s[$i]);
			// 	$mail->AddAddress($resiko_email->sendEmail($nama_email),  $nama_penerima);
			// }

			for ($i = 0; $i < count($arrDataAddres); $i++) {
				$mail->AddAddress($arrDataAddres[$i]['EMAIL'], $arrDataAddres[$i]['PENERIMA']);
			}

			for ($i = 0; $i < count($arrAttachemt); $i++) {
				$mail->addAttachment($arrAttachemt[$i]);
			}
			$mail->Subject  =  " [AQUAMARINE] " . $reqSubject;
			$mail->Body = $body;
			// $mail->MsgHTML($body);
			if (!$mail->Send()) {

				echo "Error sending: " . $mail->ErrorInfo;
			} else {
				// echo "E-mail sent to " . $email . '<br>';
			}
			// $mail->Send();

			unset($mail);
		} catch (Exception $e) {
			echo 'Caught exception: ',  $e->getMessage(), "\n";
		}
		echo 'Email berhasil dikirim';
	}
}
