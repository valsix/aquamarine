<?php
defined('BASEPATH') or exit('No direct script access allowed');

include_once("functions/string.func.php");
include_once("functions/date.func.php");

class combo_json extends CI_Controller
{

	function __construct()
	{
		parent::__construct();

		//kauth
		if (!$this->kauth->getInstance()->hasIdentity()) {
			// trow to unauthenticated page!
			redirect('login');
		}
	}

	function comboQms()
	{
		$this->load->model('FormatQm');
		$jenis_kualifikasi = new FormatQm();
		$jenis_kualifikasi->selectByParamsMonitoring(array());
		$i = 0;
		while ($jenis_kualifikasi->nextRow()) {
			$arr_json[$i]['id']		= $jenis_kualifikasi->getField("FORMAT_ID");
			$arr_json[$i]['text']	= strtoupper($jenis_kualifikasi->getField("FORMAT"));
			$i++;
		}
		echo json_encode($arr_json);
	}

	function comboCondisi()
	{
		$i = 0;
		$arr_json[$i]['id']		= "Good";
		$arr_json[$i]['text']	= "Good";
		$i++;
		$arr_json[$i]['id']		= "Repair";
		$arr_json[$i]['text']	= "Repair";
		$i++;
		$arr_json[$i]['id']		= "Review";
		$arr_json[$i]['text']	= "Review";
		$i++;

		echo json_encode($arr_json);
	}

	function comboQmss()
	{
		$i = 0;
		$arr_json[$i]['id']		= "QMS";
		$arr_json[$i]['text']	= "QMS";
		$i++;
		$arr_json[$i]['id']		= "QPS";
		$arr_json[$i]['text']	= "QPS";


		echo json_encode($arr_json);
	}


	function comboValueClassOfSurvey()
	{
		$i = 0;
		$arr_json[$i]['id']		= "UW";
		$arr_json[$i]['text']	= "UW";
		$i++;
		$arr_json[$i]['id']		= "UT";
		$arr_json[$i]['text']	= "UT";
		$i++;
		$arr_json[$i]['id']		= "CRANE TEST";
		$arr_json[$i]['text']	= "CRANE TEST";
		$i++;
		$arr_json[$i]['id']		= "HULL REPAIR";
		$arr_json[$i]['text']	= "HULL REPAIR";
		$i++;
		echo json_encode($arr_json);
	}

	function comboSatuan(){
		$i = 0;

		$this->load->model("Satuan");
		$satuan  = new Satuan();
		$satuan->selectByParamsMonitoring(array());
		while ($satuan->nextRow()) {
			$arr_json[$i]['id']		= $satuan->getField("NAME");
			$arr_json[$i]['text']	= $satuan->getField("NAME");
			$i++;
		}
		echo json_encode($arr_json);
	}

	function comboEvidance()
	{
		$i = 0;
		$arr_json[$i]['id']		= "Ada - Sesuai";
		$arr_json[$i]['text']	= "Ada - Sesuai";
		$i++;
		$arr_json[$i]['id']		= "Ada - Tidak sesuai";
		$arr_json[$i]['text']	= "Ada - Tidak sesuai";
		$i++;
		$arr_json[$i]['id']		= "Tidak ada";
		$arr_json[$i]['text']	= "Tidak ada";
		$i++;

		echo json_encode($arr_json);
	}

	function combo_cost_code()
	{

		$this->load->model("CostCode");
		$cost_code = new CostCode();
		$group_by = ' ORDER BY A.KODE ASC';
		$cost_code->selectByParamsMonitoring(array(), -1, -1, '', $group_by);
		$i = 0;
		while ($cost_code->nextRow()) {
			$arr_json[$i]['id']        = $cost_code->getField("KODE");
			$arr_json[$i]['text']    = $cost_code->getField("KODE") . ' - ' . $cost_code->getField("NAMA");
			$i++;
		}

		echo json_encode($arr_json);
	}

	function combo_categori_other()
	{
		$this->load->model('CategoryOther');
		$jenis_kualifikasi = new CategoryOther();
		$jenis_kualifikasi->selectByParamsMonitoring(array());
		$i = 0;
		while ($jenis_kualifikasi->nextRow()) {
			$arr_json[$i]['id']		= $jenis_kualifikasi->getField("CATEGORY_ID");
			$arr_json[$i]['text']	= strtoupper($jenis_kualifikasi->getField("CATEGORY"));
			$i++;
		}
		echo json_encode($arr_json);
	}

	function comboDokumentPath()
	{
		$this->load->model('Document');
		$jenis_kualifikasi = new Document();
		$jenis_kualifikasi->selectByParamsDocCategori(array());
		$i = 0;
		while ($jenis_kualifikasi->nextRow()) {
			$arr_json[$i]['id']		= $jenis_kualifikasi->getField("CATEGORY");
			$arr_json[$i]['text']	= strtoupper($jenis_kualifikasi->getField("CATEGORY"));
			$i++;
		}
		echo json_encode($arr_json);
	}

	function combo_jenis_kwalifikasi()
	{
		$this->load->model('JenisKualifikasi');
		$jenis_kualifikasi = new JenisKualifikasi();
		$jenis_kualifikasi->selectByParamsMonitoring(array());
		$i = 0;
		while ($jenis_kualifikasi->nextRow()) {
			$arr_json[$i]['id']		= $jenis_kualifikasi->getField("JENIS_ID");
			$arr_json[$i]['text']	= strtoupper($jenis_kualifikasi->getField("JENIS"));
			$i++;
		}
		echo json_encode($arr_json);
	}

	function comboCertificate()
	{
		$this->load->model('Certificate');
		$certificate = new Certificate();
		$certificate->selectByParams(array());
		$i = 0;
		while ($certificate->nextRow()) {
			$arr_json[$i]['id']		= $certificate->getField("CERTIFICATE_ID");
			$arr_json[$i]['text']	= strtoupper($certificate->getField("CERTIFICATE"));
			$i++;
		}
		echo json_encode($arr_json);
	}

	function comboValueClassOfVessel()
	{
		$i = 0;
		$this->load->model("ClassOfVessel");
		$class_of_vessel = new ClassOfVessel();
		$class_of_vessel->selectByParamsMonitoring(array(), -1, -1, $statement);
		while ($class_of_vessel->nextRow()) {
			$arr_json[$i]['id']		= $class_of_vessel->getField("NAME");

			$arr_json[$i]['text']	= $class_of_vessel->getField("NAME");
			$i++;
			# code...
		}
		// $arr_json[$i]['id']		= "ABS";
		// $arr_json[$i]['text']	= "ABS";
		// $i++;
		// $arr_json[$i]['id']		= "BKI";
		// $arr_json[$i]['text']	= "BKI";
		// $i++;
		// $arr_json[$i]['id']		= "BV";
		// $arr_json[$i]['text']	= "BV";
		// $i++;
		// $arr_json[$i]['id']		= "DNV";
		// $arr_json[$i]['text']	= "DNV";
		// $i++;
		// $arr_json[$i]['id']		= "GL";
		// $arr_json[$i]['text']	= "GL";
		// $i++;
		// $arr_json[$i]['id']		= "LR";
		// $arr_json[$i]['text']	= "LR";
		// $i++;
		// $arr_json[$i]['id']		= "NK";
		// $arr_json[$i]['text']	= "NK";
		// $i++;
		// $arr_json[$i]['id']		= "RINA";
		// $arr_json[$i]['text']	= "RINA";


		// $i++;
		echo json_encode($arr_json);
	}

	function comboVessel()
	{
		$this->load->model("Vessel");
		$vessel = new Vessel();
		$reqId = $this->input->get("reqId");
		$i = 0;
		$vessel->selectByParamsMonitoring(array("A.COMPANY_ID" => $reqId));
		while ($vessel->nextRow()) {
			$arr_json[$i]['id']		= $vessel->getField("NAME");
			$arr_json[$i]['text']	= $vessel->getField("NAME");
			$i++;
		}

		echo json_encode($arr_json);
	}

	function ambil_tahun()
	{
		$tahun = Date('Y');
		$i = 0;
		for ($j = 2017; $j <= $tahun; $j++) {
			$arr_json[$i]['id']		= $j;
			$arr_json[$i]['text']	= $j;
			$i++;
		}
		$arr_json[$i]['id']		= "All Year";
		$arr_json[$i]['text']	= "All Year";
		echo json_encode($arr_json);
	}
	function comboTypeContact()
	{
		$i = 0;
		$arr_json[$i]['id']		= "Company";
		$arr_json[$i]['text']	= "Company";
		$i++;
		$arr_json[$i]['id']		= "Driver";
		$arr_json[$i]['text']	= "Driver";
		$i++;

		$i++;
		echo json_encode($arr_json);
	}
	function comboValueTypeOfVessel()
	{
		$i = 0;
		$this->load->model("TypeOfService");
		$type_of_service = new TypeOfService();
		$type_of_service->selectByParamsMonitoring(array());
		while ( $type_of_service->nextRow()) {
			$arr_json[$i]['id']		= $type_of_service->getField("NAME");
			$arr_json[$i]['text']	= $type_of_service->getField("NAME");
			# code...
			$i++;
		}

		// $arr_json[$i]['id']		= "Tanker";
		// $arr_json[$i]['text']	= "Tanker";
		// $i++;
		// $arr_json[$i]['id']		= "Bulk Carrier";
		// $arr_json[$i]['text']	= "Bulk Carrier";
		// $i++;
		// $arr_json[$i]['id']		= "Cargo";
		// $arr_json[$i]['text']	= "Cargo";
		// $i++;
		// $arr_json[$i]['id']		= "Tug Boat";
		// $arr_json[$i]['text']	= "Tug Boat";
		// $i++;
		// $arr_json[$i]['id']		= "Barge";
		// $arr_json[$i]['text']	= "Barge";
		// $i++;
		// $arr_json[$i]['id']		= "F.S.O";
		// $arr_json[$i]['text']	= "F.S.O";
		// $i++;
		// $arr_json[$i]['id']		= "Rig";
		// $arr_json[$i]['text']	= "Rig";
		// $i++;
		// $arr_json[$i]['id']		= "Container";
		// $arr_json[$i]['text']	= "Container";

		echo json_encode($arr_json);
	}

	function comboTimeOfTest()
	{
		$i = 0;

		$arr_json[$i]['id']		= "1";
		$arr_json[$i]['text']	= "Daily";
		$i++;
		$arr_json[$i]['id']		= "2";
		$arr_json[$i]['text']	= "Weekly";
		$i++;
		$arr_json[$i]['id']		= "3";
		$arr_json[$i]['text']	= "Monthly";
		$i++;
		$arr_json[$i]['id']		= "4";
		$arr_json[$i]['text']	= "6 Monthly";
		$i++;
		$arr_json[$i]['id']		= "5";
		$arr_json[$i]['text']	= "Yearly";
		$i++;
		$arr_json[$i]['id']		= "6";
		$arr_json[$i]['text']	= "2,5 Yearly";
		$i++;
		$arr_json[$i]['id']		= "7";
		$arr_json[$i]['text']	= "5 Yearly";
		$i++;


		echo json_encode($arr_json);
	}


	function comboPeriod()
	{
		$i = 0;

		$arr_json[$i]['id']		= "1 Year";
		$arr_json[$i]['text']	= "1 Year";
		$i++;
		$arr_json[$i]['id']		= "2 Year";
		$arr_json[$i]['text']	= "2 Year";
		$i++;


		echo json_encode($arr_json);
	}




	function comboTypeOfService()
	{
		$arrDatas  = array(
			"Bolland Pull Test",
			"Commercial Driver Course Certificate",
			"Crane Load Test",
			"David Load Test",
			"David Load Test / Life Boat Repair",
			"Hull Damage Inspection ,Welding",
			"Hull Repair / Running Hull Repair",
			"Hull Button Cleaning Inspection",
			"Instalation Zinc Anode",
			"Leg on Jack Up, Cleaning Inspection",
			"Magnetic Particle Exmination",
			"Maintance Repair Damage",
			"Maintance Repair Single Moon",
			"Maintance Of Harbours Facility",
			"Man Power",
			"Piping Inspection Repair",
			"Platform Maintance",
			"Propeller Tail Shaft _Rudder Inspection",
			"Remove _install Zink Anode Prototype",
			"See Trial Test",
			"Seachest Cleaning Inspection",
			"Ultrasonic Measurement ( FLow Diagram )",
			"Ultrasonic Thickness Gauging",
			"Underwater Cleaning"

		);

		for ($i = 0; $i < count($arrDatas); $i++) {
			$arr_json[$i]['id']		= $arrDatas[$i];
			$arr_json[$i]['text']	= $arrDatas[$i];
		}

		echo json_encode($arr_json);
	}

	function comboFindMenthod()
	{
		$i = 0;

		$arr_json[$i]['id']		= "1";
		$arr_json[$i]['text']	= "By Application";
		$i++;
		$arr_json[$i]['id']		= "2";
		$arr_json[$i]['text']	= "By File Content";

		echo json_encode($arr_json);
	}

	function comboReport()
	{
		$i = 0;
		$this->load->model("Report");
		$report = new Report();

		$report->selectByParamsCombo(array());
		while ($report->nextRow()) {
			$arr_json[$i]['id']		= $report->getField("REPORT_ID");
			$arr_json[$i]['text']	= $report->getField("REPORT");
			$i++;
		}
		echo json_encode($arr_json);
	}

	function ComboBank()
	{
		$this->load->model("Bank");
		$bank = new Bank();
		$bank->selectByParamsMonitoring(array());
		$arr_json = array();
		$i = 0;
		while ($bank->nextRow()) {
			$arr_json[$i]['id']		= $bank->getField("BANK_ID");
			$arr_json[$i]['text']	= $bank->getField("NAMA");
			$i++;
		}
		echo json_encode($arr_json);
	}

	function comboValueDollar()
	{
		$i = 0;

		$arr_json[$i]['id']		= "USD";
		$arr_json[$i]['text']	= "USD";
		$i++;
		$arr_json[$i]['id']		= "IDR";
		$arr_json[$i]['text']	= "IDR";

		echo json_encode($arr_json);
	}
	function comboValueDollar2()
	{
		$i = 0;

		$arr_json[$i]['id']		= "0";
		$arr_json[$i]['text']	= "USD";
		$i++;
		$arr_json[$i]['id']		= "1";
		$arr_json[$i]['text']	= "IDR";

		echo json_encode($arr_json);
	}

	function comboEquipCategori()
	{
		$this->load->model('EquipCategory');
		$equip_category = new EquipCategory();
		$equip_category->selectByParamsMonitoring(array());
		$i = 0;
		while ($equip_category->nextRow()) {
			$arr_json[$i]['id']		= $equip_category->getField("EC_ID");
			$arr_json[$i]['text']	= strtoupper($equip_category->getField("EC_NAME"));
			$i++;
		}
		echo json_encode($arr_json);
	}
	function comboEquipList()
	{
		$this->load->model('EquipmentList');
		$equipment_list = new EquipmentList();
		$equipment_list->selectByParamsMonitoring(array());
		$i = 0;
		while ($equipment_list->nextRow()) {
			$arr_json[$i]['id']		= $equipment_list->getField("EQUIP_ID");
			$arr_json[$i]['text']	= strtoupper($equipment_list->getField("EQUIP_NAME"));
			$i++;
		}
		echo json_encode($arr_json);
	}


	function comboKategori()
	{
		$i = 0;
		$arr_json[$i]['id']		= "COMPANY";
		$arr_json[$i]['text']	= "COMPANY";
		$i++;
		$arr_json[$i]['id']		= "VESSEL";
		$arr_json[$i]['text']	= "VESSEL";

		echo json_encode($arr_json);
	}

	function comboJenisAplikasi()
	{
		$i = 0;
		$arr_json[$i]['id']		= "URL";
		$arr_json[$i]['text']	= "URL";
		$i++;
		$arr_json[$i]['id']		= "MOBILEAPP";
		$arr_json[$i]['text']	= "MOBILEAPP";

		echo json_encode($arr_json);
	}


	function status()
	{
		$i = 0;
		$arr_json[$i]['id']		= "0";
		$arr_json[$i]['text']	= "Pending";
		$i++;
		$arr_json[$i]['id']		= "1";
		$arr_json[$i]['text']	= "Real";
		$i++;
		$arr_json[$i]['id']		= "2";
		$arr_json[$i]['text']	= "Cancel";

		echo json_encode($arr_json);
	}


	function aduan()
	{
		$i = 0;
		$arr_json[$i]['id']		= "BELUM";
		$arr_json[$i]['text']	= "BELUM DIBALAS";
		$i++;
		$arr_json[$i]['id']		= "SUDAH";
		$arr_json[$i]['text']	= "SUDAH DIBALAS";
		$i++;
		$arr_json[$i]['id']		= "SEMUA";
		$arr_json[$i]['text']	= "SEMUA";

		echo json_encode($arr_json);
	}

	function personil_combo()
	{
		$this->load->model("DokumenKualifikasi");
		$dokumen_kualifikasi = new DokumenKualifikasi();
		$dokumen_kualifikasi->selectByParamsMonitoringPersonil(array());
		$i = 0;
		while ($dokumen_kualifikasi->nextRow()) {
			$arr_json[$i]['id']		= $dokumen_kualifikasi->getField("DOCUMENT_ID");
			$arr_json[$i]['text']	= $dokumen_kualifikasi->getField("NAME") . ' - ' . $dokumen_kualifikasi->getField("POSITION");
			$i++;
		}
		echo json_encode($arr_json);
	}

	function validasi()
	{
		$i = 0;
		$arr_json[$i]['id']		= "validasi";
		$arr_json[$i]['text']	= "BELUM DIVALIDASI";
		$i++;
		$arr_json[$i]['id']		= "tolak";
		$arr_json[$i]['text']	= "DITOLAK";

		echo json_encode($arr_json);
	}


	function jenis_kelamin()
	{
		$i = 0;
		$arr_json[$i]['id']		= "";
		$arr_json[$i]['text']	= "SEMUA";
		$i++;
		$arr_json[$i]['id']		= "PRIA";
		$arr_json[$i]['text']	= "PRIA";
		$i++;
		$arr_json[$i]['id']		= "WANITA";
		$arr_json[$i]['text']	= "WANITA";


		echo json_encode($arr_json);
	}


	function golongan_darah()
	{
		$i = 0;
		$arr_json[$i]['id']		= "";
		$arr_json[$i]['text']	= "SEMUA";
		$i++;
		$arr_json[$i]['id']		= "A";
		$arr_json[$i]['text']	= "A";
		$i++;
		$arr_json[$i]['id']		= "B";
		$arr_json[$i]['text']	= "B";
		$i++;
		$arr_json[$i]['id']		= "AB";
		$arr_json[$i]['text']	= "AB";
		$i++;
		$arr_json[$i]['id']		= "O";
		$arr_json[$i]['text']	= "O";

		echo json_encode($arr_json);
	}


	function cabang()
	{
		$this->load->model("Master");
		$master = new Master();

		$master->selectCabang(array());
		$i = 0;
		while ($master->nextRow()) {
			$arr_json[$i]['id']		= $master->getField("CABANG_ID");
			$arr_json[$i]['text']	= $master->getField("NAMA");
			$i++;
		}

		echo json_encode($arr_json);
	}


	function comboStatus()
	{
		$i = 0;
		$arr_json[$i]['id']		= "1";
		$arr_json[$i]['text']	= "Lunas";
		$i++;
		$arr_json[$i]['id']		= "0";
		$arr_json[$i]['text']	= "Belum Lunas";
		$i++;

		echo json_encode($arr_json);
	}


	function comboStatus2()
	{
		$i = 0;
		$arr_json[$i]['id']		= "Lunas";
		$arr_json[$i]['text']	= "Lunas";
		$i++;
		$arr_json[$i]['id']		= "Belum Lunas";
		$arr_json[$i]['text']	= "Belum Lunas";
		$i++;

		echo json_encode($arr_json);
	}
}
