<?
/* *******************************************************************************************************
MODUL NAME 			: MTSN LAWANG
FILE NAME 			:
AUTHOR				:
VERSION				: 1.0
MODIFICATION DOC	:
DESCRIPTION			:
***************************************************************************************************** */

/***
 * Entity-base class untuk mengimplementasikan tabel kategori.
 *
 ***/
include_once(APPPATH . '/models/Entity.php');

class EquipmentList  extends Entity
{

	var $query;
	var $id;
	/**
	 * Class constructor.
	 **/
	function EquipmentList()
	{
		$this->Entity();
	}


	
	function insert()
	{
		$this->setField("EQUIP_ID", $this->getNextId("EQUIP_ID", "EQUIPMENT_LIST"));

		$str = "INSERT INTO EQUIPMENT_LIST (EQUIP_ID, EQUIP_PARENT_ID, EC_ID, EQUIP_NAME, EQUIP_QTY, EQUIP_ITEM,        EQUIP_SPEC, EQUIP_DATEIN, EQUIP_LASTCAL, EQUIP_NEXTCAL, EQUIP_CONDITION,        EQUIP_STORAGE, EQUIP_REMARKS, EQUIP_PRICE, PIC_PATH)VALUES (
		'" . $this->getField("EQUIP_ID") . "',
		'" . $this->getField("EQUIP_PARENT_ID") . "',
		'" . $this->getField("EC_ID") . "',
		'" . $this->getField("EQUIP_NAME") . "',
		'" . $this->getField("EQUIP_QTY") . "',
		'" . $this->getField("EQUIP_ITEM") . "',
		'" . $this->getField("EQUIP_SPEC") . "',
		" . $this->getField("EQUIP_DATEIN") . ",
		" . $this->getField("EQUIP_LASTCAL") . ",
		" . $this->getField("EQUIP_NEXTCAL") . ",
		'" . $this->getField("EQUIP_CONDITION") . "',
		'" . $this->getField("EQUIP_STORAGE") . "',
		'" . $this->getField("EQUIP_REMARKS") . "',
		'" . $this->getField("EQUIP_PRICE") . "',
		'" . $this->getField("PIC_PATH") . "' 
	)";

		$this->id = $this->getField("EQUIP_ID");
		$this->query = $str;
		// echo $str;
		// exit;
		return $this->execQuery($str);
	}

	function update()
	{
		$str = "
		UPDATE EQUIPMENT_LIST
		SET    
		EQUIP_ID ='" . $this->getField("EQUIP_ID") . "',
		EQUIP_PARENT_ID ='" . $this->getField("EQUIP_PARENT_ID") . "',
		EC_ID ='" . $this->getField("EC_ID") . "',
		EQUIP_NAME ='" . $this->getField("EQUIP_NAME") . "',
		EQUIP_QTY ='" . $this->getField("EQUIP_QTY") . "',
		EQUIP_ITEM ='" . $this->getField("EQUIP_ITEM") . "',
		EQUIP_SPEC ='" . $this->getField("EQUIP_SPEC") . "',
		EQUIP_DATEIN =" . $this->getField("EQUIP_DATEIN") . ",
		EQUIP_LASTCAL =" . $this->getField("EQUIP_LASTCAL") . ",
		EQUIP_NEXTCAL =" . $this->getField("EQUIP_NEXTCAL") . ",
		EQUIP_CONDITION ='" . $this->getField("EQUIP_CONDITION") . "',
		EQUIP_STORAGE ='" . $this->getField("EQUIP_STORAGE") . "',
		EQUIP_REMARKS ='" . $this->getField("EQUIP_REMARKS") . "',
		EQUIP_PRICE ='" . $this->getField("EQUIP_PRICE") . "',
		PIC_PATH ='" . $this->getField("PIC_PATH") . "' 
		WHERE EQUIP_ID= '" . $this->getField("EQUIP_ID") . "'";
		$this->query = $str;
		// echo $str;
		// exit;
		return $this->execQuery($str);
	}

	function update_path()
	{
		$str = "
			UPDATE EQUIPMENT_LIST
			SET    

			PIC_PATH ='" . $this->getField("PIC_PATH") . "' 
			WHERE EQUIP_ID= '" . $this->getField("EQUIP_ID") . "'";
		$this->query = $str;
		// echo $str;exit;
		return $this->execQuery($str);
	}

	function delete($statement = "")
	{
		$str = "DELETE FROM EQUIPMENT_LIST
			WHERE EQUIP_ID= '" . $this->getField("EQUIP_ID") . "'";
		$this->query = $str;
		// echo $str;exit();
		return $this->execQuery($str);
	}

	function selectByParamsMonitoring($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.EQUIP_ID ASC")
	{
		$str = "
			SELECT A.EQUIP_ID,A.EQUIP_PARENT_ID,A.EC_ID,A.EQUIP_NAME,A.EQUIP_QTY,A.EQUIP_ITEM,A.EQUIP_SPEC,A.EQUIP_DATEIN,A.EQUIP_LASTCAL,A.EQUIP_NEXTCAL,A.EQUIP_CONDITION,A.EQUIP_STORAGE,A.EQUIP_REMARKS,A.EQUIP_PRICE,A.PIC_PATH
			FROM EQUIPMENT_LIST A
			WHERE 1=1 ";
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = '$val'";
		}

		$str .= $statement . " " . $order;
		$this->query = $str;
		return $this->selectLimit($str, $limit, $from);
	}

	function selectByParamsMonitoringEquipment($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.EQUIP_ID ASC")
	{
		$str = "
			SELECT A.EQUIP_ID ID, EC.EC_NAME KATEGORI,  A.EQUIP_NAME AS NAME, A.EQUIP_ITEM ITEM, A.EQUIP_SPEC SPEC, A.EQUIP_CONDITION CONDITION,
			(A.EQUIP_QTY - COALESCE(B.EQUIP_QTY,0)) STOCK, A.PIC_PATH
			FROM EQUIPMENT_LIST A LEFT JOIN SO_EQUIP B  ON A.EQUIP_ID = B.EQUIP_ID LEFT JOIN EQUIP_CATEGORY EC ON A.EC_ID = EC.EC_ID
			WHERE 1=1 ";
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = '$val'";
		}

		$str .= $statement . " " . $order;
		$this->query = $str;
		return $this->selectLimit($str, $limit, $from);
	}

	function selectByParamsMonitoringEquipmentProd($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.EQUIP_ID ASC")
	{
		$str = "SELECT A.EQUIP_ID ,
				B.EC_ID,
				B.EC_NAME AS CATEGORY,
				A.EQUIP_NAME ,
				(SELECT C.EQUIP_NAME FROM EQUIPMENT_LIST C WHERE A.EQUIP_PARENT_ID = C.EQUIP_ID) AS PART_OF_EQUIPMENT,
				A.EQUIP_SPEC AS SPECIFICATION,
				A.EQUIP_QTY AS QUANTITY,
				A.EQUIP_ITEM AS ITEM,
				TO_CHAR(A.EQUIP_DATEIN, 'DAY,MONTH DD YYYY') AS INCOMING_DATE,
				TO_CHAR(A.EQUIP_LASTCAL, 'DAY,MONTH DD YYYY') AS LAST_CALIBRATION,
				TO_CHAR(A.EQUIP_NEXTCAL, 'DAY,MONTH DD YYYY') AS NEXT_CALIBRATION,
				(SELECT COUNT(C.EQUIP_ID) FROM EQUIPMENT_LIST C WHERE C.EQUIP_PARENT_ID = A.EQUIP_ID) AS QTY_DETAIL_EQUIPMENT,
				A.EQUIP_CONDITION AS CONDITION,
				A.EQUIP_STORAGE AS STORAGE,
				A.EQUIP_PRICE AS PRICE,
				A.EQUIP_REMARKS AS REMARKS
				FROM EQUIPMENT_LIST A, EQUIP_CATEGORY B
				WHERE A.EC_ID = B.EC_ID ";
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = '$val'";
		}

		$str .= $statement . " " . $order;
		$this->query = $str;
		return $this->selectLimit($str, $limit, $from);
	}


	function selectByParamsMonitoringEquipmentProdCetakPdf($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.EQUIP_ID ASC")
	{
		$str = "SELECT A.EQUIP_ID ,
				B.EC_ID,
				B.EC_NAME AS CATEGORY,
				A.EQUIP_NAME ,
				(SELECT C.EQUIP_NAME FROM EQUIPMENT_LIST C WHERE A.EQUIP_PARENT_ID = C.EQUIP_ID) AS PART_OF_EQUIPMENT,
				A.EQUIP_SPEC AS SPECIFICATION,
				A.EQUIP_QTY AS QUANTITY,
				A.EQUIP_ITEM AS ITEM,
				TO_CHAR(A.EQUIP_DATEIN, 'DAY,MONTH DD YYYY') AS INCOMING_DATE,
				TO_CHAR(A.EQUIP_LASTCAL, 'DAY,MONTH DD YYYY') AS LAST_CALIBRATION,
				TO_CHAR(A.EQUIP_NEXTCAL, 'DAY,MONTH DD YYYY') AS NEXT_CALIBRATION,
				(SELECT COUNT(C.EQUIP_ID) FROM EQUIPMENT_LIST C WHERE C.EQUIP_PARENT_ID = A.EQUIP_ID) AS QTY_DETAIL_EQUIPMENT,
				A.EQUIP_CONDITION AS CONDITION,
				A.EQUIP_STORAGE AS STORAGE,
				A.EQUIP_PRICE AS PRICE,
				A.EQUIP_REMARKS AS REMARKS
				FROM EQUIPMENT_LIST A, EQUIP_CATEGORY B
				WHERE A.EC_ID = B.EC_ID ";
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = '$val'";
		}

		$str .= $statement . " " . $order;
		$this->query = $str;
		return $this->selectLimit($str, $limit, $from);
	}

	function getCountByParamsMonitoringEquipment($paramsArray = array(), $statement = "")
	{
		$str = "SELECT COUNT(1) AS ROWCOUNT FROM EQUIPMENT_LIST A 
			LEFT JOIN SO_EQUIP B  ON A.EQUIP_ID = B.EQUIP_ID LEFT JOIN EQUIP_CATEGORY EC ON A.EC_ID = EC.EC_ID
			WHERE 1=1 " . $statement;
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = 	'$val' ";
		}
		$this->query = $str;
		$this->select($str);
		if ($this->firstRow())
			return $this->getField("ROWCOUNT");
		else
			return 0;
	}


	function getCountByParamsMonitoring($paramsArray = array(), $statement = "")
	{
		$str = "SELECT COUNT(1) AS ROWCOUNT FROM EQUIPMENT_LIST A WHERE 1=1 " . $statement;
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = 	'$val' ";
		}
		$this->query = $str;
		$this->select($str);
		if ($this->firstRow())
			return $this->getField("ROWCOUNT");
		else
			return 0;
	}

	function getCountByParamsTotalEquipment($paramsArray = array(), $statement = "")
	{
		$str = " SELECT COUNT(*) AS ROWCOUNT FROM EQUIPMENT_LIST WHERE (EQUIP_NEXTCAL < NOW() OR (NOW() BETWEEN (EQUIP_NEXTCAL + INTERVAL '2 MONTH') AND (EQUIP_NEXTCAL + INTERVAL '1 DAY'))); " . $statement;
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key =    '$val' ";
		}
		$this->query = $str;
		$this->select($str);
		if ($this->firstRow())
			return $this->getField("ROWCOUNT");
		else
			return 0;
	}
}
