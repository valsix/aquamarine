<?
/* *******************************************************************************************************
MODUL NAME 			: IMASYS
FILE NAME 			: 
AUTHOR				: 
VERSION				: 1.0
MODIFICATION DOC	:
DESCRIPTION			: 
***************************************************************************************************** */

/***
 * Entity-base class untuk mengimplementasikan tabel PANGKAT.
 * 
 ***/
include_once("Entity.php");

class Vessel  extends Entity
{

    var $query;
    var $id;
    /**
     * Class constructor.
     **/
    function Vessel()
    {
        $this->Entity();
    }

    function insert()
    {
        $this->setField("VESSEL_ID", $this->getNextId("VESSEL_ID", "VESSEL"));

        $str = "INSERT INTO VESSEL (VESSEL_ID, COMPANY_ID, NAME, DIMENSION_L, DIMENSION_B, DIMENSION_D,TYPE_VESSEL, CLASS_VESSEL, TYPE_SURVEY, LOCATION_SURVEY, CONTACT_PERSON,        VALUE_SURVEY, SURVEYOR_NAME, SURVEYOR_PHONE, CURRENCY,CURRENCY_VALUE)VALUES (
            '" . $this->getField("VESSEL_ID") . "',
            '" . $this->getField("COMPANY_ID") . "',
            '" . $this->getField("NAME") . "',
            '" . $this->getField("DIMENSION_L") . "',
            '" . $this->getField("DIMENSION_B") . "',
            '" . $this->getField("DIMENSION_D") . "',
            '" . $this->getField("TYPE_VESSEL") . "',
            '" . $this->getField("CLASS_VESSEL") . "',
            '" . $this->getField("TYPE_SURVEY") . "',
            '" . $this->getField("LOCATION_SURVEY") . "',
            '" . $this->getField("CONTACT_PERSON") . "',
            '" . $this->getField("VALUE_SURVEY") . "',
            '" . $this->getField("SURVEYOR_NAME") . "',
            '" . $this->getField("SURVEYOR_PHONE") . "',
            '" . $this->getField("CURRENCY") . "',
            '" . $this->getField("CURRENCY_VALUE") . "'
         
    )";

        $this->id = $this->getField("VESSEL_ID");
        $this->query = $str;
        // echo $str;exit();
        return $this->execQuery($str);
    }

    function insert_offer()
    {
        $this->setField("VESSEL_ID", $this->getNextId("VESSEL_ID", "VESSEL"));

        $str = "INSERT INTO VESSEL (VESSEL_ID, COMPANY_ID, NAME,TYPE_VESSEL, CLASS_VESSEL)VALUES (
        '" . $this->getField("VESSEL_ID") . "',
        '" . $this->getField("COMPANY_ID") . "',
        '" . $this->getField("NAME") . "',
        '" . $this->getField("TYPE_VESSEL") . "',
        '" . $this->getField("CLASS_VESSEL") . "'
    )";

        $this->id = $this->getField("VESSEL_ID");
        $this->query = $str;
        // echo $str;exit();
        return $this->execQuery($str);
    }

    function update_offer()
    {
        $str = "UPDATE VESSEL
                SET    
                VESSEL_ID ='" . $this->getField("VESSEL_ID") . "',
                COMPANY_ID ='" . $this->getField("COMPANY_ID") . "',
                NAME ='" . $this->getField("NAME") . "',
               
                TYPE_VESSEL ='" . $this->getField("TYPE_VESSEL") . "',
                CLASS_VESSEL ='" . $this->getField("CLASS_VESSEL") . "'
               
        
        WHERE VESSEL_ID= '" . $this->getField("VESSEL_ID") . "'";
        $this->query = $str;
        // echo $str;exit;
        return $this->execQuery($str);
    }

    function update()
    {
        $str = "UPDATE VESSEL
                SET    
                VESSEL_ID ='" . $this->getField("VESSEL_ID") . "',
                COMPANY_ID ='" . $this->getField("COMPANY_ID") . "',
                NAME ='" . $this->getField("NAME") . "',
                DIMENSION_L ='" . $this->getField("DIMENSION_L") . "',
                DIMENSION_B ='" . $this->getField("DIMENSION_B") . "',
                DIMENSION_D ='" . $this->getField("DIMENSION_D") . "',
                TYPE_VESSEL ='" . $this->getField("TYPE_VESSEL") . "',
                CLASS_VESSEL ='" . $this->getField("CLASS_VESSEL") . "',
                TYPE_SURVEY ='" . $this->getField("TYPE_SURVEY") . "',
                LOCATION_SURVEY ='" . $this->getField("LOCATION_SURVEY") . "',
                CONTACT_PERSON ='" . $this->getField("CONTACT_PERSON") . "',
                VALUE_SURVEY ='" . $this->getField("VALUE_SURVEY") . "',
                SURVEYOR_NAME ='" . $this->getField("SURVEYOR_NAME") . "',
                SURVEYOR_PHONE ='" . $this->getField("SURVEYOR_PHONE") . "',
                CURRENCY ='" . $this->getField("CURRENCY") . "', 
                CURRENCY_VALUE ='" . $this->getField("CURRENCY_VALUE") . "' 
        
        WHERE VESSEL_ID= '" . $this->getField("VESSEL_ID") . "'";
        $this->query = $str;
        // echo $str;exit;
        return $this->execQuery($str);
    }

       function deleteParent(){
        $str = "DELETE FROM VESSEL
        WHERE COMPANY_ID= '" . $this->getField("COMPANY_ID") . "'";
        $this->query = $str;
        // echo $str;exit();
        return $this->execQuery($str);

       } 

    function delete($statement = "")
    {
        $str = "DELETE FROM VESSEL
        WHERE VESSEL_ID= '" . $this->getField("VESSEL_ID") . "'";
        $this->query = $str;
        // echo $str;exit();
        return $this->execQuery($str);
    }

    function selectByParamsMonitoring($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.VESSEL_ID ASC")
    {
        $str = "SELECT A.VESSEL_ID,A.COMPANY_ID,A.NAME,A.DIMENSION_L,A.DIMENSION_B,A.DIMENSION_D,A.TYPE_VESSEL,A.CLASS_VESSEL,A.TYPE_SURVEY,A.LOCATION_SURVEY,A.CONTACT_PERSON,A.VALUE_SURVEY,A.SURVEYOR_NAME,A.SURVEYOR_PHONE,A.CURRENCY,A.CURRENCY_VALUE
        FROM VESSEL A
        WHERE 1=1 ";
        while (list($key, $val) = each($paramsArray)) {
            $str .= " AND $key = '$val'";
        }

        $str .= $statement . " " . $order;
        $this->query = $str;
        // echo $str;
        // exit;
        return $this->selectLimit($str, $limit, $from);
    }

    function getCountByParamsMonitoring($paramsArray = array(), $statement = "")
    {
        $str = "SELECT COUNT(1) AS ROWCOUNT FROM VESSEL A WHERE 1=1 " . $statement;
        while (list($key, $val) = each($paramsArray)) {
            $str .= " AND $key =    '$val' ";
        }
        $this->query = $str;
        $this->select($str);
        if ($this->firstRow())
            return $this->getField("ROWCOUNT");
        else
            return 0;
    }
}
