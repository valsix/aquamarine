<?
/* *******************************************************************************************************
MODUL NAME 			: IMASYS
FILE NAME 			: 
AUTHOR				: 
VERSION				: 1.0
MODIFICATION DOC	:
DESCRIPTION			: 
***************************************************************************************************** */

/***
 * Entity-base class untuk mengimplementasikan tabel PANGKAT.
 * 
 ***/
include_once("Entity.php");

class PmsEquipDetil   extends Entity
{

    var $query;
    var $id;
    /**
     * Class constructor.
     **/
    function PmsEquipDetil()
    {
        $this->Entity();
    }

    function insert()
    {
        $this->setField("PMS_DETIL_ID", $this->getNextId("PMS_DETIL_ID","PMS_EQUIP_DETIL")); 

        $str = "INSERT INTO PMS_EQUIP_DETIL (PMS_DETIL_ID, PMS_ID, NAME, TIME_TEST, COMPETENT, DATE_LASTCAL,        DATE_NEXTCAL, EQUIP_CONDITION, PIC_PATH, KETERANGAN, NO_SPAREPART)VALUES (
        '".$this->getField("PMS_DETIL_ID")."',
        '".$this->getField("PMS_ID")."',
        '".$this->getField("NAME")."',
        '".$this->getField("TIME_TEST")."',
        '".$this->getField("COMPETENT")."',
        ".$this->getField("DATE_LASTCAL").",
        ".$this->getField("DATE_NEXTCAL").",
        '".$this->getField("EQUIP_CONDITION")."',
        '".$this->getField("PIC_PATH")."',
        '".$this->getField("KETERANGAN")."',
        '".$this->getField("NO_SPAREPART")."' 
    )";

    $this->id = $this->getField("PMS_DETIL_ID");
    $this->query= $str;
        // echo $str;exit();
    return $this->execQuery($str);
    }

    function update()
    {
        $str = "
        UPDATE PMS_EQUIP_DETIL
        SET    
        PMS_DETIL_ID ='".$this->getField("PMS_DETIL_ID")."',
        PMS_ID ='".$this->getField("PMS_ID")."',
        NAME ='".$this->getField("NAME")."',
        TIME_TEST ='".$this->getField("TIME_TEST")."',
        COMPETENT ='".$this->getField("COMPETENT")."',
        DATE_LASTCAL =".$this->getField("DATE_LASTCAL").",
        DATE_NEXTCAL =".$this->getField("DATE_NEXTCAL").",
        EQUIP_CONDITION ='".$this->getField("EQUIP_CONDITION")."',
        PIC_PATH ='".$this->getField("PIC_PATH")."',
        KETERANGAN ='".$this->getField("KETERANGAN")."',
        NO_SPAREPART ='".$this->getField("NO_SPAREPART")."' 
        WHERE PMS_DETIL_ID= '".$this->getField("PMS_DETIL_ID")."'";
        $this->query = $str;
          // echo $str;exit;
        return $this->execQuery($str);
    }

    function update_path(){
        $str = "
        UPDATE PMS_EQUIP_DETIL
        SET    
        PIC_PATH ='".$this->getField("PIC_PATH")."'
      
        WHERE PMS_DETIL_ID= '".$this->getField("PMS_DETIL_ID")."'";
        $this->query = $str;
          // echo $str;exit;
        return $this->execQuery($str);

    }

    function delete($statement= "")
    {
        $str = "DELETE FROM PMS_EQUIP_DETIL
        WHERE PMS_DETIL_ID= '".$this->getField("PMS_DETIL_ID")."'"; 
        $this->query = $str;
          // echo $str;exit();
        return $this->execQuery($str);
    }

    function selectByParamsMonitoring($paramsArray=array(),$limit=-1,$from=-1, $statement="", $order="ORDER BY A.PMS_DETIL_ID ASC")
    {
        $str = "
        SELECT A.PMS_DETIL_ID,A.PMS_ID,A.NAME,A.TIME_TEST,A.COMPETENT,A.DATE_LASTCAL,A.DATE_NEXTCAL,A.EQUIP_CONDITION,A.PIC_PATH,A.KETERANGAN,A.NO_SPAREPART,to_char(A.DATE_LASTCAL,'dd-mm-yyyy') as LAST,to_char(A.DATE_NEXTCAL,'dd-mm-yyyy') as NEXT
        FROM PMS_EQUIP_DETIL A
        WHERE 1=1 ";
        while(list($key,$val) = each($paramsArray))
        {
            $str .= " AND $key = '$val'";
        }

        $str .= $statement." ".$order;
        $this->query = $str;
        return $this->selectLimit($str,$limit,$from); 
    }


    function getCountByParamsMonitoring($paramsArray=array(), $statement="")
    {
        $str = "SELECT COUNT(1) AS ROWCOUNT FROM PMS_EQUIP_DETIL A WHERE 1=1 ".$statement;
        while(list($key,$val)=each($paramsArray))
        {
            $str .= " AND $key =    '$val' ";
        }
        $this->query = $str;
        $this->select($str); 
        if($this->firstRow()) 
            return $this->getField("ROWCOUNT"); 
        else 
            return 0; 
    }   

    function getCountByParamsTotalEquipDetail($paramsArray=array(), $statement="")
        {
            $str = " SELECT COUNT(*) AS ROWCOUNT FROM PMS_EQUIP_DETIL WHERE (DATE_NEXTCAL < NOW() OR (NOW() BETWEEN (DATE_NEXTCAL + INTERVAL '14 DAY') AND (DATE_NEXTCAL + INTERVAL '1 DAY'))); ".$statement;
            while(list($key,$val)=each($paramsArray))
            {
                $str .= " AND $key =    '$val' ";
            }
            $this->query = $str;
            $this->select($str); 
            if($this->firstRow()) 
                return $this->getField("ROWCOUNT"); 
            else 
                return 0; 
        }
}
