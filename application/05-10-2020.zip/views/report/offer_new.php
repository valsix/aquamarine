<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$this->load->model("Offer");
$this->load->model("Company");
$this->load->model("Vessel");

$reqId = $this->input->get('reqId');
$offer = new Offer();

$offer->selectByParamsMonitoring(array("OFFER_ID" => $reqId));
    // echo  $offer->query;exit;
    $offer->firstRow();
    $reqOfferId          = $offer->getField("OFFER_ID");
    $reqDocumentId       = $offer->getField("DOCUMENT_ID");
    $reqDocumentPerson   = $offer->getField("DOCUMENT_PERSON");
    $reqDestination      = $offer->getField("DESTINATION");
    $reqDateOfService    = $offer->getField("DATE_OF_SERVICE");
    $reqTypeOfService    = $offer->getField("TYPE_OF_SERVICE");
    $reqScopeOfWork      = $offer->getField("SCOPE_OF_WORK");
    $reqTermAndCondition = $offer->getField("TERM_AND_CONDITION");
    $reqPaymentMethod    = $offer->getField("PAYMENT_METHOD");
    $reqTotalPrice       = $offer->getField("TOTAL_PRICE");
    $reqTotalPriceWord   = $offer->getField("TOTAL_PRICE_WORD");
    $reqStatus           = $offer->getField("STATUS");
    $reqReason           = $offer->getField("REASON");
    $reqNoOrder          = $offer->getField("NO_ORDER");
    $reqDateOfOrder      = $offer->getField("DATE_OF_ORDER");
    $reqCompanyName      = $offer->getField("COMPANY_NAME");
    $reqAddress          = $offer->getField("ADDRESS");
    $reqFaximile         = $offer->getField("FAXIMILE");
    $reqEmail            = $offer->getField("EMAIL");
    $reqTelephone        = $offer->getField("TELEPHONE");
    $reqHp               = $offer->getField("HP");
    $reqVesselName       = $offer->getField("VESSEL_NAME");
    $reqTypeOfVessel     = $offer->getField("TYPE_OF_VESSEL");
    $reqClassOfVessel    = $offer->getField("CLASS_OF_VESSEL");
    $reqMaker            = $offer->getField("MAKER");

    $reqIssueDate       = $offer->getField("ISSUE_DATE");
    $reqPreparedBy      = $offer->getField("PREPARED_BY");
    $reqReviewedBy      = $offer->getField("REVIEWED_BY");
    $reqApprovedBy      = $offer->getField("APPROVED_BY");
    $reqIssuePurpose    = $offer->getField("ISSUE_PURPOSE");
    $reqSubject         = $offer->getField("SUBJECT");
    $reqGeneralService  = $offer->getField("GENERAL_SERVICE");
    $reqGeneralServiceDetail= $offer->getField("GENERAL_SERVICE_DETAIL");
    $reqProposalValidaty= $offer->getField("PROPOSAL_VALIDATY");
    $reqTechicalScope   = $offer->getField("TECHICAL_SCOPE");
    $reqTechicalSupport = $offer->getField("TECHICAL_SUPPORT");
    $reqCommercialSupport= $offer->getField("COMMERCIAL_SUPPORT");

    $reqRevHistory= $offer->getField("REV_HISTORY");

    $reqTechicalScope 	= json_decode($reqTechicalScope,true);
    $reqTechicalSupport = json_decode($reqTechicalSupport,true);
    $reqCommercialSupport = json_decode($reqCommercialSupport,true);
    $reqRevHistory        = json_decode($reqRevHistory,true);

?>
<h1 style="font-family: Times New Roman;font-size: 18px;text-align: center;"> TECHNICAL AND COMMERCIAL PROPOSAL </h1>	
<div style="padding: 30px">


<table style="width: 100%;border-collapse: 1px solid black;font-size: 12px;font-family: Trebuchet MS">
	<tr>
		<td style="width: 15%"> Doc. No.</td>
		<td style="width: 2%">: </td>
		<td> <?=$reqNoOrder?></td>
	</tr>
	<tr>
		<td> Date.</td>
		<td>: </td>
		<td><?=$reqDateOfOrder?></td>
	</tr>
	<tr>
		<td> Prepered For.</td>
		<td>: </td>
		<td> <?=$reqDocumentPerson?></td>
	</tr>

	<tr>
		<td> Client</td>
		<td>: </td>
		<td> <?=$reqCompanyName?></td>
	</tr>

	
	<tr>
		<td> Subject</td>
		<td>: </td>
		<td> <?=$reqSubject?></td>
	</tr>
	
</table>

<?
// print_r($reqRevHistory);
?>

<br>
<br>
<table style="width: 100%;font-size: 12px;font-family: Trebuchet MS;border-collapse: 1px solid balck" border="1">
	<tr>
		<td style="background-color: #D9D9D9" align="center"> <b>Rev</b> </td>
		<td style="background-color: #D9D9D9" align="center"> <b>Isssue Date</b></td>
		<td style="background-color: #D9D9D9" align="center" > <b>Prepared By</b></td>
		<td style="background-color: #D9D9D9" align="center"> <b>Reviewed By</b> </td>
		<td style="background-color: #D9D9D9" align="center"> <b>Approved By</b></td>
		<td style="background-color: #D9D9D9" align="center"> <b>Issue Purpose </b></td>
	</tr>
	<?
	for($i=0;$i<count($reqRevHistory);$i++){
	?>
	<tr>
		<td align="center"> <?=$i?> </td>
		<td style="padding-left: 10px"> <?=$reqRevHistory[$i]['ISSUE_DATE']?></td>
		<td style="padding-left: 10px"> <?=$reqRevHistory[$i]['PREPARED_BY']?></td>
		<td style="padding-left: 10px"> <?=$reqRevHistory[$i]['REVIEWED_BY']?> </td>
		<td style="padding-left: 10px"	> <?= $reqRevHistory[$i]['APPROVED_BY']?></td>
		<td style="padding-left: 10px"> <?=$reqRevHistory[$i]['ISSUE_PURPOSE']?></td>
	</tr>
	<?
	}
	?>
</table>

<div style="font-size:  12px;font-family: Trebuchet MS;text-align: justify-all;">
<p> Dear <?=$reqDocumentPerson?> </p>

 with refer to <b><?=$reqCompanyName?> </b> by Email dd: <b><?=$reqDateOfOrder?> </b> pertaining to plan for <b> <?=$reqGeneralService?></b> due perusal of into received, we, PT Aquamarine Divindo Inspection ("CONTRACTOR"), herewith submit out Technical & Commercial Proposal <b> <?=$reqCompanyName?></b> (" Client"), as follows :  
</div>
<table style="font-size:  12px;font-family: Trebuchet MS;text-align: justify-all;width: 100%">
	<tr>
		<td style="width: 15%;pa"> Client </td>
		<td style="width: 2%"> : </td>
		<td>PT Waruna Nusa Sentana </td>

	</tr>
	<tr>
		<td> General Services </td>
		<td> : </td>
		<td>Underwater Survey / UWILD </td>
	</tr>
	<tr>
		<td> Detail of Services </td>
		<td> : </td>
		<td>Underwater Survey / UWILD of MT  Makbrok </td>
	</tr>
	<tr>
		<td> Location </td>
		<td> : </td>
		<td> Tanjung Priok </td>
	</tr>
	<tr>
		<td> Date of Services </td>
		<td> : </td>
		<td> Circa, <?=getFormattedDate($reqDateOfService)?> (will mutualy agreed) </td>
	</tr>
	<tr>
		<td> Price of UWS </td>
		<td> : </td>
		<?
		 $reqTotalPrice = explode(" ", $reqTotalPrice);
		?>
		<td><?=$reqTotalPrice[0]?> <?=currencyToPage2($reqTotalPrice[1])?>,00/ Vessel <br>
		( ## Say <?=$reqTotalPriceWord?> ##)</td>
	</tr>
	<tr>
		<td> Payment Menthod </td>
		<td> : </td>
		<td> <?=$reqPaymentMethod?>
		 </td>
	</tr>
	<tr>
		<td> Proposal Validaty </td>
		<td> : </td>
		<td><?=$reqProposalValidaty?> Days as of date of submission
		 </td>
	</tr>
</table>


<br>
<b> Term and Condition </b>
<br>
<div style="margin-left: 20px;font-size: 12px;font-family: Trebuchet MS">
	<br>
<b> A.Technical Scope </b>
	<table style="width: 100%;border-collapse: 1px solid black;font-family: Trebuchet MS;font-size: 12px; " border="1"  >
		<?
		$this->load->model("TechicalScope");
		$techical_scope = new TechicalScope();
		$techical_scope->selectByParamsMonitoring(array());
		?>
		<thead>
		<tr>
			<th style="width: 5%; " align="center"> No</th>
			<th style="width: 50%"> Description</th>
			<th style="width: 10%"> Include</th>
			<th style="width: 10%"> Exclude</th>
			<th style="width: 25%"> Remark</th>
		</tr>
		</thead>
		<tbody>
			<?
			$no=1;
			while ( $techical_scope->nextRow()) {
				$style='style="padding-left: 10px"';
				# code...
				$remark = $reqTechicalScope[$techical_scope->getField('ID')]['REMARK'];
				$inc_check = $reqTechicalScope[$techical_scope->getField('ID')]['INC'];
				$enc_check = $reqTechicalScope[$techical_scope->getField('ID')]['ENC'];
				 if(!empty($inc_check)){$inc_check='<img src="images/centang.png" style="width: 10px;height: 10px">';}
             	 if(!empty($enc_check)){$enc_check='<img src="images/centang.png" style="width: 10px;height: 10px">';}

             	 $techical_scope2 = new TechicalScope();
             	 $total=	 $techical_scope2->getCountByParamsMonitoring(array("A.ID"=>$techical_scope->getField('PARENT_ID')));
             	 $text_no=$no;
             	 if($total!=0){
             	 	$style='style="padding-left: 25px"';
             	 	 $text_no = '';
             	 
             	 }else{
             	 		$no++;
             	 }
			
			?>
			<tr>
				<td align="center"><?=$text_no?> </td>
				<td align="left" <?=$style?> ><?=$techical_scope->getField('NAMA')?> </td>
				<td align="center"><?=$inc_check?></td>
				<td align="center"><?=$enc_check?> </td>
				<td align="center"><?=$remark?> </td>

			</tr>
			<?
			
			}
			?>
		</tbody>


	</table>
	<br>
	<br>
	<b> B.Technical Support </b>
	<table style="width: 100%;border-collapse: 1px solid black;font-family: Trebuchet MS;font-size: 12px;" border='1'>
		<?
		$this->load->model("TechicalSupport");
		$techical_scope = new TechicalSupport();
		$techical_scope->selectByParamsMonitoring(array());
		?>
		<thead>
		<tr>
			<th style="width: 5%" align="center"> No</th>
			<th style="width: 50%"> Description</th>
			<th style="width: 10%"> Include</th>
			<th style="width: 10%"> Exclude</th>
			<th style="width: 25%"> Remark</th>
		</tr>
		</thead>
		<tbody>
			<?
			$no=1;
			while ( $techical_scope->nextRow()) {
				$style='style="padding-left: 10px"';
				# code...
				$remark = $reqTechicalSupport[$techical_scope->getField('ID')]['REMARK'];
				$inc_check = $reqTechicalSupport[$techical_scope->getField('ID')]['INC'];
				$enc_check = $reqTechicalSupport[$techical_scope->getField('ID')]['ENC'];
				 if(!empty($inc_check)){$inc_check='<img src="images/centang.png" style="width: 10px;height: 10px">';}
             	 if(!empty($enc_check)){$enc_check='<img src="images/centang.png" style="width: 10px;height: 10px">';}

             	 $techical_scope2 = new TechicalSupport();
             	 $total=	 $techical_scope2->getCountByParamsMonitoring(array("A.ID"=>$techical_scope->getField('PARENT_ID')));
             	 $text_no=$no;
             	 if($total!=0){
             	 	$style='style="padding-left: 25px"';
             	 	 $text_no = '';
             	 
             	 }else{
             	 		$no++;
             	 }
			
			?>
			<tr>
				<td align="center"><?=$text_no?> </td>
				<td align="left" <?=$style?> ><?=$techical_scope->getField('NAMA')?> </td>
				<td align="center"><?=$inc_check?></td>
				<td align="center"><?=$enc_check?> </td>
				<td align="center"><?=$remark?> </td>

			</tr>
			<?
			
			}
			?>
		</tbody>


	</table>
	<br>
	<br>
	
	<b> C.Commercial Support </b>
	<table style="width: 100%;border-collapse: 1px solid black;font-family: Trebuchet MS;font-size: 12px;" border='1'>
		<?
		$this->load->model("CommercialSupport");
		$techical_scope = new CommercialSupport();
		$techical_scope->selectByParamsMonitoring(array());
		?>
		<thead>
		<tr>
			<th style="width: 5%" align="center"> No</th>
			<th style="width: 50%"> Description</th>
			<th style="width: 10%"> Include</th>
			<th style="width: 10%"> Exclude</th>
			<th style="width: 25%"> Remark</th>
		</tr>
		</thead>
		<tbody>
			<?
			$no=1;
			while ( $techical_scope->nextRow()) {
				$style='style="padding-left: 10px"';
				# code...
				$remark = $reqCommercialSupport[$techical_scope->getField('ID')]['REMARK'];
				$inc_check = $reqCommercialSupport[$techical_scope->getField('ID')]['INC'];
				$enc_check = $reqCommercialSupport[$techical_scope->getField('ID')]['ENC'];
				 if(!empty($inc_check)){$inc_check='<img src="images/centang.png" style="width: 10px;height: 10px">';}
             	 if(!empty($enc_check)){$enc_check='<img src="images/centang.png" style="width: 10px;height: 10px">';}

             	 $techical_scope2 = new CommercialSupport();
             	 $total=	 $techical_scope2->getCountByParamsMonitoring(array("A.ID"=>$techical_scope->getField('PARENT_ID')));
             	 $text_no=$no;
             	 if($total!=0){
             	 	$style='style="padding-left: 25px"';
             	 	 $text_no = '';
             	 
             	 }else{
             	 		$no++;
             	 }
			
			?>
			<tr>
				<td align="center"><?=$text_no?> </td>
				<td align="left" <?=$style?> ><?=$techical_scope->getField('NAMA')?> </td>
				<td align="center"><?=$inc_check?></td>
				<td align="center"><?=$enc_check?> </td>
				<td align="center"><?=$remark?> </td>

			</tr>
			<?
			
			}
			?>
		</tbody>


	</table>
	</div>


</div>
<br>

<p style="font-size: 12px; font-family: Trebuchet MS;text-align: justify;">
Hence, Shall there be any questions pertaining to above,feel free to contact us at any of your convenience time. Shall you find it suit to your immediate SO Accordingly
</p>

<br>
<br>

Best Regart,
<br>

<img src="uploads/offering/<?= $reqId ?>/offering<?= $reqMaker ?>.png">
<br>
<u><?= ucfirst( strtolower($reqMaker)) ?></u><br>
<b><em>Marketing </em></b>
</div>