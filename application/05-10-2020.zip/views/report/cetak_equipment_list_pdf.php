<base href="<?= base_url(); ?>" />

<?

include_once("functions/string.func.php");
include_once("functions/date.func.php");

require('libraries/fpdf182/pdf.php');

$reqCariIdNumber = $this->input->post("reqCariIdNumber");
$reqCariCondition = $this->input->post("reqCariCondition");
$reqCariCategori = $this->input->post("reqCariCategori");
$reqCariStorage = $this->input->post("reqCariStorage");
$reqCariCompanyName = $this->input->post("reqCariCompanyName");
$reqCariIncomingDateFrom = $this->input->post("reqCariIncomingDateFrom");
$reqCariIncomingDateTo = $this->input->post("reqCariIncomingDateTo");
$reqCariItemFrom = $this->input->post("reqCariItemFrom");
$reqCariItemTo = $this->input->post("reqCariItemTo");
$reqCariLastCalibrationFrom = $this->input->post("reqCariLastCalibrationFrom");
$reqCariLastCalibrationTo = $this->input->post("reqCariLastCalibrationTo");
$reqCariQuantity = $this->input->post("reqCariQuantity");
$reqCariNextCalibrationFrom = $this->input->post("reqCariNextCalibrationFrom");
$reqCariNextCalibrationTo = $this->input->post("reqCariNextCalibrationTo");
$reqCariSpesification = $this->input->post("reqCariSpesification");


if (!empty($reqCariIdNumber)) {

    $statement_privacy  = " AND A.EQUIP_ID = '" . $reqCariIdNumber . "' ";
}
if (!empty($reqCariCondition)) {

    $statement_privacy  .= " AND A.EQUIP_CONDITION LIKE '%" . $reqCariCondition . "%' ";
}
if (!empty($reqCariCategori)) {

    $statement_privacy  .= " AND b.EC_NAME ='" . $reqCariCategori . "' ";
}
if (!empty($reqCariStorage)) {

    $statement_privacy  .= " AND a.equip_storage LIKE '%" . $reqCariStorage . "%' ";
}
if (!empty($reqCariCompanyName)) {

    $statement_privacy  .= " AND A.EQUIP_NAME LIKE '%" . $reqCariCompanyName . "%' ";
}
if (!empty($reqCariIncomingDateFrom) && !empty($reqCariIncomingDateTo)) {

    $statement_privacy  .= " AND A.EQUIP_DATEIN BETWEEN  TO_CHAR(" . $reqCariIncomingDateFrom . ",'dd-mm-yyyy')  AND TO_CHAR(" . $reqCariIncomingDateFrom . ",'dd-mm-yyyy') ";
}

if (!empty($reqCariItemFrom) && !empty($reqCariItemTo)) {


    $statement_privacy  .= " AND A.EQUIP_QTY BETWEEN " . $reqCariItemFrom . " AND " . $reqCariItemTo;
}

if (!empty($reqCariLastCalibrationFrom) && !empty($reqCariLastCalibrationTo)) {

    $statement_privacy  .= " AND A.EQUIP_LASTCAL BETWEEN TO_CHAR(" . $reqCariLastCalibrationFrom . ",'dd-mm-yyyy') AND TO_CHAR(" . $reqCariLastCalibrationTo . ",'dd-mm-yyyy') ";
}

if (!empty($reqCariQuantity)) {

    $statement_privacy  .= " AND a.equip_item LIKE '%" . $reqCariQuantity . "%' ";
}
if (!empty($reqCariNextCalibrationFrom) && !empty($reqCariNextCalibrationTo)) {
    $statement_privacy  .= " AND A.EQUIP_NEXTCAL BETWEEN TO_CHAR(" . $reqCariNextCalibrationFrom . ",'dd-mm-yyyy') AND TO_CHAR(" . $reqCariNextCalibrationTo . ",'dd-mm-yyyy') ";
}

if (!empty($reqCariSpesification)) {

    $statement_privacy  .= " AND a.EQUIP_SPEC LIKE '%" . $reqCariSpesification . "%' ";
}

$this->load->model("EquipmentList");
$equipment_list = new EquipmentList();

$aColumns = array(
    "NO",
    "EC_ID", "CATEGORY", "EQUIP_NAME", "PART_OF_EQUIPMENT", "SPECIFICATION", "QUANTITY", "ITEM",
    "INCOMING_DATE", "LAST_CALIBRATION", "NEXT_CALIBRATION", "QTY_DETAIL_EQUIPMENT", "CONDITION",
    "STORAGE", "PRICE", "REMARKS"
);

$pdf = new PDF();
ob_end_clean();
$pdf->AliasNbPages();

// ECHO $pdf->w;exit;
$pdf->AddPage('L', 'A4');
$panjang = (($pdf->w * 91) / 100);
// ECHO $pdf->w;exit;
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell($panjang, 10, 'EQUIPMENT LIST REPORT', 0, 0, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 10);

// exit;
$panjang_tabel = 10;
$arrPanjang = array();
for ($i = 0; $i < 7; $i++) {
    if ($i != 0) {
        $panjang_tabel = 43;
    }
    $pdf->Cell($panjang_tabel, 10, str_replace('_', ' ', $aColumns[$i]), 1, 0, 'C');
    array_push($arrPanjang, $panjang_tabel);
}
$pdf->Ln();
// print_r($arrPanjang);exit;
$equipment_list->selectByParamsMonitoringEquipmentProdCetakPdf(array(), -1, -1, $statement . $statement_privacy);
// echo $equipment_list->query;
// exit;
$pdf->SetFont('Arial', '', 8);
$pdf->SetWidths(array(10, 43, 43, 43, 43, 43, 43, 43));
$no = 1;
while ($equipment_list->nextRow()) {
    // $date1 =  $equipment_list->getField('DATE1');
    // $date2 =  $equipment_list->getField('DATE2');
    // $date_val =
    //     $pdf->Row(array(
    //         $no,
    //         '' . $equipment_list->getField($aColumns[1]),
    //         '' . $equipment_list->getField($aColumns[2]),
    //         '' . $equipment_list->getField($aColumns[3]),
    //         '' . $equipment_list->getField($aColumns[4]),
    //         '' . getTglBlnTahun($date1) . ' - ' . getTglBlnTahun($date2),
    //         '' . $equipment_list->getField($aColumns[6]),

    //     ));

    $pdf->Row(array(
        // kolom tabel
        $no,
        '' . $equipment_list->getField($aColumns[1]),
        '' . $equipment_list->getField($aColumns[2]),
        '' . $equipment_list->getField($aColumns[3]),
        '' . $equipment_list->getField($aColumns[4]),
        '' . $equipment_list->getField($aColumns[5]),
        '' . $equipment_list->getField($aColumns[6])
    ));

    // $pdf->MultiCell($panjang - 2.2, 5, 'COMPANY NAME : ' . "\t" . $equipment_list->getField($aColumns[7]), 1, 'J', 0, 10);
    $pdf->MultiCell($panjang - 2.2, 5, 'ITEM : ' . $equipment_list->getField('ITEM'), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'INCOMING DATE : ' . currencyToPage2($equipment_list->getField('INCOMING_DATE')), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'LAST CALIBRATION : ' . currencyToPage2($equipment_list->getField('LAST_CALIBRATION')), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'NEXT CALIBRATION: ' . currencyToPage2($equipment_list->getField('NEXT_CALIBRATION')), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'QTY DETAIL EQUIPMENT : ' . $equipment_list->getField('QTY_DETAIL_EQUIPMENT'), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'CONDITION : ' . $equipment_list->getField('CONDITION'), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'STORAGE : ' . $equipment_list->getField('STORAGE'), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'PRICE : ' . $equipment_list->getField('PRICE'), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'REMARKS : ' . $equipment_list->getField('REMARKS'), 1);
    $no++;
}

// $pdf->Cell(60,10,'NO PROJECT',1,0,'C');
// $pdf->Cell(60,10,'VESSEL NAME',1,0,'C');
// $pdf->Cell(60,10,'TYPE OF VESSEL',1,0,'C');
// $pdf->Cell(60,10,'TYPE OF VESSEL',1,0,'C');


ob_end_clean();
$pdf->Output();

?>