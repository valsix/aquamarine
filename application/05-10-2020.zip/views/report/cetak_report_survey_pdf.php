<base href="<?= base_url(); ?>" />

<?

include_once("functions/string.func.php");
include_once("functions/date.func.php");

require('libraries/fpdf182/pdf.php');

$reqCariName                = $this->input->post('reqCariName');
$reqCariDescription         = $this->input->post('reqCariDescription');
$reqCariStartDateFrom       = $this->input->post('reqCariStartDateFrom');
$reqCariStartDateTo         = $this->input->post('reqCariStartDateTo');
$reqCariFinishDateFrom      = $this->input->post('reqCariFinishDateFrom');
$reqCariFinishDateTo        = $this->input->post('reqCariFinishDateTo');
$reqCariDeleveryDateFrom    = $this->input->post('reqCariDeleveryDateFrom');
$reqCariDeleveryDateTo      = $this->input->post('reqCariDeleveryDateTo');
$reqCariInvoiceDateFrom     = $this->input->post('reqCariInvoiceDateFrom');
$reqCariInvoiceDateTo       = $this->input->post('reqCariInvoiceDateTo');

if (!empty($reqCariName)) {
    $statement_privacy = " AND A.NAME LIKE '%" . $reqCariName . "%'";
}

if (!empty($reqCariDescription)) {
    $statement_privacy .= " AND A.DESCRIPTION LIKE '%" . $reqCariDescription . "%'";
}

if (!empty($reqCariStartDateFrom) || !empty($reqCariStartDateTo)) {
    $statement_privacy .= " AND A.START_DATE BETWEEN TO_CHAR('" . $reqCariStartDateFrom . "','dd-mm-yyyy') AND TO_CHAR('" . $reqCariStartDateFrom . "','dd-mm-yyyy')";
}

if (!empty($reqCariFinishDateFrom) || !empty($reqCariFinishDateTo)) {
    $statement_privacy .= " AND A.FINISH_DATE BETWEEN TO_CHAR('" . $reqCariFinishDateFrom . "','dd-mm-yyyy') AND TO_CHAR('" . $reqCariFinishDateTo . "','dd-mm-yyyy')";
}
if (!empty($reqCariDeleveryDateFrom) || !empty($reqCariDeleveryDateTo)) {
    $statement_privacy .= " AND A.DELIVERY_DATE BETWEEN TO_CHAR('" . $reqCariDeleveryDateFrom . "','dd-mm-yyyy') AND TO_CHAR('" . $reqCariDeleveryDateTo . "','dd-mm-yyyy')";
}

if (!empty($reqCariInvoiceDateFrom) || !empty($reqCariInvoiceDateTo)) {
    $statement_privacy .= " AND A.INVOICE_DATE BETWEEN TO_CHAR('" . $reqCariInvoiceDateFrom . "','dd-mm-yyyy') AND TO_CHAR('" . $reqCariInvoiceDateTo . "','dd-mm-yyyy')";
}

$this->load->model("Report");
$report_survey = new Report();

$aColumns = array(
    "NO",
    "NAME", "DESCRIPTION", "PATH", "START_DATE", "FINISH_DATE", "DELIVERY_DATE", "INVOICE_DATE", "REASON"

);


$pdf = new PDF();
ob_end_clean();
$pdf->AliasNbPages();

// ECHO $pdf->w;exit;
$pdf->AddPage('L', 'A4');
$panjang = (($pdf->w * 91) / 100);
// ECHO $pdf->w;exit;
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell($panjang, 10, 'SURVEY REPORT', 0, 0, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 10);

// exit;
$panjang_tabel = 10;
$arrPanjang = array();
for ($i = 0; $i < 7; $i++) {
    if ($i != 0) {
        $panjang_tabel = 43;
    }
    $pdf->Cell($panjang_tabel, 10, str_replace('_', ' ', $aColumns[$i]), 1, 0, 'C');
    array_push($arrPanjang, $panjang_tabel);
}
$pdf->Ln();
// print_r($arrPanjang);exit;
$report_survey->selectByParamsCetakPdf(array(), -1, -1, $statement . $statement_privacy);
// echo $report_survey->query;
// exit;
$pdf->SetFont('Arial', '', 8);
$pdf->SetWidths(array(10, 43, 43, 43, 43, 43, 43, 43));
$no = 1;
while ($report_survey->nextRow()) {
    // $date1 =  $report_survey->getField('DATE1');
    // $date2 =  $report_survey->getField('DATE2');
    // $date_val =
    //     $pdf->Row(array(
    //         $no,
    //         '' . $report_survey->getField($aColumns[1]),
    //         '' . $report_survey->getField($aColumns[2]),
    //         '' . $report_survey->getField($aColumns[3]),
    //         '' . $report_survey->getField($aColumns[4]),
    //         '' . getTglBlnTahun($date1) . ' - ' . getTglBlnTahun($date2),
    //         '' . $report_survey->getField($aColumns[6]),

    //     ));

    $pdf->Row(array(
        // kolom tabel
        $no,
        '' . $report_survey->getField($aColumns[1]),
        '' . $report_survey->getField($aColumns[2]),
        '' . $report_survey->getField($aColumns[3]),
        '' . $report_survey->getField($aColumns[4]),
        '' . $report_survey->getField($aColumns[5]),
        '' . $report_survey->getField($aColumns[6]),

    ));

    $pdf->MultiCell($panjang - 2.2, 5, 'INVOICE DATE    : ' . $report_survey->getField('INVOICE_DATE'), 1);
    $pdf->MultiCell($panjang - 2.2, 5, 'REASON  : ' . $report_survey->getField('REASON'), 1);

    // $pdf->MultiCell($panjang - 2.2, 5, 'COMPANY NAME : ' . "\t" . $report_survey->getField($aColumns[7]), 1, 'J', 0, 10);
    // $pdf->MultiCell($panjang - 2.2, 5, 'PPN : ' . currencyToPage2($report_survey->getField('PPN')), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'STATUS : ' . currencyToPage2($report_survey->getField('STATUS')), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'TOTAL AMOUNT: ' . currencyToPage2($report_survey->getField('TOTAL_AMOUNT')), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'INVOICE DATE : ' . $report_survey->getField('INVOICE_DATE'), 1);
    $no++;
}
// $pdf->Cell(60,10,'NO PROJECT',1,0,'C');
// $pdf->Cell(60,10,'VESSEL NAME',1,0,'C');
// $pdf->Cell(60,10,'TYPE OF VESSEL',1,0,'C');
// $pdf->Cell(60,10,'TYPE OF VESSEL',1,0,'C');


ob_end_clean();
$pdf->Output();

?>