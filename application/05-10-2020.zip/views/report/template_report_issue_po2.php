<?
$this->load->model("IssuePo");
$issue_po = new IssuePo();
$this->load->model("IssuePoDetail");
$issue_po_detail = new IssuePoDetail();

$reqId = $this->input->get("reqId");
$statement = " AND A.ISSUE_PO_ID = " . $reqId;
$issue_po->selectByParamsMonitoring(array(), -1, -1, $statement);
$issue_po->firstRow();

$reqId   = $issue_po->getField("ISSUE_PO_ID");
$reqNomerPo     = $issue_po->getField("NOMER_PO");
$reqPoDate      = $issue_po->getField("PO_DATE");
$reqDocLampiran = $issue_po->getField("DOC_LAMPIRAN");
$reqReferensi   = $issue_po->getField("REFERENSI");
$reqPathLampiran = $issue_po->getField("PATH_LAMPIRAN");
$reqFinance     = $issue_po->getField("FINANCE");
$reqCompanyId   = $issue_po->getField("COMPANY_ID");
$reqCompanyName = $issue_po->getField("COMPANY_NAME");
$reqContact     = $issue_po->getField("CONTACT");
$reqAddress     = $issue_po->getField("ADDRESS");
$reqEmail       = $issue_po->getField("EMAIL");
$reqTelp        = $issue_po->getField("TELP");
$reqFax         = $issue_po->getField("FAX");
$reqHp          = $issue_po->getField("HP");
$reqBuyerId     = $issue_po->getField("BUYER_ID");
$reqOther       = $issue_po->getField("OTHER");
$reqPpn         = $issue_po->getField("PPN");
$reqPpnPercent  = $issue_po->getField("PPN_PERCENT");

$reqPic         = $issue_po->getField("PIC");
$reqDepartement = $issue_po->getField("DEPARTEMENT");

?>

<div class="row">
    <div class="col">
        <table border="1" style="font-size: 12px; width: 100%; border-collapse: 1px solid black;font-family: Calibri">
            <thead>
                <tr>
                    <th>Doc Name</th>
                    <th>Doc #</th>
                    <th>Reference</th>
                    <th>PO Date</th>
                    <th>PO#</th>
                    <th>Finance Ref</th>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td style="text-align: center;width: 80px" valign="top">Purchase Order </td>
                    <td style="text-align: center; width: 60px" valign="top"><?=$reqDocLampiran?> </td>
                    <td style="text-align: center;  width: 160px" valign="top"><?=$reqReferensi ?></td>
                    <td style="text-align: center;  width: 80px" valign="top"><b> <?=$reqPoDate?> </b> </td>
                    <td style="text-align: center; width: 280px" valign="top"><b> No: <?=$reqNomerPo?> </b> </td>
                    <td style="text-align: center;  width: 80px" valign="top"><b> <?=$reqFinance?> </b></td>
                </tr>
               
            </tbody>
        </table>
    </div>
</div>

<br>

<div class="row">
    <div class="col">
        <table style="font-size: 12px; width: 100%; text-align: center;">
            <tr>
                <td>
                    Terms and Conditions
                </td>
            </tr>
        </table>
    </div>
</div>

<br>

<div class="row">
    <div class="col">
        <table style="font-size: 12px;">
            <tr>
                <td>1.</td>
                <td style="width: 100px;">Price in </td>
                <td>:</td>
                <td style="width: 610px; color:red;">IDR</td>
            </tr>
            <tr>
                <td>2.</td>
                <td style="width: 100px;">Lingkup kerja </td>
                <td>:</td>
                <td style="width: 610px; color:red;">HSD Solar B20</td>
            </tr>
            <tr>
                <td>3.</td>
                <td style="width: 100px;">Payment Terms</td>
                <td>:</td>
                <td style="width: 610px; color:red;">Pembayaran 3 hari setelah supply solar & Invoice diterima</td>
            </tr>
            <tr>
                <td>4.</td>
                <td style="width: 100px;">Delivery time </td>
                <td>:</td>
                <td style="width: 610px; color:red;">Maksimal 3 hari setelah PO diterbitkan</td>
            </tr>
            <tr>
                <td>5.</td>
                <td style="width: 100px;">Applicable Taxes </td>
                <td>:</td>
                <td style="width: 610px; color:red;"> PPn 10% & Perijinan (include)</td>
            </tr>
            <tr>
                <td>6.</td>
                <td style="width: 100px;">Exclude </td>
                <td>:</td>
                <td style="width: 610px; color:red;">-</td>
            </tr>
            <tr>
                <td style="vertical-align: top;">7.</td>
                <td style="width: 100px; vertical-align: top;">Others </td>
                <td style="vertical-align: top;">:</td>
                <td style="width: 610px; color:red; vertical-align: top;">
                    <ul>
                        <span>PO Number must be referenced on all documents </span>
                    </ul>
                    <ul>
                        <span>(delivery order, invoice, etc) </span>
                    </ul>
                    <ul>
                        <span> Any questions pertaining to this PO payment status to be addressed </span>
                    </ul>
                    <ul>
                        <span> to our Finance/Accounting : isnaini.aquamarine@gmail.com with cc </span>
                    </ul>
                    <ul>
                        <span> to operation@aquamarine.id, inspection@aquamarine.id </span>
                    </ul>
                </td>
            </tr>
        </table>
    </div>
</div>

<br>
<br>

<div class="row">
    <div class="col">
        <table border="1" style="font-size: 12px; border-collapse: 1px solid black;">
            <tr>
                <td style="width: 200px; padding-left: 5px;">
                    <ul>
                        <span>Accepted by</span>
                    </ul>
                    <ul>
                        <span> Vendor/Supplier</span>
                    </ul>
                </td>
                <td style="width: 200px;"></td>
            </tr>

            <tr>
                <td style="height: 100px;"></td>
                <td style="height: 100px;"></td>
            </tr>
        </table>
    </div>
</div>