<base href="<?= base_url(); ?>" />
<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$reqId = $this->input->get('reqId');
$reqMode = $this->input->get('reqMode');

$this->load->model("Invoice");
$this->load->model("InvoiceDetail");

$invoice = new Invoice();
$statement = " AND A.INVOICE_ID = " . $reqId;
$invoice->selectByParamsMonitoring(array(), -1, -1, $statement);
$invoice->firstRow();

$reqInvoiceId       = $invoice->getField("INVOICE_ID");
$reqInvoiceNumber   = $invoice->getField("INVOICE_NUMBER");
$reqCompanyId       = $invoice->getField("COMPANY_ID");
$reqInvoiceDate     = $invoice->getField("INVOICE_DATE");
$reqPpn             = $invoice->getField("PPN");
$reqCompanyName     = $invoice->getField("COMPANY_NAME");
$reqContactName     = $invoice->getField("CONTACT_NAME");
$reqAddress         = $invoice->getField("ADDRESS");
$reqTelephone       = $invoice->getField("TELEPHONE");
$reqFaximile        = $invoice->getField("FAXIMILE");
$reqEmail           = $invoice->getField("EMAIL");
$reqPpnPercent      = $invoice->getField("PPN_PERCENT");
$reqStatus          = $invoice->getField("STATUS");
$reqInvoicePo       = $invoice->getField("INVOICE_PO");
$reqInvoiceTax      = $invoice->getField("INVOICE_TAX");
$reqTerms           = $invoice->getField("TERMS");
$reqNoKontrak       = $invoice->getField("NO_KONTRAK");
$reqNoReport        = $invoice->getField("NO_REPORT");


?>

<h1 style="font-size: 18px;text-align: center;"><u> <b> FAKTUR </b> / INVOICE </u> </h1>
<table style="width: 100%;border-collapse: 1px solid black;font-size: 12px;padding: 20px;font-family: Courier New">
	<tr>
		<td style="width: 150px;padding-left: 10px;border-top: 1px solid black;border-left:1px solid black">&nbsp;</td>
		<td style="width: 10px;border-top: 1px solid black;">&nbsp;</td>
		<td style="padding-left: 10px;border-top: 1px solid black;">&nbsp;</td>
		<td style="border-top: 1px solid black;">&nbsp;</td>
		<td style="padding-left: 10px;border-top: 1px solid black;">&nbsp;</td>
		<td style="border-top: 1px solid black;">&nbsp;</td>
		<td style="border-top: 1px solid black;border-right: 1px solid black">&nbsp;</td>
	</tr>
	<tr>
		<td style="padding-left: 10px;border-left: 1px solid black"> INVOICE NO</td>
		<td> :</td>
		<td style="padding-left: 10px;"> <?= $reqInvoiceNumber ?> </td>
		<td> &nbsp; </td>
		<td style="padding-left: 10px;"> To</td>
		<td> :</td>
		<td style="padding-left: 10px;border-right:  1px solid black"> <?= $reqContactName ?> </td>
	</tr>
	<tr>
		<td style="padding-left: 10px;border-left: 1px solid black"> TAX INVOICE</td>
		<td> :</td>
		<td style="padding-left: 10px"> <?= $reqInvoiceTax ?></td>
		<td> &nbsp; </td>
		<td colspan="3" style="padding-left: 10px;border-right:  1px solid black"> <?= $reqCompanyName ?></td>
	</tr>
	<tr>
		<td style="padding-left: 10px;border-left: 1px solid black"> PO. NO</td>
		<td> :</td>
		<td style="padding-left: 10px"> <?= $reqInvoicePo ?> </td>
		<td> &nbsp; </td>
		<td colspan="3" style="padding-left: 10px;border-right:  1px solid black"> <?= $reqAddress ?></td>
	</tr>
	<tr>
		<td style="padding-left: 10px;border-left: 1px solid black"> PO. DATE</td>
		<td> :</td>
		<td style="padding-left: 10px"> <?= $reqInvoiceDate ?> </td>
		<td> &nbsp; </td>
		<td style="padding-left: 10px"> Telp</td>
		<td style="width: 10px"> :</td>
		<td style="padding-left: 10px;border-right:  1px solid black"> <?= $reqTelephone ?> </td>
	</tr>
	<tr>
		<td colspan="4" style="border-left: 1px solid black"> &nbsp; </td>
		<td style="padding-left: 10px"> Fax</td>
		<td style="width: 10px"> :</td>
		<td style="padding-left: 10px;border-right:  1px solid black"><?= $reqFaximile ?></td>
	</tr>
	<tr>

		<td colspan="4" style="border-left: 1px solid black"> &nbsp; </td>
		<td style="padding-left: 10px"> Email </td>
		<td style="width: 10px"> :</td>
		<td style="padding-left: 10px;border-right:  1px solid black"> <?= $reqEmail ?> </td>
	</tr>
	<tr>
		<td style="width: 150px;padding-left: 10px;border-bottom:  1px solid black;border-left:1px solid black">&nbsp;</td>
		<td style="width: 10px;border-bottom: 1px solid black;">&nbsp;</td>
		<td style="padding-left: 10px;border-bottom: 1px solid black;">&nbsp;</td>
		<td style="border-bottom: 1px solid black;">&nbsp;</td>
		<td style="padding-left: 10px;border-bottom: 1px solid black;">&nbsp;</td>
		<td style="border-bottom: 1px solid black;">&nbsp;</td>
		<td style="border-bottom: 1px solid black;border-right: 1px solid black">&nbsp;</td>
	</tr>

</table>

<br>
<br>


<center>
	<div class="row">
		<div class="col">
			<table border="1" style="border-collapse: 1px solid black;text-align: center;width: 100%; font-size: 12px;padding: 20px;font-family: Courier New">
				<thead>
					<tr>
						<th style="width: 380px;" rowspan="2">DESCRIPTION</th>
						<th colspan="2">AMOUNT</th>

					</tr>
				</thead>

				<tbody>
					<tr>

						<td> Dollar </td>
						<td> Rp </td>
					</tr>
					<?
					$invoice_detail = new InvoiceDetail();
					$invoice_detail->selectByParamsMonitoring(array("A.INVOICE_ID" => $reqId));
					$total_idr = 0;
					$total_usd = 0;
					while ($invoice_detail->nextRow()) {
						$amount_idr =	0;
						$amount_usd =	0;
						$currenct  =	$invoice_detail->getField('CURRENCY');
						if ($currenct == 1) {
							$amount_idr = currencyToPage2($invoice_detail->getField('AMOUNT'));
							$total_idr  = $total_idr + $invoice_detail->getField('AMOUNT');
						} else {
							$amount_usd = currencyToPage2($invoice_detail->getField('AMOUNT'));
							$total_usd  = $total_usd + $invoice_detail->getField('AMOUNT');
						}
					?>
						<tr>
							<td align="left" style="padding: 10px"><b><?= $invoice_detail->getField('SERVICE_TYPE') ?></b><br>
								<ul style="padding-left: 40px">

									<li><?= $invoice_detail->getField('SERVICE_DATE') ?> </li>
									<li><?= $invoice_detail->getField('LOCATION') ?> </li>
									<li><?= $invoice_detail->getField('VESSEL') ?> </li>
								</ul>
							</td>
							<td> <?= $amount_usd ?> </td>
							<td> <?= $amount_idr ?></td>

						</tr>
					<?
					}
					?>
				</tbody>
				<tfoot>
					<?
					$total_ppn_idr = ($total_idr * $reqPpnPercent) / 100;
					$total_ppn_usd = ($total_usd * $reqPpnPercent) / 100;;

					$total_sum_idr = 0;
					$total_sum_usd = 0;
					if ($reqMode == 'ppn') {

						$total_sum_idr = $total_idr - $total_ppn_idr;
						$total_sum_usd = $total_usd - $total_ppn_usd;
					?>
						<tr>
							<td align="right"><strong> KETPPN (<?= $reqPpnPercent ?>) % </strong></td>
							<td><strong> <?= currencyToPage2($total_ppn_usd) ?> </strong></td>
							<td><strong> <?= currencyToPage2($total_ppn_idr) ?> </strong></td>
						</tr>
					<?
					} else {
					}
					?>

					<tr>
						<td align="right"><strong> TOTAL PAYABLE </strong></td>
						<td><strong> <?= currencyToPage2($total_usd) ?> </strong></td>
						<td><strong> <?= currencyToPage2($total_idr) ?> </strong></td>
					</tr>

					<tr>
						<td align="right"><strong> Grand Total </strong> </td>
						<td><strong><?= currencyToPage2($total_sum_usd) ?></strong></td>
						<td><strong><?= currencyToPage2($total_sum_idr) ?></strong></td>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
</center>

<br>

<center>
	<div class="row">
		<div class="col">
			<table style="border-collapse: 1px solid black; font-size: 12px;width: 100%">
				<?
				$tgl_skrng = date('d F');
				$year = date('Y');
				?>
				<tr>
					<td></td>
					<td rowspan="2" style="text-align: left;width: 60%;border: none" align="center" valign="top"> <strong>Sidoarjo, <?= $tgl_skrng ?> </strong><sup>th</sup> <strong> <?= $year ?> </strong> </td>

				</tr>
				<tr>
					<td style="font-size: 9px;font-family: arial"> <b> Syarat & Ketentuan Umum </b> <em> / General Terms & Conditions : </em><br><br>

						<p style="text-align: justify-all;">
							Tagihan atas Invoice ini telah kami anggap selesai bila kami telah menerima pembayaran sesuai dengan box Faktur /<em>This invoice is considered paid when we receive the payment as per stipulated within box Invoice </em>
						</p>
						<br>
						<p style="text-align: justify-all;">
							Pembayaran menggunakan cek. Bilyet giro atau lainnya kami anggap telah selesai dibayarkan bila telah dapat kami uangkan / <em>Any other payment by cheque, bilyet giro or others shall be deemed as paid when we had collected same effective into our account</em>
						</p>


					</td>


				</tr>



				<tr>


					<td style="width: 190px;"></td>
					<td style="width: 190px;border: none" align="center"> <b> ISNAINI .R <br> ACCOUNT MANAGER </b></td>
				</tr>
			</table>
		</div>
	</div>
</center>