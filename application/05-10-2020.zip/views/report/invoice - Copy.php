<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

?>
<h2 style="text-align: center;"> FAKTUR / INVOICE </h2>
<table style="width: 100%;border-collapse: 1px solid black;font-weight: 10px" border="1" >
  <tr >
    <td style="width: 50%;padding: 10px" valign="top"> INVOICE NO    : 38- A/INV-AMD/CLT/VII/2020 <br>
TAX INVOICE  : 010.004-20.05972615<br>
PO.DATE      : June 07th, 2020 <br>
PO NUMBER    : KSM-2020-D0012-O(01) <br><br>
</td>
     <td style="width: 50%;padding: 10px"> To : FINANCE <br>
PT. TEMAS SHIPPING <br>
Jl. Yos Sudarso Kav.33, Sunter Jaya, Jakarta Utara  - Indonesia <br>
Telp  : (021) 4302388 <br>
Fax : (021) 4309650 <br>
E-Mail  : purchasing@asiamarine-temas.com <br>

<br><br>
 </td>
  </tr>
</table>

<br>
 <br>
 <table  style="width: 100%">
   <tr>
    <td> Description </td>
    <td> Jumlah Amount </td>
   </tr>
 </table> 
