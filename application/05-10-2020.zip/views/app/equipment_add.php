<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$this->load->model("EquipmentList");
$equipment_list = new EquipmentList();

$reqId = $this->input->get("reqId");
$reqPicPath = 'images/icon-user-login.png';
if ($reqId == "") {
    $reqMode = "insert";
  $reqEquipId =  $equipment_list->getNextId("EQUIP_ID", "EQUIPMENT_LIST");
} else {
    $reqMode = "ubah";

    $equipment_list->selectByParamsMonitoring(array("A.EQUIP_ID" => $reqId));
    $equipment_list->firstRow();
    $reqEquipId                    = $equipment_list->getField("EQUIP_ID");
    $reqEquipParentId              = $equipment_list->getField("EQUIP_PARENT_ID");
    $reqEcId                       = $equipment_list->getField("EC_ID");
    $reqEquipName                  = $equipment_list->getField("EQUIP_NAME");
    $reqEquipQty                   = $equipment_list->getField("EQUIP_QTY");
    $reqEquipItem                  = $equipment_list->getField("EQUIP_ITEM");
    $reqEquipSpec                  = $equipment_list->getField("EQUIP_SPEC");
    $reqEquipDatein                = $equipment_list->getField("EQUIP_DATEIN");
    $reqEquipLastcal               = $equipment_list->getField("EQUIP_LASTCAL");
    $reqEquipNextcal               = $equipment_list->getField("EQUIP_NEXTCAL");
    $reqEquipCondition             = $equipment_list->getField("EQUIP_CONDITION");
    $reqEquipStorage               = $equipment_list->getField("EQUIP_STORAGE");
    $reqEquipRemarks               = $equipment_list->getField("EQUIP_REMARKS");
    $reqEquipPrice                 = $equipment_list->getField("EQUIP_PRICE");
    $reqPicPaths                    = $equipment_list->getField("PIC_PATH");
    if (!empty($reqPicPaths)) {
        $reqPicPath = 'uploads/equipment/' . $reqPicPaths;
    }
}
?>

<!--// plugin-specific resources //-->
<script src='libraries/multifile-master/jquery.form.js' type="text/javascript" language="javascript"></script>
<script src='libraries/multifile-master/jquery.MetaData.js' type="text/javascript" language="javascript"></script>
<script src='libraries/multifile-master/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>
<link rel="stylesheet" href="css/gaya-multifile.css" type="text/css" />
<style type="text/css">
    #tableis {
        background-color: white;
        padding: 10px;
        border-radius: 25px;
    }

    #tableis tr td {
        padding: 10px;

        font-weight: bold;
        color: black;
    }
</style>
<div class="col-md-12">

    <div class="judul-halaman"> <a href="app/index/equipment"> Equipment</a> &rsaquo; Form Equipment
        <a class="pull-right " href="javascript:void(0)" style="color: white;font-weight: bold;" onclick="goBack()"><i class="fa fa-arrow-circle-left fa lg"> </i><span> Back</span> </a>
    </div>

    <div class="konten-area">
        <div class="konten-inner">
            <div>
                <!--<div class='panel-body'>-->
                <!--<form class='form-horizontal' role='form'>-->
                <form id="ff" class="easyui-form form-horizontal" method="post" novalidate enctype="multipart/form-data">

                    <div class="page-header">
                        <h3><i class="fa fa-file-text fa-lg"></i> Equipment Entry
                            <button type="button" id="btn_editing" class="btn btn-default pull-right " style="margin-right: 10px" onclick="editing_form()"><i id="opens" class="fa fa-folder-o fa-lg"></i><b id="htmlopen">Open</b></button>

                        </h3>
                        <br>
                    </div>

                    <br>

                    <table style="width: 100%" id="tableis">
                        <tr>
                            <td style="width: 10%"> Categori </td>
                            <td style="width: 30%">
                                <input class="easyui-combobox form-control" style="width:100%" name="reqEcId" data-options="width:'290',editable:false, valueField:'id',textField:'text',url:'combo_json/comboEquipCategori'" value="<?= $reqEcId ?>" />

                                <input type="hidden" value="<?= $reqId ?>" name="reqIds" id="reqIds">
                            </td>

                            <td style="width: 20%" rowspan="6" valign="top">
                                <div style="background: white;height: auto;color: black;height: 360px;width: 300px;border: 1px solid black;padding: 20px">
                                    <img id="imgLogo" src="<?= $reqPicPath ?>" style="height: 100%;width: 100%">

                                </div>
                                <input type="file" id="reqFilesName" name="reqFilesName[]" class="form-control" style="width: 60%" accept="image/*">
                                <input type="hidden" name="reqFilesNames" value="<?= $reqPicPath ?>">
                            </td>

                        </tr>
                        <tr>
                            <td> Equipment Id </td>
                            <td><input type="text" class="easyui-validatebox textbox form-control" value="<?= $reqEquipId ?>" style=" width:90%" disabled readOnly /> </td>
                        </tr>
                        <tr>
                            <td> Name of Equipment </td>
                            <td><input type="text" id="reqItem" class="easyui-validatebox textbox form-control" name="reqEquipName" value="<?= $reqEquipName ?>" style=" width:50%" /> </td>
                        </tr>
                        <tr>
                            <td> Part of Equipment </td>
                            <td><input class="easyui-combobox form-control" style="width:100%" name="reqEquipParentId" data-options="width:'200',editable:true, valueField:'id',textField:'text',url:'combo_json/comboEquipList'" value="<?= $reqEquipParentId ?>" /> </td>
                        </tr>
                        <tr>
                            <td> Serian No </td>
                            <td><input type="text" id="reqEquipSpec" class="easyui-validatebox textbox form-control" name="reqEquipSpec" value="<?= $reqEquipSpec ?>" style=" width:90%" /> </td>
                        </tr>
                        <tr>
                            <td> Quantity </td>
                            <td><input type="text" id="reqEquipQty" class="easyui-validatebox textbox form-control" name="reqEquipQty" value="<?= $reqEquipQty ?>" onkeypress='validate(event)' style=" width:90%" /> </td>
                        </tr>

                        <tr>
                            <td> Incoming Date </td>
                            <td> <input type="text" class="easyui-datebox textbox form-control" name="reqEquipDatein" id="reqEquipDatein" value="<?= $reqEquipDatein ?>" style=" width:170px" /> </td>
                        </tr>
                        <tr>
                            <td> Last Calibaration </td>
                            <td> <input type="text" class="easyui-datebox textbox form-control" name="reqEquipLastcal" id="reqEquipLastcal" value="<?= $reqEquipLastcal ?>" style=" width:170px" /></td>
                        </tr>
                        <tr>
                            <td> Next Calibration </td>
                            <td> <input type="text" class="easyui-datebox textbox form-control" name="reqEquipNextcal" id="reqEquipNextcal" value="<?= $reqEquipNextcal ?>" style=" width:170px" /> </td>
                        </tr>

                        <tr>
                            <td> Item </td>
                            <td><input type="text" id="reqEquipItem" class="easyui-validatebox textbox form-control" name="reqEquipItem" value="<?= $reqEquipItem ?>" style=" width:90%" /> </td>
                        </tr>
                        <tr>
                            <td> Condition </td>
                            <td><input type="text" id="reqEquipCondition" class="easyui-validatebox textbox form-control" name="reqEquipCondition" value="<?= $reqEquipCondition ?>" style=" width:90%" /> </td>
                        </tr>

                        <tr>
                            <td> Storage </td>
                            <td><input type="text" id="reqEquipStorage" class="easyui-validatebox textbox form-control" name="reqEquipStorage" value="<?= $reqEquipStorage ?>" style=" width:90%" /> </td>
                        </tr>
                        <tr>
                            <td> Price </td>
                            <td><input type="text" id="reqEquipPrice" class="easyui-validatebox textbox form-control" name="reqEquipPrice" value="<?= $reqEquipPrice ?>" 
                                onchange="numberWithCommas('reqEquipPrice')" onkeyup="numberWithCommas('reqEquipPrice')"

                                style=" width:90%" /> </td>
                        </tr>
                        <tr>
                            <td> Remarks </td>
                            <td><textarea type="text" id="reqEquipRemarks" class="form-control tinyMCES"  name="reqEquipRemarks"  style=" width:90%" ><?= $reqEquipRemarks ?></textarea> </td>
                        </tr>

                    </table>


                    <input type="hidden" name="reqId" value="<?= $reqId ?>" />
                    <input type="hidden" name="reqMode" value="<?= $reqMode ?>" />

                </form>
            </div>
            <div style="text-align:center;padding:5px">
                <a href="javascript:void(0)" class="btn btn-warning" onclick="clearForm()"><i class="fa fa-fw fa-refresh"></i> Reset</a>
                <a href="javascript:void(0)" class="btn btn-primary" onclick="submitForm()"><i class="fa fa-fw fa-send"></i> Submit</a>
            </div>

        </div>

    </div>

    <script>
        function submitForm() {
            $('#ff').form('submit', {
                url: 'web/equipment_json/add_new',
                onSubmit: function() {
                    return $(this).form('enableValidation').form('validate');
                },
                success: function(data) {
                    var datas = data.split('-');
                    //alert(data);
                    $.messager.alertLink('Info', datas[1], 'info', "app/index/equipment_add?reqId=" + datas[0]);
                }
            });
        }

        function clearForm() {
            $('#ff').form('clear');
        }
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#reqFilesName").change(function() {
                readURL(this);
            });

        });
    </script>
    <script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    console.log(e.target.result);
                    //alert(e.target.result);
                    $('#imgLogo').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</div>
</div>