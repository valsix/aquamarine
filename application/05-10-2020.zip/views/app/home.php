<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

?>

<div class="col-md-12 area-home-egateway">
    <div class="row area-info-home">
    	<div class="col-md-1">
        	&nbsp;
        </div>
        <div class="col-md-10">
        	<div class="row">
            	<div class="col-md-4">
                    <div class="item">
                        <div class="ikon"><img src="images/icons8-vise.png"></div>
                        <?
                            $this->load->model("EquipmentList");
                            $equipment_list = new EquipmentList();
                            $total_equipment =  $equipment_list->getCountByParamsMonitoring(array());

                        ?>
                        <div class="nilai"><?=$total_equipment?></div>
                        <div class="title">Equipments in your warehouse</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="item">
                        <div class="ikon"><img src="images/icons8-user.png"></div>
                         <?
                            $this->load->model("Customer");
                            $equipment_list = new Customer();
                            $total_equipment =  $equipment_list->getCountByParams(array("A.TIPE"=>0));

                        ?>
                        <div class="nilai"><?=$total_equipment?></div>
                        <div class="title">New customer in this application</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="item">
                        <div class="ikon"><img src="images/icons8-collaborator_male.png"></div>
                         <?
                            $this->load->model("Customer");
                            $equipment_list = new Customer();
                            $total_equipment =  $equipment_list->getCountByParams(array("A.TIPE"=>1));

                        ?>
                        <div class="nilai"><?=$total_equipment?></div>
                        <div class="title">Customer in this application</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-1">
        	&nbsp;
        </div>
        
    	
    </div>
    
    <div class="row area-info-home">
    	<div class="col-md-1">
        	&nbsp;
        </div>
    	<div class="col-md-2">
        	<div class="item">
            	<div class="ikon"><img src="images/icons8-info.png"></div>
            	<div class="title">Notifikasi</div>
            </div>
        </div>
    	<div class="col-md-8">
        	<div class="alert alert-info">
                <?
                      $this->load->model("DokumenCertificate");
                            $equipment_list = new DokumenCertificate();
                            $total_equipment =  $equipment_list->getCountByParamsTotalCertificate(array());
                ?>
                
            	<i class="fa fa-info-circle" aria-hidden="true"></i> You have <?=$total_equipment?> Certificate(s) must renew
            </div>
            <div class="alert alert-danger">
                <?      
                $this->load->model("EquipmentList");
                $equipment_list = new EquipmentList();
                $total_equipment =  $equipment_list->getCountByParamsTotalEquipment(array());
                ?>
                
            	<i class="fa fa-info-circle" aria-hidden="true"></i> You have <?=$total_equipment?> Equipment(s) must be calibrated.
            </div>

             <div class="alert alert-danger">
            
                
                <i class="fa fa-info-circle" aria-hidden="true"></i> You have 9999 Certificate Personnel (s) expired.
            </div>
            <div class="alert alert-warning">
                 <?      
                $this->load->model("PmsEquipDetil");
                $equipment_list = new PmsEquipDetil();
                $total_equipment =  $equipment_list->getCountByParamsTotalEquipDetail(array());
                ?>
            	<i class="fa fa-info-circle" aria-hidden="true"></i> You have <?=$total_equipment?> Component part(s) must be calibrated
            </div>
            <div class="alert alert-success">
                   <?      
                $this->load->model("Document");
                $equipment_list = new Document();
                $total_equipment =  $equipment_list->getCountByParamsTotalDocument(array());
                ?>
                
            	<i class="fa fa-info-circle" aria-hidden="true"></i> You have <?=$total_equipment?> Legality document must be renew
            </div>
        </div>
	</div>
    
    <!--<div class="row area-info-home">
    	<div class="col-md-3">
        	<div class="item">
            	<div class="ikon"><img src="images/icons8-collaborator_male.png"></div>
            	<div class="nilai">40</div>
            	<div class="title">Certificate(s) must renew</div>
            </div>
        </div>
    	<div class="col-md-3">
        	<div class="item">
            	<div class="ikon"><img src="images/icons8-collaborator_male.png"></div>
            	<div class="nilai">44</div>
            	<div class="title">Equipment(s) must be calibrated</div>
            </div>
        </div>
    	<div class="col-md-3">
        	<div class="item">
            	<div class="ikon"><img src="images/icons8-collaborator_male.png"></div>
            	<div class="nilai">113</div>
            	<div class="title">Component part(s) must be calibrated</div>
            </div>
        </div>
    	<div class="col-md-3">
        	<div class="item">
            	<div class="ikon"><img src="images/icons8-collaborator_male.png"></div>
            	<div class="nilai">7</div>
            	<div class="title">Legality document must be renew</div>
            </div>
        </div>
    </div>-->

    <!--<div class="area-home-egateway-inner">
    	<img src="images/logo-app.png">
    </div>-->

</div>