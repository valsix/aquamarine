 <tr>
                            <td>   <input type="text" name="reqDescription[]" class="easyui-validatebox textbox form-control"  style="width: 100%;" value="" >
                            
                            </td>
                              <td>   <input type="text" name="reqValue[]" class="easyui-validatebox textbox form-control"  style="width: 100%;" value="" ></td>
                              <td>   <input type="color" name="reqColor[]" class=" form-control"  style="width: 50%;" value="" ></td>
                              <td><a onclick="$(this).parent().parent().remove();" ><i class="fa fa-trash fa-lg"></i></a> </td>
                          </tr>