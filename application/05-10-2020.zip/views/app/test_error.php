<?
// if(file_exists("mytestfile.txt")) {
//   $file = fopen("mytestfile.txt", "r");
// } else {
//   die("Error: The file does not exist.");
// }

?>

asdasdasd