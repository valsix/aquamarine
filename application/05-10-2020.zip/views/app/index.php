<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$this->load->model("Users_management");
$usersManagement = new Users_management();

$reqId = $this->input->get("reqId");

$reqLevel = $usersManagement->getField("LEVEL");
// $reqMenuMarketing = $usersManagement->getField("MENUMARKETING");
// $reqMenuFinance = $usersManagement->getField("MENUFINANCE");
// $reqMenuProduction = $usersManagement->getField("MENUPRODUCTION");
// $reqMenuDocument = $usersManagement->getField("MENUDOCUMENT");
// $reqMenuSearch = $usersManagement->getField("MENUSEARCH");
// $reqMenuOthers = $usersManagement->getField("MENUOTHERS");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <meta name="description" content="">
    <meta name="author" content="">
    <!--<link rel="icon" href="libraries/bootstrap-3.3.7/docs/favicon.ico">-->

    <title>Office Management | PT Aquamarine Divindo Inspection</title>
    <base href="<?= base_url(); ?>" />

    <!-- Bootstrap core CSS -->
    <link href="libraries/bootstrap-3.3.7/docs/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="libraries/bootstrap-3.3.7/docs/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="libraries/bootstrap-3.3.7/docs/examples/sticky-footer-navbar/sticky-footer-navbar.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="libraries/bootstrap-3.3.7/docs/assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <link rel="stylesheet" href="css/halaman.css" type="text/css">
    <link rel="stylesheet" href="css/gaya-egateway.css" type="text/css">
    <link rel="stylesheet" href="css/gaya-affix.css" type="text/css">
    <link rel="stylesheet" href="css/gaya-pagination.css" type="text/css">
    <link rel="stylesheet" href="css/gaya-datatable-egateway.css" type="text/css">
    <link rel="stylesheet" href="libraries/font-awesome-4.7.0/css/font-awesome.css">

    <script type='text/javascript' src="libraries/bootstrap/js/jquery-1.12.4.min.js"></script>

    <link href='css/pagination.css' rel='stylesheet' type='text/css'>

    <!-- DATATABLE -->
    <link rel="stylesheet" type="text/css" href="libraries/DataTables-1.10.7/extensions/Responsive/css/dataTables.responsive.css">
    <link rel="stylesheet" type="text/css" href="libraries/DataTables-1.10.7/examples/resources/syntax/shCore.css">
    <link rel="stylesheet" type="text/css" href="libraries/DataTables-1.10.7/examples/resources/demo.css">

    <script type="text/javascript" language="javascript" src="libraries/DataTables-1.10.7/media/js/jquery.js"></script>
    <script type="text/javascript" language="javascript" src="libraries/DataTables-1.10.7/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" language="javascript" src="libraries/DataTables-1.10.7/media/js/fnReloadAjax.js"></script>
    <script type="text/javascript" language="javascript" src="libraries/DataTables-1.10.7/extensions/Responsive/js/dataTables.responsive.js"></script>
    <script type="text/javascript" language="javascript" src="libraries/DataTables-1.10.7/examples/resources/syntax/shCore.js"></script>
    <script type="text/javascript" language="javascript" src="libraries/DataTables-1.10.7/examples/resources/demo.js"></script>
    
     <!-- TAG INPUT -->
     <link rel="stylesheet" type="text/css" href="libraries/taginput/bootstrap-tagsinput.css">
     <script type="text/javascript" language="javascript" src="libraries/taginput/bootstrap-tagsinput.js"></script>






    <!-- PAGINATION -->
    <link rel="stylesheet" type="text/css" href="libraries/drupal-pagination/pagination.css" />

    <!-- tiny MCE -->
    <script src="libraries/tinyMCE/tinymce.min.js"></script>

    <script type="text/javascript">
        tinymce.init({
            mode: "specific_textareas",
            selector: ".tinyMCES",
            plugins: [
                "advlist autolink lists link image charmap print preview anchor",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media table contextmenu paste",
                "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking"
            ],

            toolbar: "insertfile undo redo | styleselect | sizeselect | bold italic | fontsize | fontselect | fontsizeselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image ",
            toolbar2: " responsivefilemanager | link unlink anchor | image media | forecolor backcolor  | print preview code ",
            image_advtab: true,
            menubar: true,
            image_advtab: true,
            external_filemanager_path: "<?= base_url() ?>filemanager/",
            filemanager_title: "File manager",
            external_plugins: {
                "filemanager": "<?= base_url() ?>filemanager/plugin.min.js"
            },
            font_formats: 'Arial=arial;Times New Roman=Times New Roman;Tahoma=Tahoma;Sans=sans-serif;Monospace= monospace;Verdana=Verdana',
            fontsize_formats: "8pt 9pt 10pt 11pt 12pt 13pt 14pt 15pt 16pt 17pt 18pt 19pt 20pt 24pt 36pt",

        });
    </script>


<style type="text/css">
    .bootstrap-tagsinput {
      width: 100% !important;
  }
    .bootstrap-tagsinput .tag {
        margin-right: 2px;
        color: black;
        font-size: 16px;
    }
    .bootstrap-tagsinput span   {
        
        color: red;
        /*font-size: 16px;*/
    }
</style>
</head>

<body>
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="app/" class="logo navbar-brand">
                <img src="images/logo.png" class="img-responsive">
            </a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <!--<ul class="nav navbar-nav">
            <li><a href="#">Left</a></li>
        </ul>-->
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="app"><i class="fa fa-home"></i></a>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Marketing
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <!-- <li><a href="app/index/aplikasi">Aplikasi </a></li> -->
                        <!-- <li><a href="app/index/customer">Customer</a></li> -->
                        <li><a href="app/index/customer_list">Customer List </a></li>
                        <li><a href="app/index/e_commerce">e-Commerce</a></li>
                        <li><a href="app/index/offer">Offering</a></li>
                        <!-- <li><a href="app/index/service_order">Service Order </a></li> -->
                        <li><a href="app/index/service_order">Operation Work Request</a></li>
                        <!-- <li><a href="app/index/service_order">Operation Work Request </a></li> -->
                        <!-- <li><a href="app/index/document">Experience List</a></li> -->
                        <li><a href="app/index/experience_list">Experience List</a></li>
                        <li><a href="app/index/company_profile">Company Profile</a></li>
                        <!-- <li><a href="app/index/document">Dcocuments</a></li> -->
                        <li><a href="#">Website</a></li>
                        <li><a href="app/index/issue_po">Issue PO</a></li>

                    </ul>
                </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Finance
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <!-- <li><a href="app/index/aplikasi">Aplikasi </a></li> -->
                        <li><a href="app/index/project_cost">Project Cost</a></li>
                        <!-- <li><a href="app/index/invoice">Invoice</a></li> -->
                        <li><a href="app/index/invoice">Invoice Project</a></li>
                        <li><a href="app/index/cost_request">Cost Request</a></li>
                        <!-- <li><a href="app/index/cash_report">Cash Flow Report</a></li> -->
                        <li><a href="app/index/cash_report">Cash Flow Report</a></li>
                        <li><a href="app/index/cash_saldo">Saldo Cash</a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Production
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <!-- <li><a href="app/index/aplikasi">Aplikasi </a></li> -->
                        <!-- <li><a href="app/index/equipment_delivery">Equipment Delivery</a></li> -->
                        <li><a href="app/index/equipment_delivery">Equipment Project List</a></li>
                        <!-- <li><a href="app/index/pre_report">Pre Report</a></li> -->
                        <li><a href="app/index/pre_report">Form Underwater/UWILD</a></li>
                        <!-- <li><a href="app/index/work_procedures">Work Procedures</a></li> -->
                        <li><a href="app/index/work_procedures">Working Procedures</a></li>
                        <!-- <li><a href="app/index/personal_kualifikasi">Personal Qualifications </a></li> -->
                        <li><a href="app/index/personal_kualifikasi">Personal List </a></li>
                        <!-- <li><a href="app/index/equipment">Equipment </a></li> -->
                        <li><a href="app/index/equipment">Equipment List</a></li>
                        <li><a href="app/index/pms">PMS </a></li>
                        <!-- <li><a href="app/index/report">Report </a></li> -->
                        <li><a href="app/index/report">Report Survey</a></li>
                        <li><a href="app/index/standarisasi">Standarisasi </a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Documents
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <!-- <li><a href="app/index/aplikasi">Aplikasi </a></li> -->
                        <li><a href="app/index/certificate">Certificates</a></li>
                        <li><a href="app/index/qms">QMS</a></li>
                        <li><a href="app/index/qps">QPS</a></li>
                        <li><a href="app/index/form">Form</a></li>
                        <li><a href="app/index/hse">HSE </a></li>
                        <li><a href="app/index/legality_letters">Legality Letters</a></li>
                        <li><a href="app/index/employment_contracts">Employment Contracts </a></li>
                        <li><a href="app/index/rules">Rules </a></li>
                        <li><a href="app/index/drawing">Drawing </a></li>
                        <li><a href="app/index/others">Others </a></li>
                        <!-- <li><a href="app/index/company_experience">Company Experience </a></li> -->
                        <!-- <li><a href="app/index/document">Company Experience </a></li> -->

                        <li><a href="app/index/qhse">QHSE </a></li>
                        <li><a href="app/index/work_instructions">Work Instructions </a></li>
                    </ul>
                </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Resreach & Develop
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <!-- <li><a href="app/index/aplikasi">Aplikasi </a></li> -->
                        <li><a href="app/index/bussines_plan">Bussines Plan</a></li>
                        <li><a href="app/index/customer_complain">Customer Complain</a></li>
                        <li><a href="app/index/statistic_analyst">Statistic and Analyst</a></li>

                    </ul>
                </li>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Others
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <!-- <li><a href="app/index/aplikasi">Aplikasi </a></li> -->
                        <li><a href="app/index/users_management">Users Management</a></li>
                        <li><a href="javascript:void(0)" onclick="openAdd('app/loadUrl/app/tempalate_master_email');">Email Setting</a></li>
                        <!-- <li><a href="app/index/application_settings">Application Settings</a></li> -->
                        <li><a href="app/index/searching_document">Searching Document</a></li>
                        <li><a href="app/index/log_history">Log History </a></li>
                    </ul>
                </li>

                <!--</ul>
        <ul class="nav navbar-nav navbar-right">-->
                <li class="dropdown dropdown-info-user">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user-circle-o"></i>
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li>
                            <div class="info-user">
                                <div class="nama"><?= $this->NAMA ?></div>
                                <div class="jabatan"><?= $this->JABATAN ?></div>
                            </div>
                        </li>
                        <li><a href="#"><i class="fa fa-key fa-xs"></i> Ganti Password</a></li>
                        <li><a href="login/logout"><i class="fa fa-sign-out fa-xs"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Begin page content -->
    <!--<div class="container-fluid" style="height: calc(100vh - 90px - 45px); padding-bottom: 0px;">-->
    <!--<div class="row" style="position: relative; min-height: 100%; height: 100%;">-->
    <div class="container-fluid <? if ($pg == "" || $pg == "home") { ?> container-home<? } ?>">
        <!--<div class="container-fluid">-->
        <div class="row" style="position: relative;">
            <?= ($content ? $content : '') ?>

        </div>
    </div>

    <footer class="text-center footer">
        <span>Copyright © 2020 PT Aquamarine Divindo Inspection. All Rights Reserved.</span>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>-->
    <script>
        window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')
    </script>
    <script src="libraries/bootstrap-3.3.7/docs/dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="libraries/bootstrap-3.3.7/docs/assets/js/ie10-viewport-bug-workaround.js"></script>

    <!-- SCROLLBAR -->
    <link rel="stylesheet" href="css/scrollbar.css" type="text/css">
    <script type='text/javascript' src="js/enscroll-0.6.0.min.js"></script>
    <script type='text/javascript'>
        //<![CDATA[
        $(function() {
            $('.operator-inner').enscroll({
                showOnHover: false,
                verticalTrackClass: 'track3',
                verticalHandleClass: 'handle3'
            });
        }); //]]>
    </script>
    <!--<script src="libraries/bootstrap/dist/js/bootstrap.min.js"></script>-->

    <!-- EASYUI 1.4.5 -->
    <link rel="stylesheet" type="text/css" href="libraries/easyui/themes/default/easyui.css">
    <link rel="stylesheet" type="text/css" href="libraries/easyui/themes/icon.css">
    <script type="text/javascript" src="libraries/easyui/jquery.easyui.min.js"></script>
    <script type="text/javascript" src="libraries/easyui/globalfunction.js"></script>
    <script type="text/javascript" src="libraries/easyui/kalender-easyui.js"></script>
    <script type="text/javascript" src="libraries/functions/string.func.js?n=1"></script>
    <script type="text/javascript" src="libraries/functions/command.js"></script>

    <!-- EMODAL -->
    <script src="libraries/emodal/eModal.js"></script>
    <script src="libraries/emodal/eModal-cabang.js"></script>

    <!-- TOAST -->
    <link rel="stylesheet" type="text/css" href="libraries/toast/toast.css" />
    <script type="text/javascript" language="javascript" src="libraries/toast/toast.js?n=1"></script>
    <script type="text/javascript" language="javascript" src="libraries/toast/costum.js"></script>

    <script>
        function openAdd(pageUrl) {
            eModal.iframe(pageUrl, 'Office Management | PT Aquamarine Divindo Inspection')
        }

        function openCabang(pageUrl) {
            eModalCabang.iframe(pageUrl, 'Office Management | PT Aquamarine Divindo Inspection')
        }

        function closePopup() {
            eModal.close();
        }

        function windowOpener(windowHeight, windowWidth, windowName, windowUri) {
            var centerWidth = (window.screen.width - windowWidth) / 2;
            var centerHeight = (window.screen.height - windowHeight) / 2;

            newWindow = window.open(windowUri, windowName, 'resizable=0,width=' + windowWidth +
                ',height=' + windowHeight +
                ',left=' + centerWidth +
                ',top=' + centerHeight);

            newWindow.focus();
            return newWindow.name;
        }

        function windowOpenerPopup(windowHeight, windowWidth, windowName, windowUri) {
            var centerWidth = (window.screen.width - windowWidth) / 2;
            var centerHeight = (window.screen.height - windowHeight) / 2;

            newWindow = window.open(windowUri, windowName, 'resizable=1,scrollbars=yes,width=' + windowWidth +
                ',height=' + windowHeight +
                ',left=' + centerWidth +
                ',top=' + centerHeight);

            newWindow.focus();
            return newWindow.name;
        }
    </script>

    <!-- ACCORDION -->
    <link href="libraries/jquery-accordion-menu/style/format.css" rel="stylesheet" type="text/css" />
    <link href="libraries/jquery-accordion-menu/style/text.css" rel="stylesheet" type="text/css" />
    <!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"> </script>-->
    <script type="text/javascript">
        $(document).ready(function() {

            $('div.accordionButton').click(function() {
                $('div.accordionContent').slideUp('normal');
                $(this).next().slideDown('normal');
            });

            $("div.accordionContent").show();
            $('div.accordionContent:first').show();

        });
    </script>


    <!-- SELECTED ROW ON TABLE SCROLLING -->
    <style>
        *table#Demo tbody tr:nth-child(odd) {
            background-color: #ddf7ef;
        }

        table#Demo tbody tr:hover {
            background-color: #333;
            color: #FFFFFF;
        }

        table#Demo tbody tr.selectedRow {
            background-color: #0072bc;
            color: #FFFFFF;
        }
    </style>
    <script>
        $("table#Demo tbody tr").click(function() {
            //alert("haii");
            $("table tr").removeClass('selectedRow');
            $(this).addClass('selectedRow');
        });
    </script>
    <script type="text/javascript">
        function Refresh() {
            document.location.reload();
        }
    </script>
    <!-- CHANGE BGCOLOR WHEN SCROLL -->
    <script>
        $(function() {
            $(document).scroll(function() {
                var $nav = $(".navbar-fixed-top");
                $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
            });
        });
    </script>
    <script type="text/javascript">

    </script>
    <script type="text/javascript">
        function round(value, decimals) {
            return Number(Math.round(value + 'e' + decimals) + 'e-' + decimals);
        }
    </script>
    <style>
        .navbar-fixed-top.scrolled {
            transition: background-color 1000ms linear;
            *background-color: #86a4d5 !important;
            background-color: #000000 !important;
        }
    </style>
    <script type="text/javascript">
        function deleteData_for_table(delele_link, id, idx, position) {
            var elements = oTable.fnGetData(idx);
            var kata = '<b>Detail </b><br>' + elements[position] + '<br>';
            $.messager.confirm('Konfirmasi', 'Yakin menghapus data terpilih ?<br>' + kata, function(r) {
                if (r) {
                    var jqxhr = $.get(delele_link + '?reqId=' + id, function(data) {
                            oTable.api().ajax.reload();
                            show_toast('warning', 'Delete row', kata + ' - ' + data);
                            // document.location.reload();
                        })
                        .done(function() {
                            show_toast('warning', 'Delete row', kata + ' - ' + data);
                            oTable.api().ajax.reload();
                            // document.location.reload();
                        })
                        .fail(function() {
                            // oTable.api().ajax.reload();
                            alert("error");
                        });
                }
            });
        }
    </script>

    <script type="text/javascript">
        function hidding() {
            $('#ff').find('input, textarea, select').attr('disabled', 'disabled');
            $('#ff .easyui-combobox').combobox({
                disabled: true
            });
            $('#ff .easyui-datebox').datebox({
                disabled: true
            });
            $('.btn-primary').attr('disabled', '').css('pointer-events', 'none');
            $('.btn-warning').attr('disabled', '').css('pointer-events', 'none');
            //  $('#element_id').css('pointer-events','none');
            // style.pointerEvents = 'none';
            $('.btn-danger').attr('disabled', '').css('pointer-events', 'none');
            $('.btn-info').attr('disabled', '').css('pointer-events', 'none');
            $('.btn-success').attr('disabled', '').css('pointer-events', 'none');
            // $(".btn-info").off('click');
            $('a .fa-trash-o').parent().hide();
            $('a .fa-trash').parent().hide();


        }

        function unHidding() {
            $('#ff').find('input, textarea, select').removeAttr("disabled");
            $('#ff .easyui-combobox').combobox({
                disabled: false
            });
            $('#ff .easyui-datebox').datebox({
                disabled: false
            });

            $('.btn-primary').removeAttr("disabled").css('pointer-events', '');
            $('.btn-warning').removeAttr("disabled").css('pointer-events', '');
            $('.btn-danger').removeAttr("disabled").css('pointer-events', '');
            $('.btn-info').removeAttr("disabled").css('pointer-events', '');
            $('.btn-success').removeAttr("disabled").css('pointer-events', '');

            $('.fa-trash-o').parent().show();
            $('.fa-trash').parent().show();

        }
        var myFunc = function(event) {
            event.stopPropagation();
            // execute a bunch of action to preform
        }
    </script>

    <script type="text/javascript">
        setTimeout(function() {
            $(document).ready(function() {
                <?
                if (!empty($reqId)) {
                ?>
                    hidding();
                <?
                } else {
                ?>
                    editing_form();
                <?
                }
                ?>
            });
        }, 1000);


        var i = 0;

        function editing_form() {

            if (i == 0) {
                $('#opens').removeClass('fa fa fa-folder fa-lg').addClass('fa fa fa-folder-open-o fa-lg');
                $('#htmlopen').html("Close");
                unHidding();
                i = 1;
            } else {
                $('#opens').removeClass('fa fa fa-folder-open-o fa-lg').addClass('fa fa fa-folder fa-lg');
                $('#htmlopen').html("Open");
                i = 0;
                hidding();

            }

        }
    </script>
    <script type="text/javascript">
        function types(){
         openAdd("app/loadUrl/app/tempalate_master_type_of_service");
        }
        function classes(){
         openAdd("app/loadUrl/app/tempalate_master_class_of_service");
        }
    </script>

    <script type="text/javascript">
        function goBack() {
            window.history.back();
        }
    </script>
    <script type="text/javascript">
        $( document ).ready(function() {
            $('.tagsinput').tagsinput({
  tagClass: 'big'
});
        });
    </script>
</body>

</html>