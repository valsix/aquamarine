<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$this->load->model("Pms");
$pms = new Pms();

$reqId = $this->input->get("reqId");
$reqPicPath = 'images/icon-user-login.png';
if ($reqId == "") {
    $reqMode = "insert";
} else {
    $reqMode = "ubah";

    $pms->selectByParams(array("A.PMS_ID" => $reqId));
    $pms->firstRow();
    $reqPmsId                        = $pms->getField("PMS_ID");
    $reqName                         = $pms->getField("NAME");
    $reqTimeTest                     = $pms->getField("TIME_TEST");
    $reqCompetent                    = $pms->getField("COMPETENT");
    $reqPicPaths                      = $pms->getField("PIC_PATH");
    $reqDateArrive                   = $pms->getField("DATE_ARRIVE");


    if (!empty($reqPicPaths)) {
        $reqPicPath = 'uploads/equipment_prod/' . $reqPicPaths;
    }
}
?>
<style type="text/css">
    #tabel-vessel tr th {
        color: white;
        text-transform: uppercase;
        font-weight: bold;

    }

    #tabel-vessel tr td {
        color: black;


    }
</style>

<!--// plugin-specific resources //-->
<script src='libraries/multifile-master/jquery.form.js' type="text/javascript" language="javascript"></script>
<script src='libraries/multifile-master/jquery.MetaData.js' type="text/javascript" language="javascript"></script>
<script src='libraries/multifile-master/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>
<link rel="stylesheet" href="css/gaya-multifile.css" type="text/css" />
<style type="text/css">
    #tableis {
        background-color: white;
        padding: 10px;
        border-radius: 25px;
    }

    #tableis tr td {
        padding: 10px;

        font-weight: bold;
        color: black;
    }
</style>
<div class="col-md-12">

    <div class="judul-halaman"> <a href="app/index/pms"> PMS</a> &rsaquo; Form PMS
        <a class="pull-right " href="javascript:void(0)" style="color: white;font-weight: bold;" onclick="goBack()"><i class="fa fa-arrow-circle-left fa lg"> </i><span> Back</span> </a>

    </div>

    <div class="konten-area">
        <div class="konten-inner">
            <div>
                <!--<div class='panel-body'>-->
                <!--<form class='form-horizontal' role='form'>-->
                <form id="ff" class="easyui-form form-horizontal" method="post" novalidate enctype="multipart/form-data">

                    <div class="page-header">
                        <h3><i class="fa fa-file-text fa-lg"></i> Equipment Entry
                            <button type="button" id="btn_editing" class="btn btn-default pull-right " style="margin-right: 10px" onclick="editing_form()"><i id="opens" class="fa fa-folder-o fa-lg"></i><b id="htmlopen">Open</b></button>

                        </h3>
                        <br>
                    </div>

                    <br>

                    <table style="width: 100%" id="tableis">
                        <tr>
                            <td style="width: 10%"> Equipment </td>
                            <td style="width: 30%">
                                <input type="text" name="reqName" id="reqName" class="easyui-validatebox textbox form-control" value="<?= $reqName ?>" style=" width:90%" />

                                <input type="hidden" value="<?= $reqId ?>" name="reqIds" id="reqIds">
                            </td>

                            <td style="width: 20%" rowspan="6" valign="top">
                                <div style="background: white;height: auto;color: black;height: 260px;width: 200px;border: 1px solid black;padding: 20px">
                                    <img id="imgLogo" src="<?= $reqPicPath ?>" style="height: 100%;width: 100%">

                                </div>
                                <input type="file" id="reqFilesName" name="reqFilesName[]" class="form-control" style="width: 60%" accept="image/*">
                                <input type="hidden" name="reqFilesNames" value="<?= $reqPicPaths ?>">
                            </td>

                        </tr>
                        <tr>
                            <td> Competent Person </td>
                            <td><input type="text" name="reqCompetent" id="reqCompetent" class="easyui-validatebox textbox form-control" value="<?= $reqId ?>" style=" width:90%" /> </td>
                        </tr>
                        <tr>
                            <td> Date of Arrive </td>
                            <td><input type="text" id="reqItem" class="easyui-datebox  form-control" name="reqDateArrive" value="<?= $reqDateArrive ?>" style=" width:250%" /> </td>
                        </tr>
                        <tr>
                            <td> Time of Test </td>
                            <td><input class="easyui-combobox form-control" style="width:100%" name="reqTimeTest" data-options="width:'200',editable:true, valueField:'id',textField:'text',url:'combo_json/comboTimeOfTest'" value="<?= $reqTimeTest ?>" /> </td>
                        </tr>




                    </table>
                    <br>
                    <br>
                    <div class="page-header">

                        <h3><i class="fa fa-file-text fa-lg"></i> Entry Planned Maintance System


                            <a onclick="tambahPenyebab()" class="pull-right" id="btnPenyebab" class="btn btn-info"><i class="fa fa-plus-square"></i></a>
                        </h3>

                    </div>
                    <div class="table-responsive">
                        <div style="width: 1900px">
                            <table style="width: 100%;" class="table table-bordered" id="tabel-vessel">
                                <thead>
                                    <tr>
                                        <th width="200"> No. Spared Part </th>
                                        <th width="200"> Componenen </th>
                                        <th width="200"> Time Of Test Inspection </th>
                                        <th width="200"> Categori Competen Person </th>
                                        <th width="200"> Last Kalibration </th>
                                        <th width="200"> Next Calibration </th>
                                        <th width="200"> Condition </th>

                                        <th width="50"> Aksi </th>
                                    </tr>
                                </thead>
                                <tbody id="tambahVassel">
                                    <?
                                    $this->load->model("PmsEquipDetil");
                                    $pms_equip_detil = new PmsEquipDetil();
                                    $pms_equip_detil->selectByParamsMonitoring(array("A.PMS_ID" => $reqId));
                                    while ($pms_equip_detil->nextRow()) {
                                        $ids_childs = $pms_equip_detil->getField("PMS_DETIL_ID");
                                    ?>
                                        <tr>
                                            <td><?= $pms_equip_detil->getField("NO_SPAREPART") ?> </td>
                                            <td><?= $pms_equip_detil->getField("COMPETENT") ?> </td>
                                            <td><?= $pms_equip_detil->getField("COMPETENT") ?> </td>
                                            <td><?= $pms_equip_detil->getField("TIME_TEST") ?> </td>
                                            <td><?= $pms_equip_detil->getField("DATE_LASTCAL") ?> </td>
                                            <td><?= $pms_equip_detil->getField("DATE_NEXTCAL") ?> </td>
                                            <td><?= $pms_equip_detil->getField("EQUIP_CONDITION") ?> </td>
                                            <td>
                                                <a onclick='deleteData("web/pms_equip_detil_json/delete",<?= $ids_childs ?>)'><i class="fa fa-trash fa-lg"></i></a>
                                                <a onclick='openAdd("app/loadUrl/app/template_load_componen?reqId=<?= $reqId ?>&reqChild=<?= $ids_childs ?>")'><i class="fa fa-pencil fa-lg"></i></a>
                                            </td>

                                        </tr>
                                    <?
                                    }
                                    ?>





                                </tbody>
                            </table>
                        </div>
                    </div>


                    <input type="hidden" name="reqId" value="<?= $reqId ?>" />
                    <input type="hidden" name="reqMode" value="<?= $reqMode ?>" />

                </form>
            </div>
            <div style="text-align:center;padding:5px">
                <a href="javascript:void(0)" class="btn btn-warning" onclick="clearForm()"><i class="fa fa-fw fa-refresh"></i> Reset</a>
                <a href="javascript:void(0)" class="btn btn-primary" onclick="submitForm()"><i class="fa fa-fw fa-send"></i> Submit</a>
            </div>

        </div>

    </div>

    <script>
        function submitForm() {
            $('#ff').form('submit', {
                url: 'web/pms_equipment_json/add',
                onSubmit: function() {
                    return $(this).form('enableValidation').form('validate');
                },
                success: function(data) {
                    var datas = data.split('-');
                    //alert(data);
                    $.messager.alertLink('Info', datas[1], 'info', "app/index/pms_add?reqId=" + datas[0]);
                }
            });
        }

        function clearForm() {
            $('#ff').form('clear');
        }
    </script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#reqFilesName").change(function() {
                readURL(this);
            });

        });
    </script>
    <script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    console.log(e.target.result);
                    //alert(e.target.result);
                    $('#imgLogo').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>


    <script type="text/javascript">
        function tambahPenyebab() {
            openAdd('app/loadUrl/app/template_load_componen?reqId=<?= $reqId ?>');
        }
    </script>
</div>
</div>