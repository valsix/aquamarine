<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$this->load->model("ExperienceList");
$this->load->model("Company");
$experience_list = new ExperienceList();

$reqId = $this->input->get("reqId");

if($reqId == ""){
    $reqMode = "insert";
}else{
    $reqMode = "ubah";
    $statement= " AND A.EXPERIENCE_LIST_ID = ".$reqId;
    $experience_list->selectByParamsMonitoring(array(), -1,-1, $statement);

    $experience_list->firstRow();
    $reqId= $experience_list->getField("EXPERIENCE_LIST_ID");
    $reqProjectName= $experience_list->getField("PROJECT_NAME");
    $reqProjectLocation= $experience_list->getField("PROJECT_LOCATION");
    $reqCostumerId= $experience_list->getField("COSTUMER_ID");
    $reqContactNo= $experience_list->getField("CONTACT_NO");
    $reqFromDate= dateToPageCheck3($experience_list->getField("FROM_DATE"));
    $reqToDate= dateToPageCheck3($experience_list->getField("TO_DATE"));
    $reqDuration= $experience_list->getField("DURATION");

    if(!empty($reqCostumerId)){
    $company = new Company();
    $company->selectByParamsMonitoring(array("A.COMPANY_ID"=>$reqCostumerId));
    $company->firstRow();
    $reqCompanyName = $company->getField("NAME");
    $reqDocumentPerson  = $company->getField("CP1_NAME");
    $reqAddress = $company->getField("ADDRESS");
    $reqEmail = $company->getField("EMAIL");
    $reqTelephone = $company->getField("PHONE");
    $reqFaximile = $company->getField("FAX");
    $reqHp = $company->getField("CP1_TELP");
    }

}

    // echo $reqToDate;
    $tgl_skrng = date('m/d/Y');
    $startDate = time();
    $startDate1Day =date('m/d/Y', strtotime('+1 day', $startDate));
    if(empty($reqFromDate)){$reqFromDate=$tgl_skrng;} 
    if(empty($reqToDate)){$reqToDate=$startDate1Day;}
    if(empty($reqDuration)){$reqDuration='1';} 

// echo $startDate1Day;


?>

<!--// plugin-specific resources //-->
<script src='libraries/multifile-master/jquery.form.js' type="text/javascript" language="javascript"></script>
<script src='libraries/multifile-master/jquery.MetaData.js' type="text/javascript" language="javascript"></script>
<script src='libraries/multifile-master/jquery.MultiFile.js' type="text/javascript" language="javascript"></script>
<link rel="stylesheet" href="css/gaya-multifile.css" type="text/css" />

<div class="col-md-12">

    <div class="judul-halaman"> <a href="app/index/experience_list"> Experience List</a> &rsaquo; Form Experience List
        <a class="pull-right " href="javascript:void(0)" style="color: white;font-weight: bold;" onclick="goBack()"><i class="fa fa-arrow-circle-left fa lg"> </i><span> Back</span> </a>

    </div>

    <div class="konten-area">
        <div class="konten-inner">
            <div>
                <!--<div class='panel-body'>-->
                <!--<form class='form-horizontal' role='form'>-->
                <form id="ff" class="easyui-form form-horizontal" method="post" novalidate enctype="multipart/form-data">

                    <div class="page-header">
                        <h3><i class="fa fa-file-text fa-lg"></i> Entry Experience List
                            <button type="button" id="btn_editing" class="btn btn-default pull-right " style="margin-right: 10px" onclick="editing_form()"><i id="opens" class="fa fa-folder-o fa-lg"></i><b id="htmlopen">Open</b></button>

                        </h3>
                        <br>
                    </div>

                    <div class="form-group">
                        <label for="reqCompanyName" class="control-label col-md-2">Project Name</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <textarea cols="3" rows="2" id="reqProjectName" name="reqProjectName" class="form-control"><?=$reqProjectName?></textarea>
                                </div>
                            </div>
                        </div>
                        <label for="reqCompanyName" class="control-label col-md-2">Project Location</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                     <textarea cols="3" rows="2" id="reqProjectLocation" name="reqProjectLocation" class="form-control"><?=$reqProjectLocation?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                   <div class="form-group">
                        <label for="reqName" class="control-label col-md-2">Client Name</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" class="easyui-validatebox textbox form-control" name="reqCompanyName" id="reqCompanyName" value="<?= $reqCompanyName ?>" style=" width:100%" onclick="openCompany()" />
                                    <input type="hidden" id="reqCompanyId" name="reqCompanyId" value="<?=$reqCostumerId?>" required>
                                   
                                    <button type="button" class="btn btn-default pull-right" onclick="openCompany()">...</button>
                                </div>
                            </div>
                        </div>
                        <label for="reqPhone" class="control-label col-md-2">Contact</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" class="easyui-validatebox textbox form-control" id="reqDocumentPerson" name="reqDocumentPerson" value="<?= $reqDocumentPerson ?>" style=" width:100%"  />
                                </div>
                            </div>
                        </div>
                    </div>

                     <div class="page-header">

                    </div>

                    <div class="form-group">
                        <label for="reqName" class="control-label col-md-2">Adress</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <textarea class="form-control" name="reqAddress" id="reqAddress" style="width:100%;" ><?=$reqAddress?></textarea>
                                </div>
                            </div>
                        </div>
                        <label for="reqPhone" class="control-label col-md-2">Email</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" id="reqEmail" class="easyui-validatebox textbox form-control" name="reqEmail" value="<?= $reqEmail ?>" style=" width:100%"  />
                                </div>
                            </div>
                        </div>
                        <label for="reqPhone" class="control-label col-md-2">Telephone</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" id="reqTelephone" onkeypress='validate(event)' class="easyui-validatebox textbox form-control"  name="reqTelephone" value="<?= $reqTelephone ?>" style=" width:100%"  />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="reqName" class="control-label col-md-2">Faximile</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" onkeypress='validate(event)' class="easyui-validatebox textbox form-control" name="reqFaximile" id="reqFaximile" value="<?= $reqFaximile ?>" style=" width:100%"  />
                                </div>
                            </div>
                        </div>
                        <label for="reqPhone" class="control-label col-md-2">Handphone</label>
                        <div class="col-md-4">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" id="reqHp" onkeypress='validate(event)' class="easyui-validatebox textbox form-control" name="reqHp" value="<?= $reqHp ?>" style=" width:100%"  />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="page-header">

                    </div>
                   

                    <div class="form-group">
                        <label for="reqPath" class="control-label col-md-2">Date</label>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-11">


                                    <input type="text" class="easyui-datebox textbox form-control" name="reqFromDate" id="reqFromDate" value="<?=$reqFromDate?>" style=" width:100%"  /> To  <input type="text" class="easyui-datebox textbox form-control" name="reqToDate" id="reqToDate"   value="<?=$reqToDate?>" style=" width:100%" />
                                    <input type="text" id="reqDuration" style="width: 10%"class="easyui-validatebox textbox form-control" name="reqDuration" value="<?= $reqDuration ?>" readonly   /> / Day
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="reqDescription" class="control-label col-md-2">Contract No</label>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="col-md-11">
                                    <input type="text" id="reqContactNo" style="width: 100%"class="easyui-validatebox textbox form-control" name="reqContactNo" value="<?= $reqContactNo ?>"  />
                                </div>
                            </div>
                        </div>
                    </div>

                   
                    <br>
                 
                    <input type="hidden" name="reqId" value="<?= $reqId ?>" />
                    <input type="hidden" name="reqMode" value="<?= $reqMode ?>" />

                </form>
            </div>
            <div style="text-align:center;padding:5px">
                <a href="javascript:void(0)" class="btn btn-warning" onclick="clearForm()"><i class="fa fa-fw fa-refresh"></i> Reset</a>
                <a href="javascript:void(0)" class="btn btn-primary" onclick="submitForm()"><i class="fa fa-fw fa-send"></i> Submit</a>
            </div>

        </div>

    </div>

    <script>
        function submitForm() {
            $('#ff').form('submit', {
                url: 'web/experience_list_json/add',
                onSubmit: function() {
                    return $(this).form('enableValidation').form('validate');
                },
                success: function(data) {
                    //alert(data);
                    var datas = data.split('-');
                      show_toast('info', 'Information', 'Header success added <br>' + datas[1]);
                    $.messager.alertLink('Info', datas[1], 'info', "app/index/experience_list_add?reqId=" + datas[0]);
                }
            });
        }

        function clearForm() {
            $('#ff').form('clear');
        }
    </script>

    <script type="text/javascript" src="libraries/easyui/jquery.easyui.min.js"></script>
    <script type="text/javascript">
        function tambahPenyebab() {
            $.get("app/loadUrl/app/tempalate_row_attacment?", function(data) {
                $("#tambahAttacment").append(data);
            });
        }
        function openCompany() {
            openAdd('app/loadUrl/app/template_load_company_id');

        }
        // $('#reqFromDate').datebox('setValue', '6/1/2012');
        $('#reqFromDate').datebox({
            onSelect: function(date){
                // alert(date.getFullYear()+":"+(date.getMonth()+1)+":"+date.getDate());
                ambil_interval();
            }
        });
          $('#reqToDate').datebox({
            onSelect: function(date){
                 ambil_interval();
                // alert(date.getFullYear()+":"+(date.getMonth()+1)+":"+date.getDate());
            }
        });

        function ambil_interval(){
         var tgl1 =   $('#reqFromDate').datebox('getValue');
         var tgl2 =   $('#reqToDate').datebox('getValue');

         var selisih =hitungSelisihHari(tgl1,tgl2);
         // console.log(selisih+" Day ");
         $("#reqDuration").val(selisih);

        }
         function company_pilihans(id, name, contact, reqAddress, reqEmail, reqTelephone, reqFaximile, reqHp) {
            $("#reqCompanyName").val(name);
            $("#reqCompanyId").val(id);
            $("#reqDocumentPerson").val(contact);
            $("#reqAddress").val(reqAddress);
            $("#reqEmail").val(reqEmail);
            $("#reqTelephone").val(reqTelephone);
            $("#reqFaximile").val(reqFaximile);
            $("#reqHp").val(reqHp);

        }

    </script>
</div>
</div>