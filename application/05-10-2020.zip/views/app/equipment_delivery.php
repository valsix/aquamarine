<?php
// Header Nama TABEL TH
$aColumns = array(
    "SO_ID", "NO_ORDER", "COMPANY_NAME", "VESSEL_NAME", "VESSEL_TYPE", "SURVEYOR", "SERVICE", "DESTINATION"
);


$reqCariGlobal                  = $this->input->post('reqCariGlobal');
$reqCariProject                 = $this->input->post('reqCariProject');
$reqCariVasselName              = $this->input->post('reqCariVasselName');
$reqCariPeriodeYear             = $this->input->post('reqCariPeriodeYear');
$reqCariCompanyName             = $this->input->post('reqCariCompanyName');
$reqCariPeriodeYearFrom         = $this->input->post('reqCariPeriodeYearFrom');
$reqCariPeriodeYearTo         = $this->input->post('reqCariPeriodeYearTo');



$add_str = '';
$add_str .= 'reqCariGlobal=' . $reqCariGlobal . '&';
$add_str .= 'reqCariProject=' . $reqCariProject . '&';
$add_str .= 'reqCariVasselName=' . $reqCariVasselName . '&';
$add_str .= 'reqCariPeriodeYear=' . $reqCariPeriodeYear . '&';
$add_str .= 'reqCariPeriodeYearFrom=' . $reqCariPeriodeYearFrom . '&';
$add_str .= 'reqCariPeriodeYearTo=' . $reqCariPeriodeYearTo . '&';
$add_str .= 'reqCariCompanyName=' . $reqCariCompanyName . '';

?>



<script type="text/javascript" language="javascript" class="init">
    var oTable;
    $(document).ready(function() {

        oTable = $('#example').dataTable({
            bJQueryUI: true,
            "iDisplayLength": 25,
            /* UNTUK MENGHIDE KOLOM ID */
            "aoColumns": [{
                    bVisible: false
                },
                null,
                null,
                null,
                null,
                null,
                null,
                null
            ],
            "bSort": true,
            "bProcessing": true,
            "bServerSide": true,
            "sAjaxSource": "web/equipment_delivery_json/json?<?= $add_str ?>",
            columnDefs: [{
                className: 'never',
                targets: [0]
            }],
            "bStateSave": true,
            "fnStateSave": function(oSettings, oData) {
                localStorage.setItem('DataTables_' + window.location.pathname, JSON.stringify(oData));
            },
            "fnStateLoad": function(oSettings) {
                var data = localStorage.getItem('DataTables_' + window.location.pathname);
                return JSON.parse(data);
            },
            "sPaginationType": "full_numbers"

        });
        /* Click event handler */

        /* RIGHT CLICK EVENT */
        var anSelectedData = '';
        var anSelectedId = '';
        var anSelectedDownload = '';
        var anSelectedPosition = '';

        function fnGetSelected(oTableLocal) {
            var aReturn = new Array();
            var aTrs = oTableLocal.fnGetNodes();
            for (var i = 0; i < aTrs.length; i++) {
                if ($(aTrs[i]).hasClass('row_selected')) {
                    aReturn.push(aTrs[i]);
                    anSelectedPosition = i;
                }
            }
            return aReturn;
        }

        $("#example tbody").click(function(event) {
            $(oTable.fnSettings().aoData).each(function() {
                $(this.nTr).removeClass('row_selected');
            });
            $(event.target.parentNode).addClass('row_selected');

            var anSelected = fnGetSelected(oTable);
            anSelectedData = String(oTable.fnGetData(anSelected[0]));
            var element = anSelectedData.split(',');
            anSelectedId = element[0];
        });
         $('#example tbody').on('dblclick', 'tr', function() {

            var anSelected = fnGetSelected(oTable);
            anSelectedData = String(oTable.fnGetData(anSelected[0]));
            var element = anSelectedData.split(',');
            anIndex = anSelected[0];
            anSelectedId = element[0];
            // document.location.href = "app/index/offer_add?reqId=" + anSelectedId;

            openAdd("app/loadUrl/app/template_add_equipment?reqId="+anSelectedId);

            // console.log(anIndex);
        });


        $('#btnAdd').on('click', function() {
            document.location.href = "app/index/bussines_plan_add";

        });

        $('#btnEdit').on('click', function() {
            if (anSelectedData == "")
                return false;
            document.location.href = "app/index/bussines_plan_add?reqId=" + anSelectedId;

        });

        $('#btnPrint').on('click', function() {
            openAdd('app/loadUrl/report/equipment_delivery_pdf?<?= $add_str ?>');
            // deleteData("web/bussines_plan_json/delete", anSelectedId);
        });


        $('#btnExcel').on('click', function() {
            openAdd('app/loadUrl/app/cetak_equipment_delivery_excel?=<?= $add_str ?>');

        });


        $('#btnRefresh').on('click', function() {


            Refresh();

        });
    });
</script>

<!-- FIXED AKSI AREA WHEN SCROLLING -->
<link rel="stylesheet" href="css/gaya-stick-when-scroll.css" type="text/css">
<script src="js/stick.js" type="text/javascript"></script>
<script>
    $(document).ready(function() {
        var s = $("#bluemenu");

        var pos = s.position();
        $(window).scroll(function() {
            var windowpos = $(window).scrollTop();
            //s.html("Distance from top:" + pos.top + "<br />Scroll position: " + windowpos);
            if (windowpos >= pos.top) {
                s.addClass("stick");
                $('#example thead').addClass('stick-datatable');
            } else {
                s.removeClass("stick");
                $('#example thead').removeClass('stick-datatable');
            }
        });
    });
</script>

<style>
    /** THEAD **/
    thead.stick-datatable th:nth-child(1) {
        width: 440px !important;
        *border: 1px solid cyan;
    }

    /** TBODY **/
    thead.stick-datatable~tbody td:nth-child(1) {
        width: 440px !important;
        *border: 1px solid yellow;
    }
</style>

<style type="text/css">
    #tablei tr td {
        padding: 5px;
        font-weight: bold;
    }
</style>

<!-- AREA FILTER TAMBAHAN -->
<script>
    $(document).ready(function() {
        $("button.pencarian-detil").click(function() {
            $(".area-filter-tambahan").toggle();
            $("i", this).toggleClass("fa-caret-up fa-caret-down");
        });
    });
</script>
<style>
    .area-filter-tambahan {
        display: none;
    }
</style>

<div class="col-md-12">

    <div class="judul-halaman"> Monitoring Operation Work Request </div>

    <!--<div class="judul-halaman-bawah">&nbsp;</div>-->
    <div class="konten-area">
        <div id="bluemenu" class="aksi-area">
            <span><a id="btnRefresh"><i class="fa fa-fw fa-refresh" aria-hidden="true"></i> Refresh </a></span>
            <span><a id="btnPrint"><i class="fa fa-fw fa-print" aria-hidden="true"></i> Print </a></span>
            <span><a id="btnExcel"><i class="fa fa-fw fa-file-excel-o" aria-hidden="true"></i> Export Excel </a></span>
            <!-- <span><a id="btnPosting"><i class="fa fa-paper-plane fa-lg" aria-hidden="true"></i> Posting</a></span> -->
            <button class="pull-right pencarian-detil">Pencarian Detil <i class="fa fa-caret-down" aria-hidden="true"></i></button>
        </div>

        <div class="col-md-12 area-filter-tambahan" style="padding-bottom: 10px">
            <div class="panel panel-default">
                <div class="panel-body" style="padding: 10px">
                    <form id="ffs" class="easyui-form form-horizontal" method="post" data-options="novalidate:true">
                        <table id="tablei" style="width: 100%;padding: 10px;margin:10px">
                            <tr>
                                <td>No Order </td>
                                <td><input type="text" name="reqCariNoOrder" class="form-control" id="reqCariNoOrder" value="<?= $reqCariNoOrder ?>"></td>
                                <td>Date of Service</td>
                                <td colspan="2"><input type="text" name="reqCariPeriodeYearFrom" class="easyui-datebox " id="reqCariPeriodeYearFrom" value="<?= $reqCariPeriodeYearFrom ?>"> To <input type="text" name="reqCariPeriodeYearTo" class="easyui-datebox " id="reqCariPeriodeYearTo" value="<?= $reqCariPeriodeYearTo ?>">


                                </td>

                            </tr>
                            <tr>
                                <td>Company Name </td>
                                <td><input type="text" name="reqCariCompanyName" class="form-control" id="reqCariCompanyName" value="<?= $reqCariVasselName ?>"></td>
                                <td>Periode Year</td>
                                <td>
                                    <select name="reqCariPeriodeYear" id="reqCariPeriodeYear" class="form-control form-password tahuns" placeholder="Periode" style="box-shadow: none;">
                                </td>
                                <td>&nbsp;</td>
                            </tr>

                            <tr>
                                <td>Vassel Name </td>
                                <td><input type="text" name="reqCariVasselName" class="form-control" id="reqCariVasselName" value="<?= $reqCariVasselName ?>"></td>
                                <td>Project</td>
                                <td><input type="text" name="reqCariProject" class=" form-control" id="reqCariProject" value="<?= $reqCariProject ?>"></td>
                                <td> </td>

                            </tr>

                            <tr>
                                <td>Global Search</td>
                                <td colspan="3"><input type="text" class="form-control" name="reqCariGlobal" id="reqCariGlobal" value="<?= $reqCariGlobal ?>"></td>

                                <td><button type="submit" class="btn btn-default"> Searching </button></td>
                            </tr>





                        </table>
                    </form>

                </div>
            </div>
        </div>



        <table id="example" class="table table-striped table-hover dt-responsive" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <?php
                    for ($i = 1; $i < count($aColumns); $i++) {
                    ?>
                        <th><?= str_replace('_', ' ', $aColumns[$i])  ?></th>
                    <?php

                    };
                    ?>
                </tr>
            </thead>
        </table>

    </div>


</div>
<script type="text/javascript">
    $(document).ready(function() {
        var year = (new Date()).getFullYear();
        var current = year;
        var limit = 2018;
        var limits = current - limit;
        year -= limits;
        for (var i = 0; i <= limits; i++) {
            var selected = '';
            if ((year + i) == current) {

                selected = 'selected';
            }
            $("#reqCariPeriodeYear").append('<option  value="' + (year + i) + '" ' + selected + '>' + (year + i) + '</option>');

        }

        $("#reqCariPeriodeYear").append('<option  value="ALL" > ALL </option>');
    });
</script>
<!------>