<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include_once("functions/default.func.php");
include_once("functions/string.func.php");
include_once("functions/date.func.php");
// include_once("lib/excel/excel_reader2.php");

class pms_equip_detil_json extends CI_Controller {

	function __construct() {
		parent::__construct();

		if (!$this->kauth->getInstance()->hasIdentity())
		{
			// redirect('login');
		}

		// $this->db->query("SET DATESTYLE TO PostgreSQL,European;");
		$this->Aduan_id				= $this->kauth->getInstance()->getIdentity()->Aduan_id;
		$this->nama				= $this->kauth->getInstance()->getIdentity()->nama;
		$this->keterangan			= $this->kauth->getInstance()->getIdentity()->keterangan;
		$this->link_file		= $this->kauth->getInstance()->getIdentity()->link_file;
		$this->created_by		= $this->kauth->getInstance()->getIdentity()->created_by;
		$this->created_date		= $this->kauth->getInstance()->getIdentity()->created_date;
		$this->update_by	= $this->kauth->getInstance()->getIdentity()->update_by;
		$this->update_date		= $this->kauth->getInstance()->getIdentity()->update_date;

	}

	function test(){
		echo 'adasdas';
	}

	function add(){
		$this->load->model("PmsEquipDetil");
		$pms_equip_detil = new PmsEquipDetil();

		$reqId= $this->input->post("reqId");
		$reqChild= $this->input->post("reqChild");

		$reqPmsDetilId= $this->input->post("reqPmsDetilId");
		$reqPmsId= $this->input->post("reqPmsId");
		$reqName= $this->input->post("reqName");
		$reqTimeTest= $this->input->post("reqTimeTest");
		$reqCompetent= $this->input->post("reqCompetent");
		$reqDateLastcal= $this->input->post("reqDateLastcal");
		$reqDateNextcal= $this->input->post("reqDateNextcal");
		$reqEquipCondition= $this->input->post("reqEquipCondition");
		$reqPicPath= $this->input->post("reqPicPath");
		$reqKeterangan= $this->input->post("reqKeterangan");
		$reqNoSparepart= $this->input->post("reqNoSparepart");


		$pms_equip_detil->setField("PMS_DETIL_ID", $reqChild);
		$pms_equip_detil->setField("PMS_ID", $reqId);
		$pms_equip_detil->setField("NAME", $reqName);
		$pms_equip_detil->setField("TIME_TEST", $reqTimeTest);
		$pms_equip_detil->setField("COMPETENT", $reqCompetent);
		$pms_equip_detil->setField("DATE_LASTCAL", dateToDBCheck($reqDateLastcal));
		$pms_equip_detil->setField("DATE_NEXTCAL", dateToDBCheck($reqDateNextcal));
		$pms_equip_detil->setField("EQUIP_CONDITION", $reqEquipCondition);
		$pms_equip_detil->setField("PIC_PATH", $reqPicPath);
		$pms_equip_detil->setField("KETERANGAN", $reqKeterangan);
		$pms_equip_detil->setField("NO_SPAREPART", $reqNoSparepart);

		if(empty($reqChild)){
			$pms_equip_detil->insert();
			$reqChild = $pms_equip_detil->id;
		}else{
			$pms_equip_detil->update();
		}

		$this->load->library("FileHandler");
        $file = new FileHandler();

        $FILE_DIR= "uploads/equipment_detail/";               
        makedirs($FILE_DIR);
        $filesData=$_FILES["reqFilesName"];
        $reqLinkFileTempSize    =  $this->input->post("reqLinkFileTempSize");
        $reqLinkFileTempTipe    =  $this->input->post("reqLinkFileTempTipe");
        $reqFilesNames    =  $this->input->post("reqFilesNames");
         
        $renameFile = "IMG".date("dmYhis").'-'.$reqChild.".".getExtension2($filesData['name'][0]);
        if($file->uploadToDirArray('reqFilesName', $FILE_DIR, $renameFile,0))
            {
                $reqPicPath                    = $renameFile;
                // echo 'berhasil upload'.$renameFile ;
              
                
            }else{
                $reqPicPath                    = $reqFilesNames;
          
        }
      	 $pms_equip_detil = new PmsEquipDetil();
         $pms_equip_detil->setField("PMS_DETIL_ID",$reqChild);
         $pms_equip_detil->setField("PIC_PATH",$reqPicPath);
         $pms_equip_detil->update_path();

		echo $reqChild.'-Data berhasil di simpan';

	}
	 function delete()
    {
        $this->load->model("Equipment");
        $equipment = new Equipment();

        $reqId = $this->input->get('reqId');

        $equipment->setField("EQUIP_ID", $reqId);
        $pesan ='';
        if ($equipment->delete())
            $pesan = "Data berhasil dihapus.";
        else
            $pesan = "Data gagal dihapus.";

        echo $pesan;
    }
}
