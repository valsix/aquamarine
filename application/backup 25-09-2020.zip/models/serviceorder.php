<?
/* *******************************************************************************************************
MODUL NAME 			: IMASYS
FILE NAME 			: 
AUTHOR				: 
VERSION				: 1.0
MODIFICATION DOC	:
DESCRIPTION			: 
***************************************************************************************************** */

/***
 * Entity-base class untuk mengimplementasikan tabel PANGKAT.
 * 
 ***/
include_once("Entity.php");

class ServiceOrder  extends Entity
{

    var $query;
    var $id;
    /**
     * Class constructor.
     **/
    function ServiceOrder()
    {
        $this->Entity();
    }

    function insert()
    {
        $this->setField("SO_ID", $this->getNextId("SO_ID","SERVICE_ORDER")); 

        $str = "INSERT INTO SERVICE_ORDER (SO_ID, PROJECT_NAME, NO_ORDER, COMPANY_NAME, VESSEL_NAME, VESSEL_TYPE,        SURVEYOR, DESTINATION, SERVICE, DATE_OF_START, DATE_OF_FINISH,        TRANSPORT, EQUIPMENT, OBLIGATION, DATE_OF_SERVICE, PIC_EQUIP,        CONTACT_PERSON)VALUES (
        '".$this->getField("SO_ID")."',
        '".$this->getField("PROJECT_NAME")."',
        '".$this->getField("NO_ORDER")."',
        '".$this->getField("COMPANY_NAME")."',
        '".$this->getField("VESSEL_NAME")."',
        '".$this->getField("VESSEL_TYPE")."',
        '".$this->getField("SURVEYOR")."',
        '".$this->getField("DESTINATION")."',
        '".$this->getField("SERVICE")."',
        '".$this->getField("DATE_OF_START")."',
        '".$this->getField("DATE_OF_FINISH")."',
        '".$this->getField("TRANSPORT")."',
        '".$this->getField("EQUIPMENT")."',
        '".$this->getField("OBLIGATION")."',
        '".$this->getField("DATE_OF_SERVICE")."',
        '".$this->getField("PIC_EQUIP")."',
        '".$this->getField("CONTACT_PERSON")."' 
        )";

        $this->id = $this->getField("SO_ID");
        $this->query= $str;
            // echo $str;exit();
        return $this->execQuery($str);
        }

        function update()
        {
            $str = "
            UPDATE SERVICE_ORDER
            SET    
            SO_ID ='".$this->getField("SO_ID")."',
            PROJECT_NAME ='".$this->getField("PROJECT_NAME")."',
            NO_ORDER ='".$this->getField("NO_ORDER")."',
            COMPANY_NAME ='".$this->getField("COMPANY_NAME")."',
            VESSEL_NAME ='".$this->getField("VESSEL_NAME")."',
            VESSEL_TYPE ='".$this->getField("VESSEL_TYPE")."',
            SURVEYOR ='".$this->getField("SURVEYOR")."',
            DESTINATION ='".$this->getField("DESTINATION")."',
            SERVICE ='".$this->getField("SERVICE")."',
            DATE_OF_START =".$this->getField("DATE_OF_START").",
            DATE_OF_FINISH =".$this->getField("DATE_OF_FINISH").",
            TRANSPORT ='".$this->getField("TRANSPORT")."',
            EQUIPMENT ='".$this->getField("EQUIPMENT")."',
            OBLIGATION ='".$this->getField("OBLIGATION")."',
            DATE_OF_SERVICE ='".$this->getField("DATE_OF_SERVICE")."',
            PIC_EQUIP ='".$this->getField("PIC_EQUIP")."',
            CONTACT_PERSON ='".$this->getField("CONTACT_PERSON")."' 
            WHERE SO_ID= '".$this->getField("SO_ID")."'";
            $this->query = $str;
          // echo $str;exit;
            return $this->execQuery($str);
        }

        function delete($statement= "")
        {
            $str = "DELETE FROM SERVICE_ORDER
            WHERE SO_ID= '".$this->getField("SO_ID")."'"; 
            $this->query = $str;
          // echo $str;exit();
            return $this->execQuery($str);
        }

        function selectByParamsMonitoring($paramsArray=array(),$limit=-1,$from=-1, $statement="", $order="ORDER BY A.SO_ID ASC")
        {
            $str = "
            SELECT A.SO_ID,A.PROJECT_NAME,A.NO_ORDER,A.COMPANY_NAME,A.VESSEL_NAME,A.VESSEL_TYPE,A.SURVEYOR,A.DESTINATION,A.SERVICE,A.DATE_OF_START,A.DATE_OF_FINISH,A.TRANSPORT,A.EQUIPMENT,A.OBLIGATION,A.DATE_OF_SERVICE,A.PIC_EQUIP,A.CONTACT_PERSON
            FROM service_order A
            WHERE 1=1 ";
            while(list($key,$val) = each($paramsArray))
            {
                $str .= " AND $key = '$val'";
            }

            $str .= $statement." ".$order;
            $this->query = $str;
            return $this->selectLimit($str,$limit,$from); 
        }

        function selectByParamsEquiment($paramsArray=array(),$limit=-1,$from=-1, $statement="", $order="ORDER BY A.SO_ID ASC")
        {
            $str = "
           SELECT A.SO_ID, A.NO_ORDER , A.COMPANY_NAME ,  A.VESSEL_NAME , A.VESSEL_TYPE , A.SURVEYOR , A.SERVICE , A.DESTINATION ,TO_CHAR(A.DATE_OF_SERVICE, 'DAY,MONTH DD YYYY') AS DATE_OF_SERVICE, TO_CHAR(A.DATE_OF_START, 'DAY,MONTH DD YYYY') DATE_OF_START, TO_CHAR(A.DATE_OF_FINISH, 'DAY,MONTH DD YYYY') DATE_OF_FINISH,
               PIC_EQUIP 
               FROM   SERVICE_ORDER A
            WHERE 1=1 ";
            while(list($key,$val) = each($paramsArray))
            {
                $str .= " AND $key = '$val'";
            }

            $str .= $statement." ".$order;
            $this->query = $str;
            return $this->selectLimit($str,$limit,$from); 
        }

        function getCountByParamsMonitoring($paramsArray=array(), $statement="")
        {
            $str = "SELECT COUNT(1) AS ROWCOUNT FROM SERVICE_ORDER A WHERE 1=1 ".$statement;
            while(list($key,$val)=each($paramsArray))
            {
                $str .= " AND $key =    '$val' ";
            }
            $this->query = $str;
            $this->select($str); 
            if($this->firstRow()) 
                return $this->getField("ROWCOUNT"); 
            else 
                return 0; 
        }

    
}
