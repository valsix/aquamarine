<?
/* *******************************************************************************************************
MODUL NAME 			: MTSN LAWANG
FILE NAME 			: 
AUTHOR				: 
VERSION				: 1.0
MODIFICATION DOC	:
DESCRIPTION			: 
***************************************************************************************************** */

/***
 * Entity-base class untuk mengimplementasikan tabel kategori.
 * 
 ***/
include_once(APPPATH . '/models/Entity.php');

class PmsEquipment  extends Entity
{

	var $query;
	var $id;
	/**
	 * Class constructor.
	 **/
	function PmsEquipment()
	{
		$this->Entity();
	}

	function insert()
	{
		$this->setField("PMS_ID", $this->getNextId("PMS_ID", "PMS_EQUIPMENT"));

		$str = "INSERT INTO PMS_EQUIPMENT (PMS_ID, NAME, TIME_TEST, COMPETENT, PIC_PATH, DATE_ARRIVE)VALUES (
				'" . $this->getField("PMS_ID") . "',
				'" . $this->getField("NAME") . "',
				'" . $this->getField("TIME_TEST") . "',
				'" . $this->getField("COMPETENT") . "',
				'" . $this->getField("PIC_PATH") . "',
				" . $this->getField("DATE_ARRIVE") . " 
    	)";

		$this->id = $this->getField("PMS_ID");
		$this->query = $str;
		// echo $str;
		// exit;
		return $this->execQuery($str);
	}

	function update()
	{
		$str = "
		UPDATE PMS_EQUIPMENT
		SET    
		PMS_ID ='" . $this->getField("PMS_ID") . "',
		NAME ='" . $this->getField("NAME") . "',
		TIME_TEST ='" . $this->getField("TIME_TEST") . "',
		COMPETENT ='" . $this->getField("COMPETENT") . "',
		PIC_PATH ='" . $this->getField("PIC_PATH") . "',
		DATE_ARRIVE =" . $this->getField("DATE_ARRIVE") . "
		WHERE PMS_ID= '" . $this->getField("PMS_ID") . "'";
		$this->query = $str;
		// echo $str;exit;
		return $this->execQuery($str);
	}
	function update_path()
	{
		$str = "
		UPDATE PMS_EQUIPMENT
		SET    
		
		PIC_PATH ='" . $this->getField("PIC_PATH") . "'
		
		WHERE PMS_ID= '" . $this->getField("PMS_ID") . "'";
		$this->query = $str;
		// echo $str;exit;
		return $this->execQuery($str);
	}

	function delete($statement = "")
	{
		$str = "DELETE FROM PMS_EQUIPMENT
		WHERE PMS_ID= '" . $this->getField("PMS_ID") . "'";
		$this->query = $str;
		// echo $str;exit();
		return $this->execQuery($str);
	}

	function selectByParamsMonitoring($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.PMS_ID ASC")
	{
		$str = "SELECT A.PMS_ID,A.NAME,A.TIME_TEST,A.COMPETENT,A.PIC_PATH,A.DATE_ARRIVE
				FROM PMS_EQUIPMENT A
				WHERE 1=1 ";
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = '$val'";
		}

		$str .= $statement . " " . $order;
		$this->query = $str;
		return $this->selectLimit($str, $limit, $from);
	}

	function selectByParamsMonitoringCetakPdf($paramsArray = array(), $limit = -1, $from = -1, $statement = "", $order = "ORDER BY A.PMS_ID ASC")
	{
		$str = "SELECT A.PMS_ID,A.NAME,A.TIME_TEST,A.COMPETENT,A.PIC_PATH,A.DATE_ARRIVE
				FROM PMS_EQUIPMENT A
				WHERE 1=1 ";
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = '$val'";
		}

		$str .= $statement . " " . $order;
		$this->query = $str;
		return $this->selectLimit($str, $limit, $from);
	}

	function getCountByParamsMonitoring($paramsArray = array(), $statement = "")
	{
		$str = "SELECT COUNT(1) AS ROWCOUNT FROM PMS_EQUIPMENT A WHERE 1=1 " . $statement;
		while (list($key, $val) = each($paramsArray)) {
			$str .= " AND $key = 	'$val' ";
		}
		$this->query = $str;
		$this->select($str);
		if ($this->firstRow())
			return $this->getField("ROWCOUNT");
		else
			return 0;
	}
}
