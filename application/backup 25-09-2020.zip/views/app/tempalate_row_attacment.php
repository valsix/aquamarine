  <tr>
    <td><input type="file" name="document[]" class="form-control">
      <input type="hidden" name="reqLinkFileTemp[]" value="">
    </td>

    <td><a onclick="$(this).parent().parent().remove();"><i class="fa fa-trash fa-lg"></i></a> </td>
  </tr>