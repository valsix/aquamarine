<tr>
    <td><input type="file" name="" class="form-control"> </td>
    
    <td><a onclick="$(this).parent().parent().remove();" ><i class="fa fa-trash fa-lg"></i></a>  </td>
</tr>
