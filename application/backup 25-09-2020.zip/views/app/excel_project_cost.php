<?
$fileName = 'report_cost_project.xls';
header("Content-Disposition: attachment; filename=\"$fileName\"");
header("Content-Type: application/vnd.ms-excel;");

$reqIds = $this->input->get("reqIds");
$reqId = explode(',', $reqIds);

$this->load->model("Project_cost");
$reqId = $this->input->get("reqIds");

$projectCost = new Project_cost();
$reqIds = explode(',', $reqId);

// $statement='';
// for($i=0;$i<count($reqIds);$i++){
//     if(!empty($reqIds[$i])){
//         if($i==0){
//              $statement .= " AND A.COMPANY_ID=".$reqIds[$i];
//         }else{
//              $statement .= " OR A.COMPANY_ID=".$reqIds[$i];   
//         }   

//     }

// }
$projectCost->selectByParamsCetakExcel(array(), -1, -1, $statement);

?>
<H1 style="text-align: center;"> Cost Project Report </H1>
<table style="width: 100%;border-collapse: 1px solid black" border="1">
    <tr>
        <th>No </th>
        <th>No Project </th>
        <th>Vessel Name </th>
        <th>Type Of Vessel </th>
        <th>Type Of Service </th>
        <th>Date Service1 </th>
        <th>Date Service2 </th>
        <th>Destination </th>
        <th>Company Name </th>
        <th>Contact Person </th>
        <th>Kasbon </th>
        <th>Offer Price </th>
        <th>Real Price </th>
        <th>Surveyor </th>
    </tr>
    <?
    $no = 1;
    while ($projectCost->nextRow()) {
    ?>
        <tr>
            <td><?= $no ?> </td>
            <td><?= $projectCost->getField('NO_PROJECT') ?> </td>
            <td><?= $projectCost->getField('VESSEL_NAME') ?> </td>
            <td><?= $projectCost->getField('TYPE_OF_VESSEL') ?> </td>
            <td><?= $projectCost->getField('TYPE_OF_SERVICE') ?> </td>
            <td><?= $projectCost->getField('DATESERVICE1') ?> </td>
            <td><?= $projectCost->getField('DATESERVICE2') ?> </td>
            <td><?= $projectCost->getField('DESTINATION') ?> </td>
            <td><?= $projectCost->getField('COMPANY_NAME') ?> </td>
            <td><?= $projectCost->getField('CONTACT_PERSON') ?> </td>
            <td><?= $projectCost->getField('KASBON') ?> </td>
            <td><?= $projectCost->getField('OFFER_PRICE') ?> </td>
            <td><?= $projectCost->getField('REAL_PRICE') ?> </td>
            <td><?= $projectCost->getField('SURVEYOR') ?> </td>

        </tr>
    <?
        $no++;
    }
    ?>

</table>