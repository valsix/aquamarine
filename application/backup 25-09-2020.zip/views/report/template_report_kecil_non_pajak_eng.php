<base href="<?= base_url(); ?>" />
<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$reqId = $this->input->get('reqId');
$reqMode = $this->input->get('reqMode');

$this->load->model("Invoice");
$this->load->model("InvoiceDetail");

$invoice = new Invoice();
$statement = " AND A.INVOICE_ID = " . $reqId;
$invoice->selectByParamsMonitoring(array(), -1, -1, $statement);
$invoice->firstRow();

$reqInvoiceId       = $invoice->getField("INVOICE_ID");
$reqInvoiceNumber   = $invoice->getField("INVOICE_NUMBER");
$reqCompanyId       = $invoice->getField("COMPANY_ID");
$reqInvoiceDate     = $invoice->getField("INVOICE_DATE");
$reqPpn             = $invoice->getField("PPN");
$reqCompanyName     = $invoice->getField("COMPANY_NAME");
$reqContactName     = $invoice->getField("CONTACT_NAME");
$reqAddress         = $invoice->getField("ADDRESS");
$reqTelephone       = $invoice->getField("TELEPHONE");
$reqFaximile        = $invoice->getField("FAXIMILE");
$reqEmail           = $invoice->getField("EMAIL");
$reqPpnPercent      = $invoice->getField("PPN_PERCENT");
$reqStatus          = $invoice->getField("STATUS");
$reqInvoicePo       = $invoice->getField("INVOICE_PO");
$reqInvoiceTax      = $invoice->getField("INVOICE_TAX");
$reqTerms           = $invoice->getField("TERMS");
$reqNoKontrak       = $invoice->getField("NO_KONTRAK");
$reqNoReport        = $invoice->getField("NO_REPORT");


?>

<center>
	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"><strong> Term Condition : </strong></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;"><strong> To </strong></td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><strong> <?= $reqContactName ?> </strong></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 250px;"><?= $reqTerms ?></td>
					<td style="width: 153px;"></td>
					<td style="width: 338px;"><?= $reqCompanyName ?></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 250px;"></td>
					<td style="width: 153px;"></td>
					<td style="width: 338px;"><?= $reqAddress ?></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;">Telp</td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><?= $reqTelephone ?></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;">Fax </td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><?= $reqFaximile ?></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;">E-Mail </td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><?= $reqEmail ?></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;"><strong> E-Invoice No </strong></td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><strong> <?= $reqInvoiceNumber ?> </strong></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;"><strong>Tax Invoice </strong> </td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><strong> <?= $reqInvoiceTax ?> </strong></td>
				</tr>
			</table>
		</div>
	</div>

	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 130px;"></td>
					<td style="width: 300px;"></td>
					<td style="width: 90px;"><strong> PO No </strong></td>
					<td style="width: 20px;">:</td>
					<td style="width: 250px;"><strong> <?= $reqInvoicePo ?> </strong></td>
				</tr>
			</table>
		</div>
	</div>

</center>

<br>

<center>
	<div class="row">
		<div class="col">
			<table style="font-size: 12px;">
				<tr>
					<td style="width: 350px;"></td>
					<td><strong>
							<h2><em> INVOICE </em></h2>
						</strong></td>
					<td style="width: 350px;"></td>
				</tr>
			</table>
		</div>
	</div>
</center>

<br>

<center>
	<div class="row">
		<div class="col">
			<table border="1" style="border-collapse: 1px solid black;text-align: center;width: 100%; font-size: 12px;">
				<thead>
					<tr>
						<th style="width: 380px;" rowspan="2">DESCRIPTION</th>
						<th colspan="2">AMOUNT</th>

					</tr>
				</thead>

				<tbody>
					<tr>

						<td> Dollar </td>
						<td> Rp </td>
					</tr>
					<?
					$invoice_detail = new InvoiceDetail();
					$invoice_detail->selectByParamsMonitoring(array("A.INVOICE_ID" => $reqId));
					$total_idr = 0;
					$total_usd = 0;
					while ($invoice_detail->nextRow()) {
						$amount_idr =	0;
						$amount_usd =	0;
						$currenct  =	$invoice_detail->getField('CURRENCY');
						if ($currenct == 1) {
							$amount_idr = currencyToPage2($invoice_detail->getField('AMOUNT'));
							$total_idr  = $total_idr + $invoice_detail->getField('AMOUNT');
						} else {
							$amount_usd = currencyToPage2($invoice_detail->getField('AMOUNT'));
							$total_usd  = $total_usd + $invoice_detail->getField('AMOUNT');
						}
					?>
						<tr>
							<td align="left" style="padding: 10px"><b><?= $invoice_detail->getField('SERVICE_TYPE') ?></b><br>
								<ul style="padding-left: 40px">

									<li><?= $invoice_detail->getField('SERVICE_DATE') ?> </li>
									<li><?= $invoice_detail->getField('LOCATION') ?> </li>
									<li><?= $invoice_detail->getField('VESSEL') ?> </li>
								</ul>
							</td>
							<td> <?= $amount_usd ?> </td>
							<td> <?= $amount_idr ?></td>

						</tr>
					<?
					}
					?>
				</tbody>
				<tfoot>
					<?
					$total_ppn_idr = ($total_idr * $reqPpnPercent) / 100;
					$total_ppn_usd = ($total_usd * $reqPpnPercent) / 100;;

					$total_sum_idr = 0;
					$total_sum_usd = 0;
					if ($reqMode == 'ppn') {

						$total_sum_idr = $total_idr - $total_ppn_idr;
						$total_sum_usd = $total_usd - $total_ppn_usd;
					?>
						<tr>
							<td align="right"><strong> KETPPN (<?= $reqPpnPercent ?>) % </strong></td>
							<td><strong> <?= currencyToPage2($total_ppn_usd) ?> </strong></td>
							<td><strong> <?= currencyToPage2($total_ppn_idr) ?> </strong></td>
						</tr>
					<?
					} else {
					}
					?>

					<tr>
						<td align="right"><strong> TOTAL PAYABLE </strong></td>
						<td><strong> <?= currencyToPage2($total_usd) ?> </strong></td>
						<td><strong> <?= currencyToPage2($total_idr) ?> </strong></td>
					</tr>

					<tr>
						<td align="right"><strong> Grand Total </strong> </td>
						<td><strong><?= currencyToPage2($total_sum_usd) ?></strong></td>
						<td><strong><?= currencyToPage2($total_sum_idr) ?></strong></td>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
</center>

<br>

<center>
	<div class="row">
		<div class="col">
			<table border="1" style="border-collapse: 1px solid black; font-size: 12px;width: 100%">
				<?
				$tgl_skrng = date('d F');
				$year = date('Y');
				?>
				<tr>
					<td></td>
					<td rowspan="2" style="text-align: left;width: 60%;border: none" align="center" valign="top"> <strong>Sidoarjo, <?= $tgl_skrng ?> </strong><sup>th</sup> <strong> <?= $year ?> </strong> </td>

				</tr>
				<tr>
					<td> <b> Syarat & Ketentuan Umum </b> <em> / General Terms & Conditions : </em><br>

						<p>
							Tagihan atas Invoice ini telah kami anggap selesai bila kami telah menerima pembayaran sesuai dengan box Faktur /This invoice is considered paid when we receive the payment as per stipulated within box Invoice
						</p>
						<p>
							Pembayaran menggunakan cek. Bilyet giro atau lainnya kami anggap telah selesai dibayarkan bila telah dapat kami uangkan / Any other payment by cheque, bilyet giro or others shall be deemed as paid when we had collected same effective into our account
						</p>


					</td>


				</tr>



				<tr>


					<td style="width: 190px;"></td>
					<td style="width: 190px;border: none" align="center"> <b> ISNAINI .R <br> ACCOUNT MANAGER </b></td>
				</tr>
			</table>
		</div>
	</div>
</center>