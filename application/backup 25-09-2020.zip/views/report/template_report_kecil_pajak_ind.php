<base href="<?= base_url(); ?>" />
<?
include_once("functions/string.func.php");
include_once("functions/date.func.php");

$reqId = $this->input->get('reqId');

// $this->load->model('Offer');
// $offer = new Offer();
// // $reqId =$reqIds;

// $offer->selectByParamsMonitoring(array("OFFER_ID" => $reqId));
// // echo $offer->query;
// // exit;
// $offer->firstRow();
// $reqId               = $offer->getField("OFFER_ID");
// $reqDocumentId       = $offer->getField("DOCUMENT_ID");
// $reqDocumentPerson   = $offer->getField("DOCUMENT_PERSON");
// $reqDestination      = $offer->getField("DESTINATION");
// $reqDateOfService    = $offer->getField("DATE_OF_SERVICE");
// $reqTypeOfService    = $offer->getField("TYPE_OF_SERVICE");
// $reqScopeOfWork      = $offer->getField("SCOPE_OF_WORK");
// $reqTermAndCondition = $offer->getField("TERM_AND_CONDITION");
// $reqPaymentMethod    = $offer->getField("PAYMENT_METHOD");
// $reqTotalPrice       = $offer->getField("TOTAL_PRICE");
// $reqTotalPriceWord   = $offer->getField("TOTAL_PRICE_WORD");
// $reqStatus           = $offer->getField("STATUS");
// $reqReason           = $offer->getField("REASON");
// $reqNoOrder          = $offer->getField("NO_ORDER");
// $reqDateOfOrder      = $offer->getField("DATE_OF_ORDER");
// $reqCompanyName      = $offer->getField("COMPANY_NAME");
// $reqAddress          = $offer->getField("ADDRESS");
// $reqFaximile         = $offer->getField("FAXIMILE");
// $reqEmail            = $offer->getField("EMAIL");
// $reqTelephone        = $offer->getField("TELEPHONE");
// $reqHp               = $offer->getField("HP");
// $reqVesselName       = $offer->getField("VESSEL_NAME");
// $reqTypeOfVessel     = $offer->getField("TYPE_OF_VESSEL");
// $reqClassOfVessel    = $offer->getField("CLASS_OF_VESSEL");
// $reqMaker            = $offer->getField("MAKER");


?>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 285px;"></td>
                    <td><strong>
                            <h3><em> FAKTUR </em></h3>
                        </strong></td>
                    <td>/</td>
                    <td><strong>
                            <h3><em> INVOICE </em></h3>
                        </strong></td>
                    <td style="width: 285px;"></td>
                </tr>
            </table>
        </div>
    </div>
</center>

<br>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 105px	;">INVOICE No </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> INVOICE_NUMBER </strong></td>

                    <td style="width: 165px;"></td>

                    <td style="width: 100px;">To </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> FINANCE </strong></td>

                </tr>
            </table>
        </div>
    </div>
</center>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 105px;">TAX INVOICE</td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> TAX_INVOICE </strong></td>

                    <td style="width: 165px;"></td>

                    <td style="width: 282px;">COMPANY_NAME </td>

                </tr>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 105px;">PO.NO. </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> PO_NO </strong></td>

                    <td style="width: 165px;"></td>

                    <td style="width: 282px;">ADDRESS </td>

                </tr>
            </table>
        </div>
    </div>
</center>


<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 105px	;">PO.DATE </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> PO_DATE </strong></td>

                    <td style="width: 165px;"></td>

                    <td style="width: 100px;">Telp </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> TELEPHONE </strong></td>

                </tr>
            </table>
        </div>
    </div>
</center>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 105px	;"> </td>
                    <td style="width: 12px;"></td>
                    <td style="width: 170px;"><strong> </strong></td>

                    <td style="width: 165px;"></td>

                    <td style="width: 100px;">Fax </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> FAXIMILE </strong></td>

                </tr>
            </table>
        </div>
    </div>
</center>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <td style="width: 105px	;"> </td>
                    <td style="width: 12px;"></td>
                    <td style="width: 170px;"><strong> </strong></td>

                    <td style="width: 165px;"></td>

                    <td style="width: 100px;">E-Mail </td>
                    <td>:</td>
                    <td style="width: 170px;"><strong> EMAIL_ADD </strong></td>

                </tr>
            </table>
        </div>
    </div>
</center>

<br>

<center>
    <div class="row">
        <div class="col">
            <table border="1" style="border-collapse: 1px solid black;text-align: center;width: 100%; font-size: 12px;">
                <thead>
                    <tr>
                        <th style="width: 380px;" rowspan="2">DESCRIPTION</th>
                        <th colspan="2">AMOUNT</th>

                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td> Dollar </td>
                        <td> Rp </td>
                    </tr>
                    <tr>
                        <td align="left" style="padding: 10px"><b>DETIL_SERVICE1</b><br>
                            <ul style="padding-left: 40px">

                                <li>Contract No. NO_KONTRAK </li>

                            </ul>
                        </td>
                        <td> PAYMENT_US1 </td>
                        <td> PAYMENT_RP1</td>

                    </tr>
                    <tr>
                        <td align="left" style="padding: 10px"><b>DETIL_SERVICE2</b><br>
                            <ul style="padding-left: 40px">

                                <li>Contract2 No.2 </li>

                            </ul>
                        </td>
                        <td> PAYMENT_US2 </td>
                        <td> PAYMENT_RP2</td>

                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td align="right"><strong> PPN(10%)</strong></td>
                        <td><strong> PAYMENT_PPN_USD </strong></td>
                        <td><strong> PAYMENT_PPN_RP </strong></td>
                    </tr>

                    <tr>
                        <td align="right"><strong> TOTAL PAYABLE </strong></td>
                        <td><strong> TOTAL_US </strong></td>
                        <td><strong> TOTAL_RP </strong></td>
                    </tr>

                    <tr>
                        <td align="right"><strong> The Sum of : SUM_OF_PAYMENT </strong> </td>
                        <td><strong></strong></td>
                        <td><strong></strong></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</center>

<br>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px;">
                <tr>
                    <!-- <td>Syarat & Ketentuan Umum </td>
					<td>/</td>
					<td>General Terms & Conditions </td> -->
                    <td colspan="2" style="width: 360px;"><strong> Syarat & Ketentuan Umum </strong> / General Terms & Conditions : </td>
                </tr>
                <tr>
                    <td style="width: 300px;" align="justify">
                        <li> Tagihan atas Invoice ini telah kami anggap selesai bila kami telah menerima pembayaran sesuai dengan box Faktur /This invoice is considered paid when we receive the payment as per stipulated within box Invoice </li>
                        <br>
                        <li> Pembayaran menggunakan cek. Bilyet giro atau lainnya kami anggap telah selesai dibayarkan bila telah dapat kami uangkan / Any other payment by cheque, bilyet giro or others shall be deemed as paid when we had collected same effective into our account </li>

                    </td>
                </tr>
            </table>
        </div>
    </div>
</center>

<br>

<center>
    <div class="row">
        <div class="col">
            <table style="width: 100%; font-size: 12px;">
                <tr>

                    <td style="width: 425px;"></td>
                    <td><strong> Sidoarjo </strong></td>
                    <td><strong> , </strong></td>
                    <td>
                        <strong> MONTH_NOW </strong><sup>th</sup>
                    </td>
                    <td><strong>,</strong></td>
                    <td><strong> YEAR_NOW </strong> </td>
                </tr>
            </table>
        </div>
    </div>
</center>

<br>
<br>
<br>

<center>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px; width: 100%;">
                <tr>
                    <td style="width: 600px;"></td>
                    <td align="center" style="width: 200px;">
                        <strong> ISNAINI .R </strong>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <table style="font-size: 12px; width: 100%;">
                <tr>
                    <td style="width: 600px;"></td>
                    <td align="center" style="width: 200px;">
                        <strong> ACCOUNT MANAGER </strong>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</center>