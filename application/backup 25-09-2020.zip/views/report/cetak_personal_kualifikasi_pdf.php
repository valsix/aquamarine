<base href="<?= base_url(); ?>" />

<?

include_once("functions/string.func.php");
include_once("functions/date.func.php");

require('libraries/fpdf182/pdf.php');

$this->load->model('PersonalCertificate');
$certificate = new PersonalCertificate();
$certificate->selectByParamsMonitoring(array());
$arrDatas = array();
$no = 0;
while ($certificate->nextRow()) {
    $arrDatas[$no]['ID'] = $certificate->getField("CERTIFICATE_ID");
    $arrDatas[$no]['NAME'] = $certificate->getField("CERTIFICATE");
    $no++;
}

$reqCariCompanyName = $this->input->post('reqCariCompanyName');
$reqCariTypeofQualification = $this->input->post('reqCariTypeofQualification');
$reqTypeOfService = $this->input->post('reqTypeOfService');

$reqCariCompanyName = $this->input->post('reqCariCompanyName');
$reqCariDescription = $this->input->post('reqCariDescription');


if (!empty($reqCariCompanyName)) {
    $statement = " AND A.COMPANY_NAME LIKE '%" . $reqCariCompanyName . "%' ";
}

if (!empty($reqCariTypeofQualification)) {
    $statement .= " AND A.TYPE_OF_QUALIFICATION LIKE '%" . $reqCariTypeofQualification . "%' ";
}

if (!empty($reqTypeOfService)) {
    $statement .= " AND A.TYPE_OF_SERVICE LIKE '%" . $reqTypeOfService . "%' ";
}

if (!empty($reqCariDescription)) {
    $statement .= " AND A.DESCRIPTION LIKE '%" . $reqCariDescription . "%' ";
}

// if (!empty($reqCariPeriodeYearFrom) && !empty($reqCariPeriodeYearTo)) {
//     $statement .= " AND INVOICE_DATE BETWEEN  TO_CHAR(" . $reqCariPeriodeYearFrom . ", 'yyyy-MM-dd')  AND TO_CHAR(" . $reqCariPeriodeYearTo . ", 'yyyy-MM-dd') ";
// }

// if (!empty($reqCariNoOrder)) {
//     $statement .= " AND A.INVOICE_NUMBER LIKE '%" . $reqCariNoOrder . "%' ";
// }


$this->load->model("JenisKualifikasi");
$personal_kualifikasi = new JenisKualifikasi();

$aColumns = array(
    "NO",
    "NAME", "ADDRESS", "BIRTH_DATE", "PHONE", "QUALIFICATION", "CERTIFICATE"
);

$pdf = new PDF();
ob_end_clean();
$pdf->AliasNbPages();

// ECHO $pdf->w;exit;
$pdf->AddPage('L', 'A4');
$panjang = (($pdf->w * 91) / 100);
// ECHO $pdf->w;exit;
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell($panjang, 10, 'PERSONAL KUALIFIKASI REPORT', 0, 0, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 10);

// exit;
$panjang_tabel = 10;
$arrPanjang = array();
for ($i = 0; $i < 6; $i++) {
    if ($i != 0) {
        $panjang_tabel = 53;
    }
    $pdf->Cell($panjang_tabel, 10, str_replace('_', ' ', $aColumns[$i]), 1, 0, 'C');
    array_push($arrPanjang, $panjang_tabel);
}
$pdf->Ln();
// print_r($arrPanjang);exit;
$personal_kualifikasi->selectByParamsMonitoringPersonalKualifikasiCetakPdf(array(), -1, -1, $statement);
// echo $personal_kualifikasi->query;
// exit;
$pdf->SetFont('Arial', '', 8);
$pdf->SetWidths(array(10, 53, 53, 53, 53, 53, 53, 53));
$no = 1;
while ($personal_kualifikasi->nextRow()) {
    // $date1 =  $personal_kualifikasi->getField('DATE1');
    // $date2 =  $personal_kualifikasi->getField('DATE2');
    // $date_val =
    //     $pdf->Row(array(
    //         $no,
    //         '' . $personal_kualifikasi->getField($aColumns[1]),
    //         '' . $personal_kualifikasi->getField($aColumns[2]),
    //         '' . $personal_kualifikasi->getField($aColumns[3]),
    //         '' . $personal_kualifikasi->getField($aColumns[4]),
    //         '' . getTglBlnTahun($date1) . ' - ' . getTglBlnTahun($date2),
    //         '' . $personal_kualifikasi->getField($aColumns[6]),

    //     ));

    $pdf->Row(array(
        // kolom tabel
        $no,
        '' . $personal_kualifikasi->getField($aColumns[1]),
        '' . $personal_kualifikasi->getField($aColumns[2]),
        '' . $personal_kualifikasi->getField($aColumns[3]),
        '' . $personal_kualifikasi->getField($aColumns[4]),
        '' . $personal_kualifikasi->getField($aColumns[5])
    ));

    // $pdf->MultiCell($panjang - 2.2, 5, 'COMPANY NAME : ' . "\t" . $personal_kualifikasi->getField($aColumns[7]), 1, 'J', 0, 10);
    // $pdf->MultiCell($panjang - 2.2, 5, 'VESSEL NAME : ' . $personal_kualifikasi->getField('VESSEL_NAME'), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'PPN : ' . currencyToPage2($personal_kualifikasi->getField('PPN')), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'STATUS : ' . currencyToPage2($personal_kualifikasi->getField('STATUS')), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'TOTAL AMOUNT: ' . currencyToPage2($personal_kualifikasi->getField('TOTAL_AMOUNT')), 1);
    // $pdf->MultiCell($panjang - 2.2, 5, 'INVOICE DATE : ' . $personal_kualifikasi->getField('INVOICE_DATE'), 1);
    $no++;
}
// $pdf->Cell(60,10,'NO PROJECT',1,0,'C');
// $pdf->Cell(60,10,'VESSEL NAME',1,0,'C');
// $pdf->Cell(60,10,'TYPE OF VESSEL',1,0,'C');
// $pdf->Cell(60,10,'TYPE OF VESSEL',1,0,'C');


ob_end_clean();
$pdf->Output();

?>