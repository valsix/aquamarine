<?
$this->load->model("CostRequestDetail");
$reqId = $this->input->get("reqId");
$tgl_skrng =date('d F Y');

$this->load->model("CostRequest");
$cost_request = new CostRequest();

$cost_request->selectByParamsMonitoring(array("A.COST_REQUEST_ID " => $reqId));
$cost_request->firstRow();
$reqId          = $cost_request->getField("COST_REQUEST_ID");
$reqKode        = $cost_request->getField("KODE");
$reqTanggal     = $cost_request->getField("TANGGAL");
$reqTotal       = $cost_request->getField("TOTAL");
$reqKeterangan  = $cost_request->getField("KETERANGAN");
$cost_request_detail = new CostRequestDetail();
$total = $cost_request_detail->getCountByParamsSum(array("A.COST_REQUEST_ID " => $reqId));


?>

<table  style="width: 100%;font-size: 12px;font-weight: bold;font-family: Consolas;border-collapse: 1px solid black" border="1">
	<tr>
		<td align="center" style="width: 250px;background-color: #002060;color: white"> COST REQUEST </td>
		<td  align="center" style="width: 400px;background-color: #002060;color: white"> TOTAL ( Rp ) </td>
		<td style="width: 150px;background-color: #002060;color: white"> DATE </td>
		<td style="background-color: #002060;color: white"> PREPARED BY </td>
	</tr>
	<tr>
		<td rowspan="3" valign="top" align="center"><br><?=$reqKode ?> </td>
		<td rowspan="3" valign="top" align="center"> <br><?=currencyToPage2($total)?><br> <?=terbilang($total)?> Rupiah</td>
		<td><?= $tgl_skrng?> </td>
		<td style="background-color: #002060;color: white">Isnaini </td>
	</tr>
	<tr>
		<td style="background-color: #002060;color: white">Date </td>
		<td style="background-color: #002060;color: white">ACKNOWLEDGED BY </td>
	</tr>
	<tr>
		<td><?= $tgl_skrng?></td>
		<td> ( ) </td>
	</tr>
</table>

<br>
<br>
<table style="width: 100%;border-collapse: 1px solid black;font-size: 10px;font-family: Consolas;text-align: center;" border="1" >
	<tr>
	<td style="background-color: #002060;color: white"><b>NO</b></td> 
	<td style="background-color: #002060;color: white"><b>DESCRIPTION OF COST</b></td> 
	<td style="background-color: #002060;color: white"><b>COST CODE</b></td> 
	<td style="background-color: #002060;color: white"><b>COST CATEGORI</b></td> 
	<td style="background-color: #002060;color: white"><b>EVIDENCE</b></td> 
	<td style="background-color: #002060;color: white"><b>AMOUNT ( RP )</b></td> 
	<td style="background-color: #002060;color: white"><b>PROJECT</b></td> 
	<td style="background-color: #002060;color: white"><b>PAIN TO</b></td> 
</tr>
<?
  
        $cost_request_detail = new CostRequestDetail();
        $cost_request_detail->selectByParamsMonitoring(array("A.COST_REQUEST_ID"=>$reqId));
        $no=1;
	  while ( $cost_request_detail->nextRow()) {
        	?>
        	<tr>
        	<td><?=$no?> </td>
        	<td><?=$cost_request_detail->getField("KETERANGAN")?> </td>
        	<td><?=$cost_request_detail->getField("COST_CODE")?> </td>
        	<td><?=$cost_request_detail->getField("COST_CODE_CATEGORI")?> </td>
        	<td><?=$cost_request_detail->getField("EVIDANCE")?> </td>
        	<td><?=currencyToPage2($cost_request_detail->getField("AMOUNT"))?> </td>
        	<td><?=$cost_request_detail->getField("PROJECT")?> </td>
        	<td><?=$cost_request_detail->getField("PAID_TO")?> </td>
        </tr>
        	<?

        $no++;	
        }
?>


</table>