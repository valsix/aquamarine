<base href="<?= base_url(); ?>" />

<?

include_once("functions/string.func.php");
include_once("functions/date.func.php");

require('libraries/fpdf182/pdf.php');

$this->load->model("Offer");
$offer = new Offer();

$aColumns = array(
    "NO", "NO_ORDER", "EMAIL", "DESTINATION", "COMPANY_NAME", "VESSEL_NAME", "TYPE_OF_VESSEL", "FAXIMILE", "TYPE_OF_SERVICE", "TOTAL_PRICE", "SCOPE_OF_WORK"
);

$reqCariNoOrder = $this->input->get("reqCariNoOrder");
$reqCariDateofServiceFrom = $this->input->get("reqCariDateofServiceFrom");
$reqCariDateofServiceTo = $this->input->get("reqCariDateofServiceTo");
$reqCariCompanyName = $this->input->get("reqCariCompanyName");
$reqCariPeriodeYear = $this->input->get("reqCariPeriodeYear");
$reqCariVasselName = $this->input->get("reqCariVasselName");
$reqCariProject = $this->input->get("reqCariProject");
$reqCariGlobalSearch = $this->input->get("reqCariGlobalSearch");
$reqCariStatus = $this->input->get("reqCariStatus");

if (!empty($reqCariCompanyName)) {
    $statement .= " AND A.COMPANY_NAME LIKE '%" . $reqCariCompanyName . "%' ";
}
if (!empty($reqCariPeriodeYear)) {
    $statement .= " AND A.DATE_OF_ORDER BETWEEN  to_date('" . $reqCariDateofServiceTo . "', 'yyyy-MM-dd') AND to_date('" . $reqCariDateofServiceFrom . "', 'yyyy-MM-dd') ";
}
if (!empty($reqCariVasselName)) {
    $statement .= " AND A.VESSEL_NAME LIKE '%" . $reqCariVasselName . "%' ";
}
if (!empty($reqCariProject)) {
    $statement .= "AND A.SCOPE_OF_WORK LIKE '%" . $reqCariProject . "%'  ";
}
if (!empty($reqCariGlobalSearch)) {
    $statement .= " AND ( A.VESSEL_NAME LIKE '%" . $reqCariGlobalSearch . "%' 
                                    OR A.COMPANY_NAME LIKE '%" . $reqCariGlobalSearch . "%' 
                                    OR A.SCOPE_OF_WORK LIKE '%" . $reqCariGlobalSearch . "%' 
                                    OR A.NO_ORDER LIKE '%" . $reqCariGlobalSearch . "%' ";
    $statement .= " OR A.TOTAL_PRICE LIKE '%" . $reqCariGlobalSearch . "%' OR A.CONTACT_PERSON LIKE '%" . $reqCariGlobalSearch . "%' OR A.DESTINATION LIKE '%" . $reqCariGlobalSearch . "%'  ";
}
if (!empty($reqCariStatus)) {
    $statement_privacy .= "  AND a.STATUS  = '" . $reqCariStatus . "'";
}



$pdf = new PDF();
ob_end_clean();
$pdf->AliasNbPages();

// ECHO $pdf->w;exit;
$pdf->AddPage('L', 'A4');
$panjang = (($pdf->w * 91) / 100);
// ECHO $pdf->w;exit;
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell($panjang, 10, 'OFFER LIST REPORT', 0, 0, 'C');
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 10);

// exit;
$panjang_tabel = 10;
$arrPanjang = array();
for ($i = 0; $i < 7; $i++) {
    if ($i != 0) {
        $panjang_tabel = 43;
    }
    $pdf->Cell($panjang_tabel, 10, str_replace('_', ' ', $aColumns[$i]), 1, 0, 'C');
    array_push($arrPanjang, $panjang_tabel);
}
$pdf->Ln();
// print_r($arrPanjang);exit;
$offer->selectByParams(array(), -1, -1, $statement);
$pdf->SetFont('Arial', '', 8);
$pdf->SetWidths($arrPanjang);
$no = 1;
while ($offer->nextRow()) {


    $pdf->Row(array(
        $no,
        '' . $offer->getField($aColumns[1]),
        '' . $offer->getField($aColumns[2]),
        '' . $offer->getField($aColumns[3]),
        '' . $offer->getField($aColumns[4]),
        '' . $offer->getField($aColumns[5]),
        '' . $offer->getField($aColumns[6]),

    ));





    $pdf->MultiCell($panjang - 2.2, 5, $aColumns[7] . ' : ' . "\t" . $offer->getField($aColumns[7]), 1, 'J', 0, 10);
    $pdf->MultiCell($panjang - 2.2, 5, $aColumns[8] . ' : ' . $offer->getField($aColumns[8]), 1);
    $pdf->MultiCell($panjang - 2.2, 5, $aColumns[9] . ' : ' . $offer->getField($aColumns[9]), 1);
    $pdf->MultiCell($panjang - 2.2, 5, $aColumns[10] . ' : ' . $offer->getField($aColumns[10]), 1);

    $no++;
}


ob_end_clean();
$pdf->Output();

?>